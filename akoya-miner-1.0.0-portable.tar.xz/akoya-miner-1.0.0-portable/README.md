# Akoya Miner v1.0.0

Mine Pearl (PRL) on the Akoya pool with your NVIDIA GPU.

## Quick start

    # Install (recommended)
    curl -sSL https://get.akoyapool.com/install.sh | sudo bash

    # Or run manually from this folder:
    ./akoya-miner --config config.json

## Requirements

- NVIDIA GPU: RTX 3060 or newer (RTX 30xx, 40xx, 50xx, A100, H100)
- NVIDIA driver 545+ (CUDA 12.4+)
- 64-bit Linux with **GLIBC 2.34 or newer**, e.g.:
    - Ubuntu 22.04 / 24.04
    - Debian 12 / 13
    - Fedora 36+
    - RHEL 9 / Rocky 9 / AlmaLinux 9 / Amazon Linux 2023
    - openSUSE Leap 15.5+ / SLES 15 SP5+

If you're on an older distro (Ubuntu 20.04, RHEL 8, Amazon Linux 2),
use the docker image instead:

    docker run --gpus all --restart=unless-stopped \
      -e AKOYA_POOL_WALLET=PRL1... \
      registry.akoyapool.com/akoya-miner:latest

## Windows users

There is no native Windows build. Use **WSL2 with Ubuntu 22.04**:

    1. Install/update your NVIDIA Windows driver (R545+).
    2. `wsl --install Ubuntu-22.04` (Windows 10/11).
    3. Inside WSL: `curl -sSL https://get.akoyapool.com/install.sh | sudo bash`

WSL2 GPU passthrough gives full CUDA performance with no separate driver.

## Config file example

Create a `config.json`:

    {
      "pool": {
        "url": "pool.akoyapool.com:3333",
        "wallet": "prl1q_YOUR_ADDRESS_HERE",
        "worker": "my-rig"
      },
      "logging": { "level": "info" },
      "devices": "all"
    }

Then run:

    ./akoya-miner --config config.json

## Support

- Pool dashboard: https://pool.akoyapool.com
- Discord: https://discord.gg/pearl
