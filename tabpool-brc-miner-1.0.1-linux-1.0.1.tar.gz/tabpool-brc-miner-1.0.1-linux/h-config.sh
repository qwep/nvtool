#!/usr/bin/env bash
# HiveOS custom miner configuration for Tabpool BRC Miner 1.0.1.

TABPOOL_MINER_DIR="${MINER_DIR:-/hive/miners/custom}/${CUSTOM_MINER:-tabpool-brc-miner-1.0.1-linux}"
TABPOOL_BIN="$TABPOOL_MINER_DIR/tabpool-brc-miner"
TABPOOL_POOL="${CUSTOM_URL:-https://tabpool.xhash.xyz}"
TABPOOL_TEMPLATE="${CUSTOM_TEMPLATE:-}"
TABPOOL_WORKER="${WORKER_NAME:-$(hostname 2>/dev/null || echo rig)}"
TABPOOL_THREADS="$(nproc 2>/dev/null || getconf _NPROCESSORS_ONLN 2>/dev/null || echo 1)"
TABPOOL_CPU_POWER=100
TABPOOL_LANES="" # empty = miner's auto-tuning

# CUSTOM_TEMPLATE is normally the wallet template. Accept address.worker too.
TABPOOL_TEMPLATE="${TABPOOL_TEMPLATE//%WORKER_NAME%/$TABPOOL_WORKER}"
TABPOOL_ADDRESS="${TABPOOL_TEMPLATE%%.*}"
if [[ "$TABPOOL_TEMPLATE" == *.* ]]; then
    TABPOOL_WORKER="${TABPOOL_TEMPLATE#*.}"
fi

# Validate the address required by this miner (64 hexadecimal characters).
if [[ ! "$TABPOOL_ADDRESS" =~ ^[A-Fa-f0-9]{64}$ ]]; then
    echo "ERROR: Tabpool BRC requires a 64-character hexadecimal payout address." >&2
    echo "Set the HiveOS wallet/template to your BRC address (optionally .worker)." >&2
    return 1 2>/dev/null || exit 1
fi

# Worker names supported by the binary: up to 32 chars [A-Za-z0-9._-].
if [[ ! "$TABPOOL_WORKER" =~ ^[A-Za-z0-9._-]{1,32}$ ]]; then
    TABPOOL_WORKER="${TABPOOL_WORKER//[^A-Za-z0-9._-]/-}"
    TABPOOL_WORKER="${TABPOOL_WORKER:0:32}"
fi
[[ -z "$TABPOOL_WORKER" ]] && TABPOOL_WORKER=rig

# CUSTOM_USER_CONFIG accepts either a thread count or CLI options.
# Only the miner's documented tuning options are accepted.
if [[ -n "${CUSTOM_USER_CONFIG:-}" ]]; then
    if [[ "$CUSTOM_USER_CONFIG" =~ ^[0-9]+$ ]]; then
        TABPOOL_THREADS="$CUSTOM_USER_CONFIG"
    else
        read -r -a TABPOOL_EXTRA <<< "$CUSTOM_USER_CONFIG"
        for ((i=0; i<${#TABPOOL_EXTRA[@]}; i++)); do
            case "${TABPOOL_EXTRA[$i]}" in
                --threads|-t)
                    ((i+1 < ${#TABPOOL_EXTRA[@]})) || { echo "Missing value for --threads" >&2; return 1 2>/dev/null || exit 1; }
                    TABPOOL_THREADS="${TABPOOL_EXTRA[++i]}" ;;
                --cpu-power)
                    ((i+1 < ${#TABPOOL_EXTRA[@]})) || { echo "Missing value for --cpu-power" >&2; return 1 2>/dev/null || exit 1; }
                    TABPOOL_CPU_POWER="${TABPOOL_EXTRA[++i]}" ;;
                --lanes)
                    ((i+1 < ${#TABPOOL_EXTRA[@]})) || { echo "Missing value for --lanes" >&2; return 1 2>/dev/null || exit 1; }
                    TABPOOL_LANES="${TABPOOL_EXTRA[++i]}" ;;
                --no-large-pages) TABPOOL_NO_LARGE_PAGES=1 ;;
                *) echo "Unsupported Tabpool extra option: ${TABPOOL_EXTRA[$i]}" >&2; return 1 2>/dev/null || exit 1 ;;
            esac
        done
    fi
fi

[[ "$TABPOOL_THREADS" =~ ^[0-9]+$ ]] && (( TABPOOL_THREADS > 0 && TABPOOL_THREADS <= 4096 )) || { echo "Invalid CPU thread count: $TABPOOL_THREADS" >&2; return 1 2>/dev/null || exit 1; }
[[ "$TABPOOL_CPU_POWER" =~ ^[0-9]+$ ]] && (( TABPOOL_CPU_POWER >= 1 && TABPOOL_CPU_POWER <= 100 )) || { echo "Invalid --cpu-power: $TABPOOL_CPU_POWER" >&2; return 1 2>/dev/null || exit 1; }
[[ -z "$TABPOOL_LANES" || "$TABPOOL_LANES" == 1 || "$TABPOOL_LANES" == 2 ]] || { echo "--lanes must be 1 or 2" >&2; return 1 2>/dev/null || exit 1; }
[[ "$TABPOOL_POOL" == http://* || "$TABPOOL_POOL" == https://* ]] || { echo "Pool URL must start with http:// or https://" >&2; return 1 2>/dev/null || exit 1; }

# Build a Bash array. h-run.sh is sourced by HiveOS in the configured miner context.
TABPOOL_ARGS=(--address "$TABPOOL_ADDRESS" --threads "$TABPOOL_THREADS" --worker "$TABPOOL_WORKER" --pool "$TABPOOL_POOL" --cpu-power "$TABPOOL_CPU_POWER")
[[ -n "$TABPOOL_LANES" ]] && TABPOOL_ARGS+=(--lanes "$TABPOOL_LANES")
[[ "${TABPOOL_NO_LARGE_PAGES:-0}" == 1 ]] && TABPOOL_ARGS+=(--no-large-pages)

# A human-readable copy for the HiveOS config display.
printf 'address=%s\npool=%s\nworker=%s\nthreads=%s\ncpu_power=%s\nlanes=%s\n' \
    "$TABPOOL_ADDRESS" "$TABPOOL_POOL" "$TABPOOL_WORKER" "$TABPOOL_THREADS" "$TABPOOL_CPU_POWER" "${TABPOOL_LANES:-auto}" \
    > "$TABPOOL_MINER_DIR/miner.conf" 2>/dev/null || true
