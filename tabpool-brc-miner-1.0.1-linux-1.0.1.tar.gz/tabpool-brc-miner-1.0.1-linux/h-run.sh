#!/usr/bin/env bash
# HiveOS runs this script with h-config.sh already sourced.
set -o pipefail

MINER_BIN="${MINER_DIR:-/hive/miners/custom}/${CUSTOM_MINER:-tabpool-brc-miner-1.0.1-linux}/tabpool-brc-miner"
LOG_DIR="/var/log/miner/tabpool-brc-miner"
LOG_FILE="$LOG_DIR/tabpool-brc-miner.log"
mkdir -p "$LOG_DIR"

if [[ ! -x "$MINER_BIN" ]]; then
    echo "Tabpool BRC miner binary missing or not executable: $MINER_BIN" >&2
    return 1 2>/dev/null || exit 1
fi

if [[ ${#TABPOOL_ARGS[@]} -eq 0 ]]; then
    echo "Tabpool config is empty. Check h-config.sh / HiveOS wallet and pool." >&2
    return 1 2>/dev/null || exit 1
fi

# Keep output visible to HiveOS and save it for h-stats.sh parsing.
"$MINER_BIN" "${TABPOOL_ARGS[@]}" 2>&1 | tee -a "$LOG_FILE"
exit ${PIPESTATUS[0]}
