#!/usr/bin/env bash
# HiveOS stats hook. The miner 1.0.1 currently has no documented local API;
# parse hashrate/share counters from its console log when those lines exist.

local_log="/var/log/miner/tabpool-brc-miner/tabpool-brc-miner.log"
local_pid="$(pgrep -fo '/tabpool-brc-miner( |$)' 2>/dev/null || true)"
local_uptime=0
local_hs=0
local_accepted=0
local_rejected=0

if [[ -n "$local_pid" && -r "/proc/$local_pid/stat" ]]; then
    local_uptime="$(ps -o etimes= -p "$local_pid" 2>/dev/null | tr -d ' ' )"
    [[ "$local_uptime" =~ ^[0-9]+$ ]] || local_uptime=0
fi

if [[ -r "$local_log" ]]; then
    # Supports common miner console forms such as "123.4 H/s", "1.2 kH/s"
    # or "hashrate: 1234 H/s". No synthetic estimate is reported.
    local_rate="$(grep -Eio '[0-9]+([.][0-9]+)?[[:space:]]*(k|m|g)?[[:space:]]*h/s' "$local_log" | tail -n 1 | awk '
      {v=$1; u=tolower($2); if (u ~ /^kh/) v*=1000; else if (u ~ /^mh/) v*=1000000; else if (u ~ /^gh/) v*=1000000000; print v+0}')"
    [[ "$local_rate" =~ ^[0-9]+([.][0-9]+)?$ ]] && local_hs="$local_rate"
    local_accepted="$(grep -Eic 'share accepted|accepted share' "$local_log" 2>/dev/null || true)"
    local_rejected="$(grep -Eic 'share rejected|rejected share' "$local_log" 2>/dev/null || true)"
fi

# HiveOS expects khs in kH/s and hs array units declared explicitly.
khs="$(awk -v h="$local_hs" 'BEGIN {printf "%.8f", h/1000}')"
stats="{\"hs\":[${local_hs}],\"hs_units\":\"hs\",\"uptime\":${local_uptime},\"ver\":\"1.0.1\",\"ar\":[${local_accepted:-0},${local_rejected:-0}],\"algo\":\"brc\"}"

echo "$stats"
