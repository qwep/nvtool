#!/bin/sh
# 範例啟動腳本：把地址改成自己的再執行；也可以刪掉參數，改寫在同資料夾的 config.json
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec "$DIR/tabpool-brc-miner" --address YOUR_BRC_ADDRESS --threads "$(nproc)" "$@"
