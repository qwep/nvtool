# -*- coding: utf-8 -*-

"""Vast.ai GPU rental Telegram bot.

Feature parity with the user's Clore bot where Vast.ai has an equivalent:
- ON-DEMAND auto-rent
- optional INTERRUPTIBLE and RESERVED auto-rent
- per-GPU / 24h price ranges
- permanent machine blacklist
- Telegram inline controls for pause/start, prices and active-rig limit
- real active-instance synchronization from Vast.ai
- hard active-rig limit with automatic pause/resume
- throttled Telegram limit notifications
- marketplace caching and API request gating to reduce 429/rate pressure
- manual rent buttons from /market

Important Vast.ai differences:
- Vast uses instances rather than Clore orders.
- Vast pricing is hourly; this bot converts dph_total/min_bid to /24h for
  the same price-range UI used by the previous bot.
- Vast interruptible instances can be preempted; this bot does not pretend
  that an interruptible instance has Clore-style renewal.
- Reserved offers are searched separately with Vast's reserved marketplace type.

Dependencies:
    pip install requests

Environment:
    VAST_API_KEY   Vast.ai API key
    TG_TOKEN       Telegram bot token
    TG_CHAT_ID     allowed Telegram chat id

Optional:
    VAST_IMAGE, VAST_DISK_GB, VAST_TEMPLATE_HASH, VAST_RUNTYPE,
    VAST_JUPYTER_TOKEN, VAST_ONSTART_CMD, VAST_REQUIRE_VERIFIED,
    VAST_MIN_RELIABILITY, VAST_EXTERNAL_ALLOWED, etc.
"""

import html
import hashlib
import json
import logging
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from heapq import nsmallest
from pathlib import Path
from typing import Any, Optional

import requests
from requests.adapters import HTTPAdapter

try:
    from vastai import VastAI
except ImportError as exc:
    raise RuntimeError(
        "Не установлен официальный Vast.ai SDK. Выполни: python -m pip install -U vastai"
    ) from exc


# ============================================================
# CONFIG
# ============================================================

VAST_API_KEY = os.getenv("VAST_API_KEY", "d07f14ddf61379c8a930cdb8d5d08f4b85a748f976f0a13bb2efd7278e8b3855")
TG_TOKEN = os.getenv("TG_TOKEN", "8895520023:AAF4XeN3hJfy8fOZYbBvHWfKXQXEL9GkU3A")
TG_CHAT_ID = os.getenv("TG_CHAT_ID", "265459649")

if not VAST_API_KEY or VAST_API_KEY.startswith("ВСТАВЬ_"):
    raise RuntimeError("Вставь VAST_API_KEY в CONFIG или задай переменную окружения VAST_API_KEY")
if not TG_TOKEN or TG_TOKEN.startswith("ВСТАВЬ_"):
    raise RuntimeError("Вставь TG_TOKEN в CONFIG или задай переменную окружения TG_TOKEN")
if not TG_CHAT_ID or TG_CHAT_ID.startswith("ВСТАВЬ_"):
    raise RuntimeError("Вставь TG_CHAT_ID в CONFIG или задай переменную окружения TG_CHAT_ID")


# ------------------------------------------------------------
# Vast.ai
# ------------------------------------------------------------

# The current Vast CLI/REST documentation continues to expose the v0
# endpoints below for offers, instances and account details.
VAST_BASE_URL = os.getenv("VAST_BASE_URL", "https://console.vast.ai/api/v0")

# Official Vast.ai Python SDK (current PyPI package).
# Core offer/instance operations below use this object instead of hand-built
# REST calls. SDK resolves the same VAST_API_KEY passed here.
VAST_SDK = VastAI(
    api_key=VAST_API_KEY,
    retry=3,
    raw=True,
    quiet=True,
)
VAST_SDK_MIN_INTERVAL = float(os.getenv("VAST_SDK_MIN_INTERVAL", "0.20"))
_vast_sdk_lock = threading.Lock()
_last_vast_sdk_call = 0.0

def _sdk_rate_gate() -> None:
    global _last_vast_sdk_call
    with _vast_sdk_lock:
        now = time.monotonic()
        target = max(now, _last_vast_sdk_call + VAST_SDK_MIN_INTERVAL)
        _last_vast_sdk_call = target
    delay = target - now
    if delay > 0:
        time.sleep(delay)

def vast_sdk_call(method_name: str, *args, **kwargs):
    _sdk_rate_gate()
    method = getattr(VAST_SDK, method_name)
    return method(*args, **kwargs)


VAST_IMAGE = os.getenv("VAST_IMAGE", "vastai/pytorch:cuda-13.2.1-auto")
VAST_TEMPLATE_HASH = os.getenv("VAST_TEMPLATE_HASH", "").strip()
VAST_DISK_GB = float(os.getenv("VAST_DISK_GB", "16"))
VAST_RUNTYPE = os.getenv(
    "VAST_RUNTYPE",
    "jupyter_direct",
).strip()
VAST_JUPYTER_TOKEN = os.getenv("VAST_JUPYTER_TOKEN", "")
VAST_ONSTART_CMD = os.getenv("VAST_ONSTART_CMD", "entrypoint.sh").strip()
VAST_EXTRA = os.getenv(
    "VAST_EXTRA",
    '-p 1111:1111 -p 6006:6006 -p 8080:8080 -p 8384:8384 -p 10100:10100 -p 10200:10200 -p 72299:72299 '
    '-e OPEN_BUTTON_PORT="1111" -e OPEN_BUTTON_TOKEN="1" '
    '-e JUPYTER_DIR="/" -e DATA_DIRECTORY="/workspace/" '
    '-e PORTAL_CONFIG="localhost:1111:11111:/:Instance Portal|localhost:8080:18080:/:Jupyter|localhost:8080:8080:/terminals/1:Jupyter Terminal|localhost:8384:18384:/:Syncthing|localhost:6006:16006:/:Tensorboard"'
).strip()
VAST_LABEL_PREFIX = os.getenv("VAST_LABEL_PREFIX", "clore-style-bot")
VAST_REQUIRE_VERIFIED = os.getenv(
    "VAST_REQUIRE_VERIFIED", "true"
).lower() in ("1", "true", "yes", "on")
VAST_EXTERNAL_ALLOWED = os.getenv(
    "VAST_EXTERNAL_ALLOWED", "false"
).lower() in ("1", "true", "yes", "on")
VAST_MIN_RELIABILITY = float(os.getenv("VAST_MIN_RELIABILITY", "0"))
VAST_MIN_CUDA = float(os.getenv("VAST_MIN_CUDA", "0"))
VAST_MIN_DISK_GB = float(os.getenv("VAST_MIN_DISK_GB", "0"))
VAST_MIN_DIRECT_PORTS = int(os.getenv("VAST_MIN_DIRECT_PORTS", "1"))
MARKETPLACE_MIN_GPU_COUNT = int(os.getenv("MARKETPLACE_MIN_GPU_COUNT", "1"))
MARKETPLACE_MAX_GPU_COUNT = int(os.getenv("MARKETPLACE_MAX_GPU_COUNT", "8"))
VAST_RESERVED_PREPAY_AMOUNT = float(os.getenv("VAST_RESERVED_PREPAY_AMOUNT", "0"))

# Vast charges are hourly. We display /24h in the same price-menu units as
# the user's old Clore bot.
MIN_ON_DEMAND_DAILY = float(os.getenv("MIN_ON_DEMAND_DAILY", "0"))
MAX_ON_DEMAND_DAILY = float(os.getenv("MAX_ON_DEMAND_DAILY", "999999"))
MIN_SPOT_DAILY = float(os.getenv("MIN_SPOT_DAILY", "0"))
MAX_SPOT_DAILY = float(os.getenv("MAX_SPOT_DAILY", "999999"))
MIN_RESERVED_DAILY = float(os.getenv("MIN_RESERVED_DAILY", "0"))
MAX_RESERVED_DAILY = float(os.getenv("MAX_RESERVED_DAILY", "999999"))


# ------------------------------------------------------------
# Scan / automation
# ------------------------------------------------------------

SCAN_DELAY = float(os.getenv("SCAN_DELAY", "3"))
# Auto capture is enabled only for ON-DEMAND; INTERRUPTIBLE remains manual.
# INTERRUPTIBLE/BID remains manual only in this build.
# INTERRUPTIBLE/BID remains available for manual rental, but never auto-captures.
AUTO_ON_DEMAND = os.getenv("AUTO_ON_DEMAND", "true").lower() in (
    "1", "true", "yes", "on"
)
AUTO_SPOT = False
AUTO_INTERRUPTIBLE = False
AUTO_RESERVED = False  # RESERVED отключён по запросу пользователя
# Original environment setting is intentionally ignored while RESERVED is disabled.
_UNUSED_AUTO_RESERVED_ENV = os.getenv("AUTO_RESERVED", "false").lower() in (
    "1", "true", "yes", "on"
)
NOTIFY_SPOT_WHEN_AUTO_DISABLED = os.getenv(
    "NOTIFY_SPOT_WHEN_AUTO_DISABLED", "true"
).lower() in ("1", "true", "yes", "on")
SPOT_NOTIFY_COOLDOWN = float(os.getenv("SPOT_NOTIFY_COOLDOWN", "300"))
MAX_RENT_PER_SCAN = int(os.getenv("MAX_RENT_PER_SCAN", "10"))

# Automatic marketplace notifications are independent from auto-rental.
# Auto-rental stays OFF by default, but the bot can still scan and report
# available offers with manual rent buttons.
MARKETPLACE_AUTO_NOTIFY = os.getenv(
    "MARKETPLACE_AUTO_NOTIFY", "true"
).lower() in ("1", "true", "yes", "on")
MARKETPLACE_NOTIFY_INTERVAL = float(
    os.getenv("MARKETPLACE_NOTIFY_INTERVAL", "15")
)
MARKETPLACE_NOTIFY_COOLDOWN = float(
    os.getenv("MARKETPLACE_NOTIFY_COOLDOWN", "300")
)
MARKETPLACE_NOTIFY_MAX = int(
    os.getenv("MARKETPLACE_NOTIFY_MAX", "24")
)
MARKETPLACE_NOTIFY_PRICE_CHANGE = float(
    os.getenv("MARKETPLACE_NOTIFY_PRICE_CHANGE", "0.01")
)

# Vast does not provide the same fixed-period ON-DEMAND renewal model as
# Clore. For parity of control, the old variables are retained only as
# compatibility names and are intentionally not used as a fake renewal.
AUTO_RENEW_ON_DEMAND = False

# Sync/instance polling.
ACTIVE_INSTANCE_SYNC_TTL = float(os.getenv("ACTIVE_INSTANCE_SYNC_TTL", "30"))
INSTANCES_CACHE_TTL = float(os.getenv("INSTANCES_CACHE_TTL", "15"))
MARKETPLACE_CACHE_TTL = float(os.getenv("MARKETPLACE_CACHE_TTL", "5"))
ACCOUNT_STATS_CACHE_TTL = float(os.getenv("ACCOUNT_STATS_CACHE_TTL", "15"))

# Vast API request gate. The public tooling recommends avoiding aggressive
# request rates; 1.05s is deliberately conservative for a polling bot.
VAST_GET_MIN_INTERVAL = float(os.getenv("VAST_GET_MIN_INTERVAL", "0.55"))
VAST_MAX_RETRIES = int(os.getenv("VAST_MAX_RETRIES", "3"))
VAST_MARKETPLACE_LIMIT = int(os.getenv("VAST_MARKETPLACE_LIMIT", "500"))
VAST_MULTIGPU_QUERY_LIMIT = int(os.getenv("VAST_MULTIGPU_QUERY_LIMIT", "1000"))
VAST_MULTIGPU_CACHE_TTL = float(os.getenv("VAST_MULTIGPU_CACHE_TTL", "45"))

# Prevent repeated Telegram spam when the active-rig cap is full.
LIMIT_ERROR_NOTIFY_INTERVAL = float(
    os.getenv("LIMIT_ERROR_NOTIFY_INTERVAL", "600")
)
_limit_error_notify_lock = threading.Lock()

# INTERRUPTIBLE / BID controls. Vast changes bid in $/hour.
# Each Telegram click raises the stored bid by exactly this amount.
BID_RAISE_STEP = float(os.getenv("BID_RAISE_STEP", "0.10"))
BID_OUTBID_NOTIFY_COOLDOWN = float(
    os.getenv("BID_OUTBID_NOTIFY_COOLDOWN", "600")
)
_bid_change_lock = threading.Lock()

# Real active-rig pause gate.
_active_limit_pause_lock = threading.Lock()
_active_limit_pause = False
_active_limit_pause_active = None
_active_limit_pause_limit = None


# ------------------------------------------------------------
# Permanent blacklist
# ------------------------------------------------------------

# Vast host identity is more stable when blacklisting machine_id rather than
# a temporary offer id. Keep this empty by default; add IDs if needed.
BANNED_MACHINE_IDS = {
    int(x.strip())
    for x in os.getenv("BANNED_MACHINE_IDS", "").split(",")
    if x.strip().isdigit()
}


# ------------------------------------------------------------
# Excluded GPU models
# ------------------------------------------------------------

EXCLUDED_GPU_NAMES = {
    "rtx 4090 laptop gpu",
    "geforce rtx 4090 laptop gpu",
    "rtx 5090 laptop gpu",
    "geforce rtx 5090 laptop gpu",
}
EXCLUDED_GPU_NAMES_LOWER = tuple(x.lower() for x in EXCLUDED_GPU_NAMES)


# ------------------------------------------------------------
# GPU aliases / prices
# ------------------------------------------------------------

GPU_ALIASES = {
    "5090": ["RTX 5090", "GeForce RTX 5090"],
    "5080": ["RTX 5080", "GeForce RTX 5080"],
    "5070TI": ["RTX 5070 Ti", "RTX 5070TI", "GeForce RTX 5070 Ti"],
    "5060TI": ["RTX 5060 Ti", "RTX 5060TI", "GeForce RTX 5060 Ti"],
    "4090": ["RTX 4090", "GeForce RTX 4090"],
    "4070": ["RTX 4070", "GeForce RTX 4070", "NVIDIA GeForce RTX 4070"],
    "4080": ["RTX 4080", "GeForce RTX 4080"],
    "4080SUPER": ["RTX 4080 SUPER", "RTX 4080SUPER", "GeForce RTX 4080 SUPER"],
    "4070TI": ["RTX 4070 Ti", "RTX 4070TI", "GeForce RTX 4070 Ti", "NVIDIA GeForce RTX 4070 Ti"],
    "4070TISUPER": ["RTX 4070 Ti SUPER", "RTX 4070TI SUPER", "RTX 4070S Ti", "GeForce RTX 4070 Ti SUPER", "NVIDIA GeForce RTX 4070 Ti SUPER", "NVIDIA GeForce RTX 4070S Ti"],
    "3080": ["RTX 3080", "GeForce RTX 3080"],
    "3090": ["RTX 3090", "GeForce RTX 3090"],
    "3080TI": ["RTX 3080 Ti", "RTX 3080TI", "GeForce RTX 3080 Ti"],
    "A100": ["A100", "NVIDIA A100", "NVIDIA A100-SXM4-40GB", "NVIDIA A100-SXM4-80GB"],
    "A6000": ["RTX A6000", "NVIDIA RTX A6000"],
    "V100": ["Tesla V100", "NVIDIA Tesla V100", "Tesla V100S", "NVIDIA Tesla V100S"],
    "TESLAV100": ["Tesla V100", "NVIDIA Tesla V100", "Tesla V100S", "NVIDIA Tesla V100S"],
}

# GPU filter shown in Telegram. "470TI" from the request is normalized to
# the standard model name "4070TI".
DEFAULT_FILTER_GPUS = [
    "5090", "5080", "5070TI", "5060TI", "4090", "4070",
    "4080", "4080SUPER", "4070TI", "4070TISUPER",
    "3080", "3090",
]

ALLOWED_GPUS = [
    x.strip()
    for x in os.getenv("ALLOWED_GPUS", ",".join(DEFAULT_FILTER_GPUS)).split(",")
    if x.strip()
]

# Price limits are TOTAL PRICE FOR 24 HOURS PER GPU.
# Vast offers themselves are hourly; the bot converts hourly -> daily
# and then divides by the number of GPUs before applying these limits.
GPU_PRICE_DAILY_RANGES = {
    "5090": (4.00, 6.50),
    "5080": (1.50, 4.50),
    "5070TI": (3.00, 3.50),
    "5060TI": (1.00, 2.30),
    "4090": (3.80, 5.50),
    "4080": (1.50, 4.50),
    "4080SUPER": (1.50, 5.00),
    "4070TI": (2.00, 3.00),
    "4070TISUPER": (3.00, 3.90),
    "3090": (2.00, 2.35),
    "3080TI": (2.00, 2.25),
    "3080": (2.00, 2.20),
    "A100": (5.00, 11.00),
    "A6000": (2.00, 6.00),
    "V100": (1.50, 2.20),
    "TESLAV100": (1.50, 2.20),
}

GPU_ALIAS_PAIRS = sorted(
    (
        alias.lower(),
        gpu_key,
    )
    for gpu_key, aliases in GPU_ALIASES.items()
    for alias in aliases
)
GPU_ALIAS_PAIRS.sort(key=lambda item: len(item[0]), reverse=True)
GPU_ALIAS_LOOKUP = {alias: key for alias, key in GPU_ALIAS_PAIRS}
GPU_ALIAS_PATTERN = re.compile(
    "|".join(re.escape(alias) for alias, _ in GPU_ALIAS_PAIRS),
    flags=re.IGNORECASE,
)
ALLOWED_GPU_KEYS = {x for x in ALLOWED_GPUS if x in GPU_ALIASES}
GPU_DISPLAY_NAMES = {
    key: (aliases[0] if aliases else key)
    for key, aliases in GPU_ALIASES.items()
}


# ============================================================
# LOGGING / SESSIONS
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)
logger = logging.getLogger("vast-gpu-bot")

def _build_http_session(user_agent: str) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        pool_connections=4,
        pool_maxsize=8,
        max_retries=0,
    )
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    session.headers.update({"User-Agent": user_agent})
    return session


TG_SESSION = _build_http_session("Vast-GPU-Bot/Telegram")

VAST_SESSION = _build_http_session("Vast-GPU-Bot/1.1")
VAST_SESSION.headers.update(
    {
        "Accept": "application/json",
        "Authorization": f"Bearer {VAST_API_KEY}",
    }
)


# ============================================================
# STATE
# ============================================================

STATE_FILE = Path(os.getenv("STATE_FILE", "vast_bot_state.json"))
state_lock = threading.Lock()

state = {
    "blacklist": sorted(BANNED_MACHINE_IDS),
    "rented": [],  # active machine ids, not offer ids
    "instance_ids": [],
    "auto_on_demand_paused": not AUTO_ON_DEMAND,
    "auto_interruptible_paused": not AUTO_INTERRUPTIBLE,
    "auto_reserved_paused": not AUTO_RESERVED,
    "max_active_rigs": 4,
    "auto_gpu_price_daily_ranges": {},
    "spot_notifications": {},
    "marketplace_notifications": {},
    "marketplace_live_message_id": None,
    "marketplace_live_message_hash": "",
    "reserved_prepay_amount": VAST_RESERVED_PREPAY_AMOUNT,
    "pending_input": None,
    "control_message_id": None,
    "control_message_hash": "",
    "last_limit_error_notify_ts": 0.0,
    # Per-instance bid tracking: instance_id -> {bid, machine_id, gpu_name}.
    # This is required because Vast exposes min_bid for the current floor,
    # while the bot needs to remember the bid price it actually submitted.
    "bid_tracking": {},
    "bid_outbid_notifications": {},
    "gpu_filter_enabled": list(DEFAULT_FILTER_GPUS),
}

blacklist_set = set(BANNED_MACHINE_IDS)
rented_machine_set = set()
rented_instance_set = set()
marketplace_scan_lock = threading.Lock()
# Telegram UI refreshes use a separate lock so a slow Vast marketplace scan
# never blocks callback handling longer than necessary.
marketplace_live_update_lock = threading.Lock()
# A saved Telegram message_id is not trusted blindly after a bot restart.
# The first marketplace refresh of each process verifies/repairs the message.
marketplace_live_message_verified = False
rental_create_lock = threading.Lock()


# ============================================================
# STATE HELPERS
# ============================================================

AUTO_MODE_DEFAULTS_VERSION = 4

def _sync_state_indexes_locked():
    global blacklist_set, rented_machine_set, rented_instance_set

    raw_blacklist = state.get("blacklist", [])
    raw_rented = state.get("rented", [])
    raw_instances = state.get("instance_ids", [])

    def norm_ints(values):
        out = []
        seen = set()
        if not isinstance(values, list):
            return out
        for value in values:
            try:
                ivalue = int(value)
            except (TypeError, ValueError):
                continue
            if ivalue not in seen:
                seen.add(ivalue)
                out.append(ivalue)
        return out

    normalized_blacklist = norm_ints(raw_blacklist)
    for machine_id in sorted(BANNED_MACHINE_IDS):
        if machine_id not in normalized_blacklist:
            normalized_blacklist.append(machine_id)

    normalized_rented = norm_ints(raw_rented)
    normalized_instances = norm_ints(raw_instances)

    state["blacklist"] = normalized_blacklist
    state["rented"] = normalized_rented
    state["instance_ids"] = normalized_instances
    # One-time migration: the previous MANUAL build saved all auto modes as
    # paused. The user explicitly switched to auto capture for all three modes,
    # so activate them once now. Future Telegram pause/resume actions persist.
    state.setdefault("auto_on_demand_paused", not AUTO_ON_DEMAND)
    state.setdefault("auto_interruptible_paused", not AUTO_INTERRUPTIBLE)
    state.setdefault("auto_reserved_paused", not AUTO_RESERVED)

    try:
        activation_version = int(state.get("auto_mode_defaults_version", 0) or 0)
    except (TypeError, ValueError):
        activation_version = 0
    if activation_version < AUTO_MODE_DEFAULTS_VERSION:
        # Current policy: automatic capture is ON-DEMAND only; INTERRUPTIBLE remains manual.
        # INTERRUPTIBLE stays manual-only.
        state["auto_on_demand_paused"] = not AUTO_ON_DEMAND
        state["auto_interruptible_paused"] = True
        state["auto_reserved_paused"] = True
        state["auto_mode_defaults_version"] = AUTO_MODE_DEFAULTS_VERSION
        logger.info(
            "Auto mode policy applied: ON-DEMAND=%s INTERRUPTIBLE=%s RESERVED=%s",
            AUTO_ON_DEMAND, AUTO_INTERRUPTIBLE, AUTO_RESERVED,
        )

    raw_gpu_filter = state.get("gpu_filter_enabled")
    if not isinstance(raw_gpu_filter, list):
        raw_gpu_filter = list(DEFAULT_FILTER_GPUS)
    normalized_gpu_filter = []
    for gpu_key in raw_gpu_filter:
        key = str(gpu_key).strip()
        if key in ALLOWED_GPUS and key in GPU_ALIASES and key not in normalized_gpu_filter:
            normalized_gpu_filter.append(key)
    # Old state files have no filter; enable all currently configured GPUs.
    if "gpu_filter_enabled" not in state:
        normalized_gpu_filter = [key for key in ALLOWED_GPUS if key in GPU_ALIASES]
    # Make the two requested 4070 Ti models visible in Telegram even when an
    # older state.json was created before these models were added.  This is a
    # one-time migration and does not depend on whether the current marketplace
    # has an offer for the model.
    required_visible_gpus = ("4070TI", "4070TISUPER")
    for key in required_visible_gpus:
        if key in ALLOWED_GPUS and key in GPU_ALIASES and key not in normalized_gpu_filter:
            normalized_gpu_filter.append(key)
            logger.info("GPU filter migration: enabled %s", key)
    state["gpu_filter_enabled"] = normalized_gpu_filter

    # Price ranges are stored per GPU and per rental type. Migrate older
    # single-range state by copying that range to all three modes.
    raw_ranges = state.get("auto_gpu_price_daily_ranges", {})
    migrated_ranges = {}
    if isinstance(raw_ranges, dict):
        for gpu_key, values in raw_ranges.items():
            if isinstance(values, (list, tuple)) and len(values) == 2:
                try:
                    pair = [float(values[0]), float(values[1])]
                except (TypeError, ValueError):
                    continue
                migrated_ranges[gpu_key] = {
                    "on-demand": pair[:],
                    "interruptible": pair[:],
                    "reserved": pair[:],
                }
            elif isinstance(values, dict):
                mode_map = {}
                for mode in ("on-demand", "interruptible"):
                    candidate = values.get(mode)
                    if isinstance(candidate, (list, tuple)) and len(candidate) == 2:
                        try:
                            mode_map[mode] = [float(candidate[0]), float(candidate[1])]
                        except (TypeError, ValueError):
                            pass
                if mode_map:
                    # Fill missing modes from the first available valid range.
                    fallback = next(iter(mode_map.values()))[:]
                    for mode in ("on-demand", "interruptible"):
                        mode_map.setdefault(mode, fallback[:])
                    migrated_ranges[gpu_key] = mode_map
    state["auto_gpu_price_daily_ranges"] = migrated_ranges
    state.setdefault("spot_notifications", {})
    if not isinstance(state.get("marketplace_notifications"), dict):
        state["marketplace_notifications"] = {}
    if not isinstance(state.get("bid_tracking"), dict):
        state["bid_tracking"] = {}
    if not isinstance(state.get("bid_outbid_notifications"), dict):
        state["bid_outbid_notifications"] = {}

    # Normalize persisted bid state. Bad entries are dropped rather than
    # risking a wrong bid update after a restart.
    normalized_bid_tracking = {}
    for raw_iid, raw_item in list(state.get("bid_tracking", {}).items()):
        try:
            iid = str(int(raw_iid))
        except (TypeError, ValueError):
            continue
        if not isinstance(raw_item, dict):
            continue
        try:
            bid = float(raw_item.get("bid"))
        except (TypeError, ValueError):
            continue
        if bid <= 0:
            continue
        item = {"bid": round(bid, 2)}
        machine_id = norm_ints([raw_item.get("machine_id")])
        if machine_id:
            item["machine_id"] = machine_id[0]
        gpu_name = str(raw_item.get("gpu_name", "") or "").strip()
        if gpu_name:
            item["gpu_name"] = gpu_name
        normalized_bid_tracking[iid] = item
    state["bid_tracking"] = normalized_bid_tracking

    normalized_bid_notifications = {}
    for raw_iid, raw_item in list(state.get("bid_outbid_notifications", {}).items()):
        try:
            iid = str(int(raw_iid))
        except (TypeError, ValueError):
            continue
        if isinstance(raw_item, dict):
            normalized_bid_notifications[iid] = {
                "notified": bool(raw_item.get("notified", False)),
                "last_ts": float(raw_item.get("last_ts", 0.0) or 0.0),
            }
        else:
            normalized_bid_notifications[iid] = {
                "notified": bool(raw_item),
                "last_ts": 0.0,
            }
    state["bid_outbid_notifications"] = normalized_bid_notifications

    try:
        state["last_limit_error_notify_ts"] = float(
            state.get("last_limit_error_notify_ts", 0.0) or 0.0
        )
    except (TypeError, ValueError):
        state["last_limit_error_notify_ts"] = 0.0

    try:
        limit = int(state.get("max_active_rigs", 4))
    except (TypeError, ValueError):
        limit = 4
    state["max_active_rigs"] = max(1, min(100, limit))

    # RESERVED prepay is runtime-configurable from Telegram. The environment
    # variable is only the initial default; after the first start the value is
    # persisted in state.json and survives restarts.
    try:
        prepay_amount = float(state.get("reserved_prepay_amount", VAST_RESERVED_PREPAY_AMOUNT) or 0.0)
    except (TypeError, ValueError):
        prepay_amount = VAST_RESERVED_PREPAY_AMOUNT
    state["reserved_prepay_amount"] = max(0.0, min(100000.0, prepay_amount))

    pending = state.get("pending_input")
    if not isinstance(pending, dict) or pending.get("kind") != "reserved_prepay":
        state["pending_input"] = None

    blacklist_set = set(normalized_blacklist)
    rented_machine_set = set(normalized_rented)
    rented_instance_set = set(normalized_instances)


def load_state():
    global state

    if not STATE_FILE.exists():
        with state_lock:
            _sync_state_indexes_locked()
        return

    try:
        with STATE_FILE.open("r", encoding="utf-8") as f:
            loaded = json.load(f)
        if isinstance(loaded, dict):
            state.update(loaded)
        with state_lock:
            _sync_state_indexes_locked()
        logger.info("State загружен из %s", STATE_FILE)
    except Exception as exc:
        logger.error("Ошибка загрузки state: %s", exc)


def save_state():
    try:
        with state_lock:
            tmp = STATE_FILE.with_suffix(".tmp")
            with tmp.open("w", encoding="utf-8") as f:
                json.dump(state, f, ensure_ascii=False, indent=2)
            tmp.replace(STATE_FILE)
    except Exception as exc:
        logger.error("Ошибка сохранения state: %s", exc)


def get_reserved_prepay_amount() -> float:
    with state_lock:
        try:
            return max(0.0, float(state.get("reserved_prepay_amount", VAST_RESERVED_PREPAY_AMOUNT) or 0.0))
        except (TypeError, ValueError):
            return max(0.0, float(VAST_RESERVED_PREPAY_AMOUNT))


def set_reserved_prepay_amount(amount: float) -> float:
    amount = float(amount)
    if amount < 0:
        raise ValueError("Сумма prepay не может быть отрицательной")
    if amount > 100000:
        raise ValueError("Сумма prepay слишком большая (максимум $100000)")
    with state_lock:
        state["reserved_prepay_amount"] = round(amount, 2)
        state["pending_input"] = None
    save_state()
    return round(amount, 2)


def set_pending_reserved_prepay(waiting: bool) -> None:
    with state_lock:
        state["pending_input"] = {"kind": "reserved_prepay"} if waiting else None
    save_state()


def is_waiting_reserved_prepay() -> bool:
    with state_lock:
        pending = state.get("pending_input")
        return isinstance(pending, dict) and pending.get("kind") == "reserved_prepay"


# ============================================================
# GENERIC HELPERS
# ============================================================

def get_value(obj: Any, *names: str, default=None):
    if obj is None:
        return default
    for name in names:
        if isinstance(obj, dict) and name in obj:
            return obj[name]
        if not isinstance(obj, dict):
            try:
                value = getattr(obj, name)
                if value is not None:
                    return value
            except Exception:
                pass
    return default


def to_int(value, default=None):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def to_float(value, default=None):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def boolish(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return str(value).lower() in ("1", "true", "yes", "on")


def short_error(exc: Exception, max_len: int = 500) -> str:
    text = str(exc).strip() or type(exc).__name__
    return text[:max_len]


# ============================================================
# VAST API
# ============================================================

_vast_request_lock = threading.Lock()
_last_vast_request_monotonic = 0.0


def _wait_for_vast_request_slot():
    """Rate-limit Vast requests without holding the mutex during sleep.

    Each caller reserves its own execution slot while the short critical
    section is protected by _vast_request_lock. The actual sleep happens
    outside the lock so Telegram callbacks and other workers do not queue
    behind a sleeping thread.
    """
    global _last_vast_request_monotonic
    with _vast_request_lock:
        now = time.monotonic()
        slot_at = max(now, _last_vast_request_monotonic + VAST_GET_MIN_INTERVAL)
        _last_vast_request_monotonic = slot_at
    wait_for = slot_at - now
    if wait_for > 0:
        time.sleep(wait_for)


def vast_request(
    method: str,
    path: str,
    *,
    params: Optional[dict] = None,
    json_body: Optional[dict] = None,
    timeout: int = 30,
    retries: Optional[int] = None,
):
    if retries is None:
        retries = VAST_MAX_RETRIES

    url = f"{VAST_BASE_URL.rstrip('/')}/{path.lstrip('/')}"
    last_exc = None

    for attempt in range(1, max(1, retries) + 1):
        try:
            _wait_for_vast_request_slot()
            response = VAST_SESSION.request(
                method=method.upper(),
                url=url,
                params=params or {},
                json=json_body,
                timeout=timeout,
            )

            if response.status_code == 429:
                retry_after = to_float(
                    response.headers.get("Retry-After"),
                    0.0,
                ) or 0.0
                if retry_after <= 0:
                    retry_after = max(1.5, VAST_GET_MIN_INTERVAL * attempt * 1.5)
                if attempt < max(1, retries):
                    logger.warning(
                        "Vast %s %s: HTTP 429 (попытка %s/%s), ждём %.1f сек",
                        method.upper(),
                        path,
                        attempt,
                        retries,
                        retry_after,
                    )
                    time.sleep(retry_after)
                    continue

            if not response.ok:
                body = ""
                try:
                    body = response.text.strip()
                except Exception:
                    body = ""
                if response.status_code == 400 and body:
                    raise requests.HTTPError(
                        f"HTTP 400 {method.upper()} {path}: {body[:1200]}",
                        response=response,
                    )
                response.raise_for_status()

            if not response.content:
                return {}
            return response.json()

        except Exception as exc:
            last_exc = exc
            if attempt >= max(1, retries):
                break
            if isinstance(exc, requests.HTTPError):
                response = getattr(exc, "response", None)
                if response is not None and response.status_code == 400:
                    break
            time.sleep(min(5.0, 0.75 * attempt))

    raise last_exc if last_exc else RuntimeError("Vast API request failed")


# ============================================================
# VAST OFFERS / INSTANCES CACHE
# ============================================================

_market_cache = {
    "slots": {
        "on-demand": {"time": 0.0, "offers": None},
        "interruptible": {"time": 0.0, "offers": None},
        "reserved": {"time": 0.0, "offers": None},
    }
}
_market_cache_lock = threading.Lock()
_market_fetch_locks = {
    "on-demand": threading.Lock(),
    "interruptible": threading.Lock(),
    "reserved": threading.Lock(),
}

_multigpu_cache = {
    "on-demand": {"time": 0.0, "offers": None},
    "interruptible": {"time": 0.0, "offers": None},
    "reserved": {"time": 0.0, "offers": None},
}
_multigpu_cache_lock = threading.Lock()

_instances_cache = {"time": 0.0, "instances": None}
_instances_cache_lock = threading.Lock()
_instances_fetch_lock = threading.Lock()

_account_cache = {"time": 0.0, "data": None}
_account_cache_lock = threading.Lock()


def invalidate_marketplace_cache():
    with _market_cache_lock:
        slots = _market_cache.get("slots", {})
        if isinstance(slots, dict):
            for slot in slots.values():
                if isinstance(slot, dict):
                    slot["time"] = 0.0
                    slot["offers"] = None
    with _multigpu_cache_lock:
        for slot in _multigpu_cache.values():
            slot["time"] = 0.0
            slot["offers"] = None


def _normalize_rent_mode(mode: str) -> str:
    value = str(mode or "on-demand").strip().lower()
    aliases = {
        "od": "on-demand",
        "on_demand": "on-demand",
        "spot": "interruptible",
        "bid": "interruptible",
        "reserved": "reserved",
    }
    return aliases.get(value, value)


def _build_offer_query(
    mode: str = "on-demand",
    *,
    min_gpu_count: Optional[int] = None,
    max_gpu_count: Optional[int] = None,
    order: Optional[list[list[str]]] = None,
    limit: Optional[int] = None,
    gpu_key: Optional[str] = None,
) -> dict:
    mode = _normalize_rent_mode(mode)
    if mode not in {"on-demand", "interruptible", "reserved"}:
        raise ValueError(f"Неизвестный режим аренды: {mode}")

    # Vast REST search API expects these exact type values.
    # The current API documentation uses:
    #   on-demand, bid, reserved
    # NOTE: the internal bot name remains "on-demand" for readability.
    api_type = {
        "on-demand": "on-demand",
        "interruptible": "bid",
        "reserved": "reserved",
    }[mode]
    sort_field = "min_bid" if mode == "interruptible" else "dph_total"

    query = {
        "limit": max(100, min(1000, int(limit if limit is not None else VAST_MARKETPLACE_LIMIT))),
        "rentable": {"eq": True},
        "rented": {"eq": False},
        "type": api_type,
        "order": order if order is not None else [[sort_field, "asc"]],
    }

    # Ask Vast for the GPU families that the bot can actually display.
    # Without this filter the API may return the first 100 cheapest offers
    # from other GPUs, and our local filter could then hide 5090/5080/4090,
    # etc. simply because they were outside that first page.
    # Vast can return the same GPU under several names, e.g. "RTX 5090"
    # and "GeForce RTX 5090".  Include every configured alias instead of
    # only the first display name, otherwise valid rigs can disappear from
    # the first API page.  For a GPU detail view, narrow the query to that
    # single model to save response size and latency.
    selected_keys = [gpu_key] if gpu_key else list(ALLOWED_GPUS)
    selected_keys = [key for key in selected_keys if key in GPU_ALIASES]
    enabled_gpu_names = []
    seen_gpu_names = set()
    for key in selected_keys:
        for name in GPU_ALIASES.get(key, []):
            normalized = str(name).strip()
            if normalized and normalized.lower() not in seen_gpu_names:
                seen_gpu_names.add(normalized.lower())
                enabled_gpu_names.append(normalized)
    if enabled_gpu_names:
        query["gpu_name"] = {"in": enabled_gpu_names}
    if VAST_REQUIRE_VERIFIED:
        query["verified"] = {"eq": True}
    if not VAST_EXTERNAL_ALLOWED:
        query["external"] = {"eq": False}
    if VAST_MIN_RELIABILITY > 0:
        query["reliability"] = {"gte": VAST_MIN_RELIABILITY}
    if VAST_MIN_CUDA > 0:
        query["cuda_max_good"] = {"gte": VAST_MIN_CUDA}
    if VAST_MIN_DISK_GB > 0:
        query["disk_space"] = {"gte": VAST_MIN_DISK_GB}
    if VAST_MIN_DIRECT_PORTS > 0:
        query["direct_port_count"] = {"gte": VAST_MIN_DIRECT_PORTS}

    # Keep the live marketplace focused on whole-rig configurations from
    # 1 through 8 GPUs.  The API still returns all allowed counts in this
    # range; the live UI then keeps the cheapest offer separately for each
    # GPU model + GPU count.
    effective_min = max(1, MARKETPLACE_MIN_GPU_COUNT if min_gpu_count is None else int(min_gpu_count))
    effective_max = max(effective_min, MARKETPLACE_MAX_GPU_COUNT if max_gpu_count is None else int(max_gpu_count))
    query["num_gpus"] = {
        "gte": effective_min,
        "lte": effective_max,
    }
    return query


def _extract_offers(data: Any) -> list[dict]:
    if isinstance(data, dict):
        rows = data.get("offers")
        if isinstance(rows, list):
            return [x for x in rows if isinstance(x, dict)]
        # Some API/tooling variants may return a single offer object.
        if isinstance(rows, dict):
            return [rows]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    return []


def _dedupe_offers(offers: list[dict]) -> list[dict]:
    """Merge offer lists without duplicate offer IDs."""
    seen = set()
    result = []
    for offer in offers:
        oid = offer_id(offer) if isinstance(offer, dict) else None
        key = ("id", oid) if oid is not None else ("obj", id(offer))
        if key in seen:
            continue
        seen.add(key)
        result.append(offer)
    return result


def _log_marketplace_gpu_counts(mode: str, offers: list[dict]) -> None:
    max_count = max(8, int(MARKETPLACE_MAX_GPU_COUNT))
    counts = {i: 0 for i in range(1, max_count + 1)}
    for offer in offers:
        count = get_gpu_count(offer)
        if count in counts:
            counts[count] += 1
    summary = " ".join(f"{i}x={counts[i]}" for i in range(1, max_count + 1) if counts[i])
    logger.info("Vast marketplace coverage: mode=%s, %s", mode, summary or "GPU-конфигураций нет")


def _sdk_gpu_token(name: str) -> str:
    """Convert a display GPU name to the token used by Vast SDK search queries."""
    value = re.sub(r"\s+", "_", str(name).strip())
    value = re.sub(r"[^A-Za-z0-9_\-]", "", value)
    return value

def _sdk_search(
    mode: str,
    *,
    min_gpu_count: int = 1,
    max_gpu_count: int = 8,
    limit: int = 500,
    gpu_name: Optional[str] = None,
    order: str = "dph_total",
) -> list[dict]:
    mode = _normalize_rent_mode(mode)
    api_type = {
        "on-demand": "on-demand",
        "interruptible": "bid",
    }.get(mode)
    if api_type is None:
        return []

    parts = [
        f"num_gpus>={max(1, int(min_gpu_count))}",
        f"num_gpus<={max(max(1, int(min_gpu_count)), int(max_gpu_count))}",
    ]
    if gpu_name:
        parts.append(f"gpu_name={_sdk_gpu_token(gpu_name)}")
    query = " ".join(parts)
    try:
        result = vast_sdk_call(
            "search_offers",
            query=query,
            type=api_type,
            order=order,
            limit=max(1, int(limit)),
            storage=max(1.0, float(VAST_DISK_GB)),
            no_default=False,
        )
        rows = result if isinstance(result, list) else _extract_offers(result)
        return [x for x in rows if isinstance(x, dict)]
    except Exception as exc:
        logger.error("Vast SDK search_offers error mode=%s query=%s: %s", mode, query, short_error(exc, 600))
        return []

def _sdk_offer_name_keys_present(offers: list[dict]) -> set[str]:
    found = set()
    for offer in offers:
        key = get_gpu_key(get_gpu_name(offer))
        if key:
            found.add(key)
    return found

def get_marketplace(mode: str = "on-demand", force_refresh: bool = False) -> list[dict]:
    mode = _normalize_rent_mode(mode)
    if mode not in {"on-demand", "interruptible"}:
        return []

    slot = _market_cache["slots"].setdefault(mode, {"time": 0.0, "offers": None})
    now = time.monotonic()
    with _market_cache_lock:
        cached = slot.get("offers")
        cached_at = float(slot.get("time", 0.0) or 0.0)
        if not force_refresh and cached is not None and now - cached_at < MARKETPLACE_CACHE_TTL:
            return list(cached)

    with _market_fetch_locks.setdefault(mode, threading.Lock()):
        now = time.monotonic()
        with _market_cache_lock:
            cached = slot.get("offers")
            cached_at = float(slot.get("time", 0.0) or 0.0)
            if not force_refresh and cached is not None and now - cached_at < MARKETPLACE_CACHE_TTL:
                return list(cached)

        primary = _sdk_search(
            mode,
            min_gpu_count=1,
            max_gpu_count=MARKETPLACE_MAX_GPU_COUNT,
            limit=VAST_MARKETPLACE_LIMIT,
            order="dph_total" if mode == "on-demand" else "min_bid",
        )

        multi = []
        with _multigpu_cache_lock:
            multi_cached = _multigpu_cache[mode].get("offers")
            multi_at = float(_multigpu_cache[mode].get("time", 0.0) or 0.0)
            multi_fresh = multi_cached is not None and now - multi_at < VAST_MULTIGPU_CACHE_TTL
        if multi_fresh and not force_refresh:
            multi = list(multi_cached or [])
        else:
            multi = _sdk_search(
                mode,
                min_gpu_count=2,
                max_gpu_count=MARKETPLACE_MAX_GPU_COUNT,
                limit=max(200, min(1000, VAST_MULTIGPU_QUERY_LIMIT)),
                order=("num_gpus", "dph_total"),
            )
            with _multigpu_cache_lock:
                _multigpu_cache[mode]["time"] = time.monotonic()
                _multigpu_cache[mode]["offers"] = list(multi)

        offers = _dedupe_offers(primary + multi)

        # Rescue only GPU families absent from the broad result. This fixes
        # names such as RTX 4070S Ti without making 11+ SDK requests every scan.
        present = _sdk_offer_name_keys_present(offers)
        enabled_keys = [k for k in get_enabled_gpus() if k in GPU_ALIASES]
        missing = [k for k in enabled_keys if k not in present]
        for key in missing[:4]:
            aliases = GPU_ALIASES.get(key, [])
            if not aliases:
                continue
            rescue_name = aliases[0]
            rescued = _sdk_search(
                mode,
                min_gpu_count=1,
                max_gpu_count=MARKETPLACE_MAX_GPU_COUNT,
                limit=min(100, VAST_MULTIGPU_QUERY_LIMIT),
                gpu_name=rescue_name,
                order="dph_total" if mode == "on-demand" else "min_bid",
            )
            offers = _dedupe_offers(offers + rescued)

        logger.info(
            "Vast SDK marketplace: mode=%s primary=%s multi=%s merged=%s rescued=%s",
            mode, len(primary), len(multi), len(offers), len(missing[:4]),
        )
        _log_marketplace_gpu_counts(mode, offers)

        with _market_cache_lock:
            slot["time"] = time.monotonic()
            slot["offers"] = list(offers)
        return offers


def get_instance_details(instance_id: int) -> dict:
    iid = int(instance_id)
    try:
        data = vast_sdk_call("show_instance", id=iid)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def get_instances(force_refresh: bool = False) -> list[dict]:
    now = time.monotonic()
    with _instances_cache_lock:
        cached = _instances_cache.get("instances")
        cached_at = float(_instances_cache.get("time", 0.0) or 0.0)
        if not force_refresh and cached is not None and now - cached_at < INSTANCES_CACHE_TTL:
            return list(cached)

    with _instances_fetch_lock:
        now = time.monotonic()
        with _instances_cache_lock:
            cached = _instances_cache.get("instances")
            cached_at = float(_instances_cache.get("time", 0.0) or 0.0)
            if not force_refresh and cached is not None and now - cached_at < INSTANCES_CACHE_TTL:
                return list(cached)
        try:
            data = vast_sdk_call("show_instances")
            rows = data if isinstance(data, list) else _extract_offers(data)
            instances = [x for x in rows if isinstance(x, dict)]
        except Exception as exc:
            logger.error("Ошибка Vast SDK instances: %s", exc)
            raise
        with _instances_cache_lock:
            _instances_cache["time"] = time.monotonic()
            _instances_cache["instances"] = list(instances)
        return instances


def get_account(force_refresh: bool = False) -> dict:
    now = time.monotonic()
    with _account_cache_lock:
        cached = _account_cache.get("data")
        cached_at = float(_account_cache.get("time", 0.0) or 0.0)
        if (
            not force_refresh
            and cached is not None
            and now - cached_at < ACCOUNT_STATS_CACHE_TTL
        ):
            return dict(cached)

    try:
        data = vast_request("GET", "/users/current", params={"owner": "me"})
        if not isinstance(data, dict):
            data = {}
    except Exception as exc:
        logger.error("Ошибка Vast account: %s", exc)
        data = {"error": str(exc)}

    with _account_cache_lock:
        _account_cache["time"] = time.monotonic()
        _account_cache["data"] = dict(data)
    return dict(data)


# ============================================================
# VAST NORMALIZATION
# ============================================================

ACTIVE_INSTANCE_STATUSES = {
    None,
    "created",
    "loading",
    "running",
    "frozen",
    "rebooting",
    "unknown",
    "offline",
}


def instance_status(instance: dict) -> Optional[str]:
    value = instance.get("actual_status")
    if value is None:
        return None
    return str(value).strip().lower()


def is_instance_active(instance: dict) -> bool:
    return instance_status(instance) in ACTIVE_INSTANCE_STATUSES


def get_instance_id(instance: dict) -> Optional[int]:
    return to_int(instance.get("id"))


def get_machine_id(instance_or_offer: dict) -> Optional[int]:
    return to_int(
        get_value(instance_or_offer, "machine_id", "machine_id_int", default=None)
    )


def get_gpu_name(obj: dict) -> str:
    value = get_value(
        obj,
        "gpu_name",
        "gpu",
        "gpu_model",
        default="",
    )
    return str(value or "")


def safe_gpu_count(value: Any, default: int = 1) -> int:
    """Return a positive GPU count even when API data is malformed."""
    try:
        count = int(value)
    except (TypeError, ValueError):
        count = int(default)
    return max(1, count)


def get_gpu_count(obj: dict) -> int:
    for key in ("num_gpus", "gpu_count", "gpus_count"):
        value = to_int(obj.get(key), None)
        if value is not None:
            return safe_gpu_count(value)

    gpu_name = get_gpu_name(obj)
    match = re.match(r"\s*(\d+)\s*[x×]\b", gpu_name, flags=re.IGNORECASE)
    if match:
        return safe_gpu_count(match.group(1))
    return 1


def get_gpu_key(gpu_name: str) -> Optional[str]:
    text = str(gpu_name or "").strip()
    if not text:
        return None

    lowered = text.lower()
    if any(excluded in lowered for excluded in EXCLUDED_GPU_NAMES_LOWER):
        return None

    match = GPU_ALIAS_PATTERN.search(text)
    if match is None:
        return None
    return GPU_ALIAS_LOOKUP.get(match.group(0).lower())


def get_enabled_gpus() -> tuple[str, ...]:
    with state_lock:
        raw = state.get("gpu_filter_enabled", [])
        enabled = {str(x) for x in raw} if isinstance(raw, list) else set()
    return tuple(key for key in ALLOWED_GPUS if key in enabled and key in GPU_ALIASES)


def set_enabled_gpus(gpu_keys) -> list[str]:
    allowed = set(ALLOWED_GPUS) & set(GPU_ALIASES)
    normalized = []
    for gpu_key in gpu_keys:
        key = str(gpu_key).strip()
        if key in allowed and key not in normalized:
            normalized.append(key)
    with state_lock:
        state["gpu_filter_enabled"] = normalized
    save_state()
    logger.info("GPU-фильтр установлен: %s", ", ".join(normalized) if normalized else "ВЫКЛЮЧЕН")
    return normalized


def toggle_gpu_filter(gpu_key: str) -> bool:
    key = str(gpu_key).strip()
    if key not in ALLOWED_GPUS or key not in GPU_ALIASES:
        raise ValueError("Неизвестная GPU")
    with state_lock:
        raw = state.get("gpu_filter_enabled", [])
        enabled = set(raw if isinstance(raw, list) else [])
        if key in enabled:
            enabled.remove(key)
            selected = False
        else:
            enabled.add(key)
            selected = True
        state["gpu_filter_enabled"] = [x for x in ALLOWED_GPUS if x in enabled]
    save_state()
    logger.info("GPU-фильтр %s: %s", key, "ON" if selected else "OFF")
    return selected


def gpu_matches(gpu_name: str) -> bool:
    key = get_gpu_key(gpu_name)
    return key is not None and key in ALLOWED_GPU_KEYS and key in set(get_enabled_gpus())


def offer_id(offer: dict) -> Optional[int]:
    return to_int(offer.get("id"))


def offer_rentable(offer: dict) -> bool:
    return boolish(offer.get("rentable", True))


def offer_gpu_price_hour(offer: dict, mode: str = "on-demand") -> Optional[float]:
    """Return GPU-only hourly cost when Vast includes a component breakdown.

    For ON-DEMAND/RESERVED, prefer the documented ``search.gpuCostPerHour``
    or ``instance.gpuCostPerHour`` component so disk is not mixed into the
    per-GPU price. For BID, Vast exposes the bid floor as ``min_bid``; that
    value is the hourly bid basis used by this bot and is divided by GPU count
    when displayed per GPU.
    """
    mode = _normalize_rent_mode(mode)
    if mode == "interruptible":
        value = to_float(offer.get("min_bid"), None)
        if value is not None and value >= 0:
            return value
        return None

    for container_name in ("search", "instance"):
        container = offer.get(container_name)
        if isinstance(container, dict):
            for key in ("gpuCostPerHour", "gpu_cost_per_hour", "gpu_hourly"):
                value = to_float(container.get(key), None)
                if value is not None and value >= 0:
                    return value

    for key in ("gpuCostPerHour", "gpu_cost_per_hour", "gpu_hourly", "gpu_price_hour"):
        value = to_float(offer.get(key), None)
        if value is not None and value >= 0:
            return value

    # Some bundle payloads expose only dph_total. Keep the marketplace visible
    # instead of replacing every price with '?'. The caller will divide this
    # total hourly offer price by GPU count when displaying per-GPU pricing.
    fallback = to_float(offer.get("dph_total"), None)
    if fallback is not None and fallback >= 0:
        return fallback

    return None


def offer_price_hour(offer: dict, mode: str = "on-demand") -> Optional[float]:
    mode = _normalize_rent_mode(mode)
    if mode == "interruptible":
        keys = ("min_bid",)
    elif mode == "reserved":
        keys = ("discounted_hourly", "discounted_dph_total", "dph_total")
    else:
        keys = ("dph_total",)

    for key in keys:
        value = to_float(offer.get(key), None)
        if value is not None and value >= 0:
            return value
    return None


def price_daily(total_hourly: float) -> float:
    return float(total_hourly) * 24.0


def per_gpu_daily(total_hourly: float, gpu_count: int) -> float:
    """Convert hourly total to daily price for one GPU safely."""
    try:
        hourly = float(total_hourly)
    except (TypeError, ValueError):
        return 0.0
    return price_daily(hourly) / safe_gpu_count(gpu_count)


def machine_is_blacklisted(machine_id: Optional[int]) -> bool:
    if machine_id is None:
        return False
    with state_lock:
        return machine_id in blacklist_set


def offer_is_candidate(
    offer: dict,
    mode: str = "on-demand",
    *,
    blacklist_snapshot: Optional[set[int]] = None,
    rented_snapshot: Optional[set[int]] = None,
    price_ranges: Optional[dict] = None,
    enabled_gpus: Optional[set[str]] = None,
) -> bool:
    """Fast local validation; optional snapshots avoid repeated state locks."""
    mode = _normalize_rent_mode(mode)
    oid = offer_id(offer)
    if oid is None or not offer_rentable(offer):
        return False

    machine_id = get_machine_id(offer)
    if blacklist_snapshot is None or rented_snapshot is None:
        blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()

    if machine_id is not None and (
        machine_id in blacklist_snapshot or machine_id in rented_snapshot
    ):
        return False

    gpu_name = get_gpu_name(offer)
    gpu_key = get_gpu_key(gpu_name)
    if gpu_key is None or gpu_key not in ALLOWED_GPU_KEYS:
        return False
    if enabled_gpus is None:
        enabled_gpus = set(get_enabled_gpus())
    if gpu_key not in enabled_gpus:
        return False

    count = get_gpu_count(offer)
    if count < 1:
        return False
    if mode == "on-demand" and count > 10:
        return False

    # Auto-rental filtering must use the same GPU-only hourly component that
    # the live marketplace displays. Using dph_total here can include disk
    # cost and make a valid GPU fail the configured per-GPU price range.
    hourly_gpu = offer_gpu_price_hour(offer, mode=mode)
    if hourly_gpu is None:
        return False

    # The global min/max switches are total-server daily guardrails. When the
    # API only exposes the GPU component, use the GPU component multiplied by
    # GPU count for this guardrail; the per-GPU range below remains authoritative.
    count = safe_gpu_count(get_gpu_count(offer))
    daily_total = price_daily(hourly_gpu) * count
    daily_limits = {
        "on-demand": (MIN_ON_DEMAND_DAILY, MAX_ON_DEMAND_DAILY),
        "interruptible": (MIN_SPOT_DAILY, MAX_SPOT_DAILY),
        "reserved": (MIN_RESERVED_DAILY, MAX_RESERVED_DAILY),
    }
    min_daily, max_daily = daily_limits[mode]
    if not (min_daily <= daily_total <= max_daily):
        return False

    if price_ranges is None:
        price_ranges = get_auto_price_ranges_snapshot(mode=mode)
    limits = price_ranges.get(gpu_key)
    if limits is None:
        return False
    per_gpu = price_daily(hourly_gpu)
    return limits[0] <= per_gpu <= limits[1]


# ============================================================
# PRICE RANGE STATE
# ============================================================

def get_auto_price_ranges_snapshot(mode: Optional[str] = None) -> dict:
    if mode is not None:
        mode = _normalize_rent_mode(mode)
    with state_lock:
        saved = state.get("auto_gpu_price_daily_ranges")
        saved = saved if isinstance(saved, dict) else {}
        result = {}
        for gpu_key in ALLOWED_GPUS:
            base = GPU_PRICE_DAILY_RANGES.get(gpu_key)
            values = saved.get(gpu_key)
            if isinstance(values, dict):
                if mode is not None:
                    pair = values.get(mode)
                    if isinstance(pair, (list, tuple)) and len(pair) == 2:
                        try:
                            result[gpu_key] = (float(pair[0]), float(pair[1]))
                            continue
                        except (TypeError, ValueError):
                            pass
                else:
                    result[gpu_key] = {
                        m: (float(pair[0]), float(pair[1]))
                        for m, pair in values.items()
                        if isinstance(pair, (list, tuple)) and len(pair) == 2
                    }
                    if result[gpu_key]:
                        continue
            elif mode is None and isinstance(values, (list, tuple)) and len(values) == 2:
                try:
                    result[gpu_key] = {
                        m: (float(values[0]), float(values[1]))
                        for m in ("on-demand", "interruptible", "reserved")
                    }
                    continue
                except (TypeError, ValueError):
                    pass

            if base is not None and mode is not None:
                result[gpu_key] = (float(base[0]), float(base[1]))
            elif base is not None:
                result[gpu_key] = {
                    m: (float(base[0]), float(base[1]))
                    for m in ("on-demand", "interruptible", "reserved")
                }
    return result


def get_auto_gpu_price_range(gpu_key: str, mode: str = "on-demand"):
    mode = _normalize_rent_mode(mode)
    return get_auto_price_ranges_snapshot(mode=mode).get(gpu_key)


def set_auto_gpu_price_range(gpu_key: str, min_price: float, max_price: float, mode: str = "on-demand"):
    mode = _normalize_rent_mode(mode)
    min_price = round(max(0.0, float(min_price)), 2)
    max_price = round(max(0.0, float(max_price)), 2)
    if min_price > max_price:
        raise ValueError("Минимальная цена не может быть выше максимальной")
    with state_lock:
        ranges = state.setdefault("auto_gpu_price_daily_ranges", {})
        entry = ranges.setdefault(gpu_key, {})
        if not isinstance(entry, dict):
            entry = {
                m: [min_price, max_price]
                for m in ("on-demand", "interruptible", "reserved")
            }
            ranges[gpu_key] = entry
        entry[mode] = [min_price, max_price]
    save_state()


def adjust_auto_gpu_price(gpu_key: str, which: str, delta: float, mode: str = "on-demand"):
    current = get_auto_gpu_price_range(gpu_key, mode=mode)
    if current is None:
        raise ValueError("Для этой GPU нет цены автоаренды")
    min_price, max_price = current
    delta = round(float(delta), 2)
    if which == "min":
        candidate = max(0.0, round(min_price + delta, 2))
        if candidate > max_price:
            raise ValueError("Минимальная цена не может быть выше максимальной")
        min_price = candidate
    elif which == "max":
        candidate = max(0.0, round(max_price + delta, 2))
        if candidate < min_price:
            raise ValueError("Максимальная цена не может быть ниже минимальной")
        max_price = candidate
    else:
        raise ValueError("Неизвестный параметр цены")
    set_auto_gpu_price_range(gpu_key, min_price, max_price, mode=mode)
    return min_price, max_price


# ============================================================
# BLACKLIST / RENTED STATE
# ============================================================

def ban_machine(machine_id: int):
    machine_id = int(machine_id)
    with state_lock:
        if machine_id not in blacklist_set:
            blacklist_set.add(machine_id)
            state["blacklist"] = sorted(blacklist_set)
    save_state()
    logger.info("🚫 Vast machine %s добавлен в blacklist", machine_id)


def unban_machine(machine_id: int) -> tuple[bool, str]:
    machine_id = int(machine_id)
    with state_lock:
        if machine_id in BANNED_MACHINE_IDS:
            return False, "Этот machine ID закреплён в постоянном blacklist."
        if machine_id not in blacklist_set:
            return False, "Machine ID отсутствует в blacklist."
        blacklist_set.remove(machine_id)
        state["blacklist"] = sorted(blacklist_set)
    save_state()
    logger.info("🔓 Vast machine %s удалён из blacklist", machine_id)
    return True, "OK"


def get_scan_state_snapshot():
    with state_lock:
        return set(blacklist_set), set(rented_machine_set)


# ============================================================
# INTERRUPTIBLE / BID TRACKING
# ============================================================

def is_bid_instance(instance: dict) -> bool:
    # Vast's instance payload normally exposes is_bid, but a tracked BID
    # contract remains a BID for our purposes even if that flag temporarily
    # disappears/changes while the instance is being preempted.
    iid = get_instance_id(instance)
    if iid is not None:
        with state_lock:
            if str(iid) in state.get("bid_tracking", {}):
                return True
    return boolish(instance.get("is_bid", False))


def _state_instance_key(instance_id: Any) -> str:
    """Canonical JSON-state key for a Vast instance id."""
    try:
        return str(int(instance_id))
    except (TypeError, ValueError):
        return str(instance_id).strip()


def get_tracked_bid(instance_id: int) -> Optional[float]:
    iid = _state_instance_key(instance_id)
    with state_lock:
        item = state.get("bid_tracking", {}).get(iid)
        if not isinstance(item, dict):
            return None
        return to_float(item.get("bid"), None)


def track_bid_instance(
    instance_id: int,
    bid: float,
    machine_id: Optional[int] = None,
    gpu_name: str = "",
):
    iid = _state_instance_key(instance_id)
    bid = round(float(bid), 2)
    with state_lock:
        tracking = state.setdefault("bid_tracking", {})
        tracking[iid] = {
            "bid": bid,
            "machine_id": int(machine_id) if machine_id is not None else None,
            "gpu_name": str(gpu_name or ""),
        }
        # A successful new bid means that an earlier outbid notification is
        # no longer relevant. The next real outbid will trigger a new alert.
        state.setdefault("bid_outbid_notifications", {})[iid] = {
            "notified": False,
            "last_ts": 0.0,
        }
    save_state()


def _clear_bid_tracking_for_missing_instances(instances: list[dict]):
    known_ids = {
        str(iid)
        for iid in (get_instance_id(x) for x in instances)
        if iid is not None
    }
    changed = False
    with state_lock:
        tracking = state.setdefault("bid_tracking", {})
        notifications = state.setdefault("bid_outbid_notifications", {})
        for iid in list(tracking):
            if iid not in known_ids:
                tracking.pop(iid, None)
                notifications.pop(iid, None)
                changed = True
    if changed:
        save_state()


def change_vast_bid(instance_id: int, new_bid: float) -> dict:
    """Change an interruptible instance bid using Vast's REST endpoint."""
    instance_id = int(instance_id)
    new_bid = round(float(new_bid), 2)
    if new_bid < 0.10:
        raise ValueError("Ставка должна быть не меньше $0.10/ч")
    if new_bid > 32.0:
        raise ValueError("Ставка не может быть выше $32/ч")

    with _bid_change_lock:
        current = get_tracked_bid(instance_id)
        if current is None:
            raise RuntimeError(
                "Текущая ставка этого instance не сохранена ботом. "
                "Создай/измени ставку через этот бот, чтобы включить управление."
            )

        try:
            data = vast_sdk_call("change_bid", id=instance_id, price=new_bid)
        except Exception as exc:
            raise RuntimeError(f"Vast не принял новую ставку: {short_error(exc, 700)}") from exc
        if not isinstance(data, dict):
            raise RuntimeError(f"Vast не принял новую ставку: {data}")

        iid = _state_instance_key(instance_id)
        with state_lock:
            state.setdefault("bid_tracking", {})[iid]["bid"] = new_bid
            state.setdefault("bid_outbid_notifications", {})[iid] = {
                "notified": False,
                "last_ts": 0.0,
            }
        save_state()

        with _instances_cache_lock:
            _instances_cache["time"] = 0.0
            _instances_cache["instances"] = None

        logger.info(
            "💰 Vast bid изменён: instance_id=%s %.2f -> %.2f $/ч",
            instance_id,
            current,
            new_bid,
        )
        return data


def build_bid_control_keyboard(instance_id: int):
    return {
        "inline_keyboard": [
            [{
                "text": f"⬆️ ПЕРЕБИТЬ +${BID_RAISE_STEP:.2f}",
                "callback_data": f"bid_raise:{int(instance_id)}",
            }],
            [{
                "text": "🔄 Обновить ставку",
                "callback_data": f"bid_show:{int(instance_id)}",
            }],
        ]
    }


def get_bid_instance_summary(instance_id: int) -> Optional[str]:
    """Read one instance and return a compact bid-control message."""
    instances = get_instances(force_refresh=True)
    iid = int(instance_id)
    instance = next((x for x in instances if get_instance_id(x) == iid), None)
    if instance is None:
        return None

    # Do not rely only on Vast's is_bid flag here: our own bid_tracking is the
    # authoritative record for instances created through this bot.
    with state_lock:
        tracked = str(iid) in state.get("bid_tracking", {})
    if not is_bid_instance(instance) and not tracked:
        return "❌ Этот instance не является INTERRUPTIBLE/BID."

    own = get_tracked_bid(iid)
    min_bid = to_float(instance.get("min_bid"), None)
    status = str(instance.get("actual_status", "unknown"))
    gpu = html.escape(get_gpu_name(instance) or "Unknown GPU")
    gpu_count = safe_gpu_count(get_gpu_count(instance))

    lines = [
        "💰 <b>Управление ставкой</b>",
        "",
        f"GPU: <code>{gpu}</code> × <code>{gpu_count}</code>",
        f"Instance: <code>{iid}</code>",
        f"Статус: <code>{html.escape(status)}</code>",
    ]
    if own is not None:
        own_daily_per_gpu = own * 24.0 / gpu_count
        lines.append(f"Моя ставка: <code>${own:.2f}/ч</code> · <code>${own_daily_per_gpu:.4f}/24ч на GPU</code>")
    if min_bid is not None:
        min_daily_per_gpu = min_bid * 24.0 / gpu_count
        lines.append(f"Текущий минимум: <code>${min_bid:.2f}/ч</code> · <code>${min_daily_per_gpu:.4f}/24ч на GPU</code>")
    if own is not None and min_bid is not None and min_bid > own + 1e-9:
        lines.append("⚠️ <b>Твоя ставка перебита.</b>")
        lines.append(f"Нужно поднять ставку минимум до <code>${min_bid:.2f}/ч</code>.")
    return "\n".join(lines)


def check_interruptible_bid_status():
    """Detect outbid BID contracts and notify Telegram with a raise button.

    Important: iterate over every instance we track as a BID contract instead
    of filtering only on Vast's is_bid field. During preemption Vast can change
    transient status/flags; our saved bid_tracking record remains authoritative.
    """
    with state_lock:
        tracked_ids = [
            _state_instance_key(k) for k, v in list(state.get("bid_tracking", {}).items())
            if isinstance(v, dict)
        ]
    if not tracked_ids:
        return

    try:
        instances = get_instances(force_refresh=False)
    except Exception as exc:
        logger.warning("Не удалось проверить INTERRUPTIBLE ставки: %s", exc)
        return

    by_id = {}
    for instance in instances:
        iid = get_instance_id(instance)
        if iid is not None:
            by_id[str(iid)] = instance

    now = time.time()

    with state_lock:
        tracking_snapshot = {
            str(k): dict(v)
            for k, v in state.get("bid_tracking", {}).items()
            if isinstance(v, dict)
        }
        notification_snapshot = {
            str(k): dict(v) if isinstance(v, dict) else {}
            for k, v in state.get("bid_outbid_notifications", {}).items()
        }

    changed = False

    # Do NOT delete tracking merely because an instance temporarily vanished
    # from the list during a Vast state transition. The next polling pass may
    # bring it back. Only a long-lived disappearance is handled elsewhere.
    for iid_key in tracked_ids:
        instance = by_id.get(iid_key)
        if instance is None:
            continue

        iid = int(iid_key)
        track = tracking_snapshot.get(iid_key)
        if not track:
            continue

        own_bid = to_float(track.get("bid"), None)
        min_bid = to_float(instance.get("min_bid"), None)
        status = instance_status(instance) or "unknown"

        if own_bid is None or min_bid is None:
            # Keep a diagnostic in the log so we can see Vast's actual payload
            # if a future API version moves the current bid floor to another key.
            logger.debug(
                "BID check instance=%s: own_bid=%r min_bid=%r is_bid=%r status=%s",
                iid,
                own_bid,
                min_bid,
                instance.get("is_bid"),
                status,
            )
            continue

        outbid = min_bid > own_bid + 1e-9
        if not outbid:
            # A recovered bid starts a new notification cycle.
            current_meta = notification_snapshot.get(iid_key, {})
            if bool(current_meta.get("notified", False)) or float(current_meta.get("last_ts", 0.0) or 0.0) != 0.0:
                with state_lock:
                    state.setdefault("bid_outbid_notifications", {})[iid_key] = {
                        "notified": False,
                        "last_ts": 0.0,
                    }
                changed = True
            continue

        meta = notification_snapshot.get(iid_key, {})
        already_notified = bool(meta.get("notified", False))
        last_ts = to_float(meta.get("last_ts"), 0.0) or 0.0
        if already_notified:
            # One message per outbid event. Once the user raises the bid and
            # Vast reports min_bid <= own_bid, the state resets above.
            continue
        if last_ts > 0 and now - last_ts < BID_OUTBID_NOTIFY_COOLDOWN:
            continue

        gpu = html.escape(get_gpu_name(instance) or track.get("gpu_name") or "Unknown GPU")
        gpu_count = safe_gpu_count(get_gpu_count(instance))
        own_daily_per_gpu = own_bid * 24.0 / gpu_count
        min_daily_per_gpu = min_bid * 24.0 / gpu_count

        message = (
            "⚠️ <b>ТВОЯ СТАВКА ПЕРЕБИТА</b>\n\n"
            f"GPU: <code>{gpu}</code> × <code>{gpu_count}</code>\n"
            f"Instance ID: <code>{iid}</code>\n"
            f"Статус: <code>{html.escape(status)}</code>\n\n"
            f"Твоя ставка: <code>${own_bid:.4f}/ч</code>\n"
            f"За 1 GPU: <code>${own_daily_per_gpu:.4f}/24ч</code>\n"
            f"Текущий минимум: <code>${min_bid:.4f}/ч</code>\n"
            f"Минимум за 1 GPU: <code>${min_daily_per_gpu:.4f}/24ч</code>\n\n"
            f"Нажми кнопку <b>ПЕРЕБИТЬ +${BID_RAISE_STEP:.2f}</b>."
        )

        result = send_message(message, build_bid_control_keyboard(iid))
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state.setdefault("bid_outbid_notifications", {})[iid_key] = {
                    "notified": True,
                    "last_ts": now,
                }
            changed = True
            logger.warning(
                "⚠️ INTERRUPTIBLE bid перебит: instance=%s моя=%.4f минимум=%.4f $/ч status=%s",
                iid,
                own_bid,
                min_bid,
                status,
            )
        else:
            logger.warning(
                "⚠️ Не удалось отправить уведомление о перебитой BID: instance=%s",
                iid,
            )

    if changed:
        save_state()


# ============================================================
# ACTIVE INSTANCE LIMIT / PAUSE
# ============================================================

_active_instance_sync_cache = {"time": 0.0, "instance_ids": None, "machine_ids": None}
_active_instance_sync_lock = threading.Lock()
_active_instance_sync_ready = False


def refresh_active_rented_state(force_refresh: bool = False) -> bool:
    """Synchronize active Vast instances.

    A failed synchronization never becomes zero. New rentals are blocked until
    Vast confirms the real account state.
    """
    global _active_instance_sync_ready

    now = time.monotonic()
    with _active_instance_sync_lock:
        cached_ids = _active_instance_sync_cache.get("instance_ids")
        cached_at = float(_active_instance_sync_cache.get("time", 0.0) or 0.0)
        if (
            not force_refresh
            and cached_ids is not None
            and now - cached_at < ACTIVE_INSTANCE_SYNC_TTL
        ):
            _active_instance_sync_ready = True
            return True

    try:
        instances = get_instances(force_refresh=force_refresh)
    except Exception as exc:
        _active_instance_sync_ready = False
        logger.error("❌ Не удалось синхронизировать активные инстансы Vast.ai: %s", exc)
        logger.error("⛔ Новые аренды заблокированы до успешной синхронизации Vast.")
        return False

    active_instances = [x for x in instances if is_instance_active(x)]
    active_instance_ids = {
        iid for iid in (get_instance_id(x) for x in active_instances) if iid is not None
    }
    active_machine_ids = {
        mid for mid in (get_machine_id(x) for x in active_instances) if mid is not None
    }

    with state_lock:
        old_instance_ids = set(rented_instance_set)
        old_machine_ids = set(rented_machine_set)
        rented_instance_set.clear()
        rented_instance_set.update(active_instance_ids)
        rented_machine_set.clear()
        rented_machine_set.update(active_machine_ids)
        state["instance_ids"] = sorted(active_instance_ids)
        state["rented"] = sorted(active_machine_ids)

    with _active_instance_sync_lock:
        _active_instance_sync_cache["time"] = time.monotonic()
        _active_instance_sync_cache["instance_ids"] = set(active_instance_ids)
        _active_instance_sync_cache["machine_ids"] = set(active_machine_ids)

    _active_instance_sync_ready = True

    if old_instance_ids != active_instance_ids or old_machine_ids != active_machine_ids:
        save_state()

    logger.info("📦 Vast.ai подтверждает активных ригов: %s", len(active_instance_ids))
    return True


def get_active_rental_count() -> int:
    with state_lock:
        return len(rented_instance_set)


def get_max_active_rigs() -> int:
    with state_lock:
        try:
            value = int(state.get("max_active_rigs", 4))
        except (TypeError, ValueError):
            value = 20
        return max(1, min(100, value))


def has_active_rental_capacity(*, log: bool = False) -> bool:
    if not refresh_active_rented_state(force_refresh=False):
        if log:
            logger.warning("⛔ Лимит не подтвержден Vast. Новая аренда запрещена.")
        return False

    with _active_instance_sync_lock:
        if not _active_instance_sync_ready:
            return False

    active = get_active_rental_count()
    limit = get_max_active_rigs()
    if active >= limit:
        if log:
            logger.info("⛔ Лимит активных ригов достигнут: %s/%s", active, limit)
        return False

    if log:
        logger.info("✅ Есть место по лимиту: %s/%s", active, limit)
    return True


def set_max_active_rigs(limit: int):
    limit = int(limit)
    if limit < 1 or limit > 100:
        raise ValueError("Лимит активных ригов должен быть от 1 до 100")
    with state_lock:
        state["max_active_rigs"] = limit
    save_state()
    logger.info("Лимит активных ригов установлен: %s", limit)


def adjust_max_active_rigs(delta: int) -> int:
    current = get_max_active_rigs()
    new_limit = max(1, min(100, current + int(delta)))
    set_max_active_rigs(new_limit)
    return new_limit


def notify_active_rental_limit(mode: str = "ON-DEMAND", machine_id: Optional[int] = None) -> bool:
    now = time.time()
    with _limit_error_notify_lock:
        with state_lock:
            last_sent = to_float(state.get("last_limit_error_notify_ts"), 0.0) or 0.0
        elapsed = now - last_sent
        if last_sent > 0 and elapsed < LIMIT_ERROR_NOTIFY_INTERVAL:
            logger.info(
                "Telegram лимит-уведомление подавлено: %.0f/%.0f сек",
                elapsed,
                LIMIT_ERROR_NOTIFY_INTERVAL,
            )
            return False

        active = get_active_rental_count()
        limit = get_max_active_rigs()
        extra = (
            f"\nПоследняя попытка: machine <code>{machine_id}</code>"
            if machine_id is not None else ""
        )
        result = send_message(
            "⛔ <b>Достигнут лимит активных ригов</b>\n\n"
            f"Активно: <code>{active}/{limit}</code>\n"
            f"Новая {html.escape(mode)} аренда сейчас не создаётся."
            f"{extra}\n\n"
            "Автоаренда поставлена на паузу до освобождения слота "
            "или увеличения лимита."
        )
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state["last_limit_error_notify_ts"] = now
            save_state()
            return True
        return False


def _active_limit_gate_allows_marketplace() -> bool:
    """Pause marketplace scanning while the active-rig cap is full.

    The bot only polls active Vast instances until the count falls below the
    cap or the configured limit is raised. This reproduces the working Clore
    behavior without hammering the offer endpoint while full.
    """
    global _active_limit_pause, _active_limit_pause_active, _active_limit_pause_limit

    active = get_active_rental_count()
    limit = get_max_active_rigs()

    with _active_limit_pause_lock:
        was_paused = _active_limit_pause
        paused_active = _active_limit_pause_active
        paused_limit = _active_limit_pause_limit

        if active >= limit:
            if not was_paused:
                _active_limit_pause = True
                _active_limit_pause_active = active
                _active_limit_pause_limit = limit
                logger.info(
                    "⏸️ Автоаренда поставлена на паузу: достигнут лимит %s/%s. "
                    "Marketplace больше не сканируется до изменения состояния.",
                    active,
                    limit,
                )
                notify_active_rental_limit(mode="AUTO")
            elif paused_active != active or paused_limit != limit:
                _active_limit_pause_active = active
                _active_limit_pause_limit = limit
                logger.info(
                    "⏸️ Лимит всё ещё заполнен: %s/%s → %s/%s. Остаёмся на паузе.",
                    paused_active,
                    paused_limit,
                    active,
                    limit,
                )
            return False

        if was_paused:
            logger.info(
                "▶️ Лимит освободился или был увеличен: %s/%s "
                "(пауза была %s/%s). Возобновляю marketplace и автоаренду.",
                active,
                limit,
                paused_active,
                paused_limit,
            )
            _active_limit_pause = False
            _active_limit_pause_active = None
            _active_limit_pause_limit = None

        return True


# ============================================================
# OFFER / INSTANCE DISPLAY
# ============================================================

def fmt_price(value: Optional[float]) -> str:
    if value is None:
        return "нет данных"
    return f"${float(value):.4f}"


def format_offer(offer: dict, mode: str = "on-demand") -> str:
    gpu = html.escape(get_gpu_name(offer) or "Unknown GPU")
    count = max(1, get_gpu_count(offer))
    oid = offer_id(offer)
    machine_id = get_machine_id(offer)
    mode = _normalize_rent_mode(mode)
    total_hourly = offer_price_hour(offer, mode=mode)
    total_daily = price_daily(total_hourly) if total_hourly is not None else None
    total_per_gpu_daily = per_gpu_daily(total_hourly, count) if total_hourly is not None else None
    gpu_hourly = offer_gpu_price_hour(offer, mode=mode)
    gpu_daily = per_gpu_daily(gpu_hourly, count) if gpu_hourly is not None else None
    reliability = to_float(offer.get("reliability"), None)
    location = html.escape(str(offer.get("geolocation", offer.get("location", "")) or ""))

    lines = [
        f"🖥 <b>{gpu}</b>",
        f"Offer ID: <code>{oid if oid is not None else '?'}</code>",
        f"Machine ID: <code>{machine_id if machine_id is not None else '?'}</code>",
        f"GPU count: <code>{count}</code>",
        f"Тип: <code>{mode.upper()}</code>",
    ]

    if gpu_daily is not None:
        lines.append(f"GPU: <code>{fmt_price(gpu_daily)}/24ч</code> на 1 карту")
        lines.append(f"GPU: <code>{fmt_price(gpu_hourly)}/ч</code> на 1 карту")
    elif total_per_gpu_daily is not None:
        lines.append(
            f"Цена 1 GPU: <code>{fmt_price(total_per_gpu_daily)}/24ч</code> "
            "(fallback, включая общую стоимость offer)"
        )

    if total_daily is not None:
        lines.append(f"Всего за server: <code>{fmt_price(total_daily)}/24ч</code>")
        lines.append(f"Всего за server: <code>{fmt_price(total_hourly)}/ч</code>")

    disk_hour = None
    for container_name in ("search", "instance"):
        container = offer.get(container_name)
        if isinstance(container, dict):
            for key in ("diskHour", "disk_hour"):
                disk_hour = to_float(container.get(key), None)
                if disk_hour is not None:
                    break
        if disk_hour is not None:
            break
    if disk_hour is None:
        disk_hour = to_float(offer.get("storage_cost"), None)
    if disk_hour is not None:
        lines.append(f"Disk: <code>{fmt_price(price_daily(disk_hour))}/24ч</code>")

    if mode == "interruptible":
        min_bid = to_float(offer.get("min_bid"), None)
        if min_bid is not None:
            lines.append(
                f"Минимальная ставка: <code>{fmt_price(price_daily(min_bid))}/24ч</code> "
                f"на server"
            )

    if reliability is not None:
        lines.append(f"Reliability: <code>{reliability:.3f}</code>")
    if location:
        lines.append(f"Location: <code>{location}</code>")
    return "\n".join(lines)


def format_instance(instance: dict) -> str:
    gpu = html.escape(get_gpu_name(instance) or "Unknown GPU")
    iid = get_instance_id(instance)
    machine_id = get_machine_id(instance)
    count = get_gpu_count(instance)
    status = html.escape(str(instance.get("actual_status", "unknown")))
    dph = to_float(instance.get("dph_total"), None)
    daily = price_daily(dph) if dph is not None else None
    label = html.escape(str(instance.get("label", "") or ""))
    lines = [
        f"🖥 <b>{gpu}</b>",
        f"Instance: <code>{iid if iid is not None else '?'}</code>",
        f"Machine: <code>{machine_id if machine_id is not None else '?'}</code>",
        f"GPU count: <code>{count}</code>",
        f"Status: <code>{status}</code>",
    ]
    if is_bid_instance(instance):
        own_bid = get_tracked_bid(iid) if iid is not None else None
        min_bid = to_float(instance.get("min_bid"), None)
        if own_bid is not None:
            own_daily_total = price_daily(own_bid)
            own_daily_gpu = own_daily_total / max(1, count)
            lines.append(
                f"Моя ставка: <code>{fmt_price(own_daily_gpu)}/24ч на GPU</code> "
                f"(<code>{fmt_price(own_bid)}/ч весь риг</code>)"
            )
        if min_bid is not None:
            min_daily_total = price_daily(min_bid)
            min_daily_gpu = min_daily_total / max(1, count)
            lines.append(
                f"Мин. ставка: <code>{fmt_price(min_daily_gpu)}/24ч на GPU</code> "
                f"(<code>{fmt_price(min_bid)}/ч весь риг</code>)"
            )
        if own_bid is not None and min_bid is not None and min_bid > own_bid + 1e-9:
            lines.append("⚠️ Ставка перебита")
    elif daily is not None:
        daily_gpu = daily / max(1, count)
        lines.append(
            f"Стоимость: <code>{fmt_price(daily_gpu)}/24ч на GPU</code> "
            f"(<code>{fmt_price(daily)}/24ч весь риг</code>)"
        )
    if label:
        lines.append(f"Label: <code>{label}</code>")
    return "\n".join(lines)


# ============================================================
# CREATE INSTANCE
# ============================================================

def _vast_env() -> str:
    # Keep the Docker env/ports as close as possible to the user's working
    # `vastai create instance ... --env '...'` command.
    parts = []
    if VAST_JUPYTER_TOKEN:
        parts.append(f"-e JUPYTER_TOKEN={VAST_JUPYTER_TOKEN}")
    if VAST_EXTRA:
        parts.append(VAST_EXTRA.strip())
    return " ".join(parts)


def prepay_vast_instance(instance_id: int, amount: float) -> dict:
    """Convert an on-demand instance into reserved pricing by prepaying credits.

    Vast documents Reserved as an on-demand instance plus a prepayment. The
    REST endpoint is PUT /instances/prepay/{id} with an amount in credits.
    """
    instance_id = int(instance_id)
    amount = float(amount)
    if amount <= 0:
        raise ValueError(
            "Для RESERVED укажи VAST_RESERVED_PREPAY_AMOUNT > 0"
        )

    data = vast_request(
        "PUT",
        f"/instances/prepay/{instance_id}",
        json_body={"amount": amount},
        timeout=40,
    )
    if not isinstance(data, dict) or data.get("success") is not True:
        msg = data.get("msg") if isinstance(data, dict) else data
        raise RuntimeError(f"Vast RESERVED prepay не выполнен: {msg}")
    return data


def destroy_vast_instance(instance_id: int) -> dict:
    try:
        data = vast_sdk_call("destroy_instance", id=int(instance_id))
    except Exception as exc:
        raise RuntimeError(f"Vast destroy не выполнен: {short_error(exc, 700)}") from exc
    return data if isinstance(data, dict) else {"response": data}


def _parse_vast_env_string(raw: str) -> dict:
    """Parse Vast CLI-style '-e KEY=VALUE -p host:container' into SDK env dict."""
    result = {}
    if not raw:
        return result
    tokens = re.findall(r"(?:[^\s\"']|\"[^\"]*\"|'[^']*')+", raw)
    prev = None
    for token in tokens:
        token = token.strip()
        if prev is None:
            if token in {"-e", "-p"}:
                prev = token
            continue
        value = token.strip(" '\"")
        if prev == "-p":
            if re.fullmatch(r"[0-9:]+", value):
                result["-p " + value] = "1"
        elif prev == "-e":
            if "=" in value:
                key, val = value.split("=", 1)
                result[key] = val
        prev = None
    return result

def create_vast_instance(offer: dict, mode: str = "on-demand") -> dict:
    mode = _normalize_rent_mode(mode)
    if mode == "reserved":
        raise RuntimeError("RESERVED отключён в этой версии бота")
    oid = offer_id(offer)
    if oid is None:
        raise RuntimeError("У offer отсутствует ID")

    with rental_create_lock:
        if not has_active_rental_capacity(log=True):
            active = get_active_rental_count()
            limit = get_max_active_rigs()
            machine_id = get_machine_id(offer)
            notify_active_rental_limit(mode=mode.upper(), machine_id=machine_id)
            raise RuntimeError(f"Достигнут лимит активных ригов: {active}/{limit}")

        env_string = _vast_env()
        sdk_kwargs = {
            "id": int(oid),
            "image": VAST_IMAGE,
            "disk": float(VAST_DISK_GB),
            "label": f"{VAST_LABEL_PREFIX}-{get_gpu_key(get_gpu_name(offer)) or 'GPU'}",
            "runtype": VAST_RUNTYPE,
            "cancel_unavail": True,
            "env": _parse_vast_env_string(env_string),
            "onstart_cmd": VAST_ONSTART_CMD or None,
            "template_hash": VAST_TEMPLATE_HASH or None,
        }
        if mode == "interruptible":
            bid_price = offer_price_hour(offer, mode="interruptible")
            if bid_price is None or bid_price <= 0:
                raise RuntimeError("У INTERRUPTIBLE offer отсутствует цена bid")
            sdk_kwargs["price"] = float(bid_price)

        try:
            data = vast_sdk_call("create_instance", **sdk_kwargs)
        except Exception as exc:
            invalidate_marketplace_cache()
            raise RuntimeError(f"Vast SDK create_instance не выполнен: {short_error(exc, 700)}") from exc

        if not isinstance(data, dict):
            raise RuntimeError(f"Неожиданный ответ Vast SDK: {data}")
        if data.get("success") is False:
            invalidate_marketplace_cache()
            raise RuntimeError(f"Vast отклонил создание instance: {data.get('msg') or data}")

        instance_id = to_int(data.get("new_contract"), None)
        if instance_id is None:
            nested = data.get("instance")
            if isinstance(nested, dict):
                instance_id = to_int(nested.get("id"), None)
        if instance_id is None:
            instance_id = to_int(data.get("id"), None)
        if instance_id is None:
            raise RuntimeError(f"Vast создал instance, но не вернул ID: {data}")

        machine_id = get_machine_id(offer)
        with state_lock:
            rented_instance_set.add(instance_id)
            state["instance_ids"] = sorted(rented_instance_set)
            if machine_id is not None:
                rented_machine_set.add(machine_id)
                state["rented"] = sorted(rented_machine_set)
        save_state()

        if mode == "interruptible":
            bid_price = offer_price_hour(offer, mode="interruptible")
            if bid_price is not None:
                track_bid_instance(instance_id, bid_price, machine_id, get_gpu_name(offer))

        invalidate_marketplace_cache()
        logger.info(
            "✅ Vast SDK instance создан: instance_id=%s offer_id=%s machine_id=%s mode=%s",
            instance_id, oid, machine_id, mode,
        )
        return {
            "instance_id": instance_id,
            "offer_id": oid,
            "machine_id": machine_id,
            "mode": mode,
            "raw": data,
        }


def _is_offer_unavailable_error(exc: Exception) -> bool:
    """Return True when Vast says the selected ask/offer is gone.

    Vast documents HTTP 410 from PUT /asks/{id} as `no_such_ask`: the offer
    is no longer available. This is a normal marketplace race, not an API-key
    or endpoint failure.
    """
    text = str(exc).lower()
    return (
        "http 410" in text
        or "410 client error" in text
        or "no_such_ask" in text
        or "no longer available" in text
        or "is not available" in text
    )


def _find_fresh_offer_for_machine(
    machine_id: Optional[int],
    mode: str,
    *,
    auto: bool = False,
    retries: int = 2,
    reference_offer: Optional[dict] = None,
) -> Optional[dict]:
    """Find a fresh offer for a machine through the official Vast SDK."""
    if machine_id is None:
        return None
    mode = _normalize_rent_mode(mode)
    if mode not in {"on-demand", "interruptible"}:
        return None

    reference_gpu_key = get_gpu_key(get_gpu_name(reference_offer)) if isinstance(reference_offer, dict) else None
    reference_count = get_gpu_count(reference_offer) if isinstance(reference_offer, dict) else None
    attempts = max(1, int(retries) if not auto else 1)

    for attempt in range(attempts):
        try:
            api_type = "on-demand" if mode == "on-demand" else "bid"
            fresh_offers = vast_sdk_call(
                "search_offers",
                query=(
                    f"machine_id={int(machine_id)} "
                    f"num_gpus>=1 num_gpus<={max(1, MARKETPLACE_MAX_GPU_COUNT)}"
                ),
                type=api_type,
                order="dph_total" if mode == "on-demand" else "min_bid",
                limit=100,
                storage=max(1.0, float(VAST_DISK_GB)),
                no_default=False,
            )
            if not isinstance(fresh_offers, list):
                fresh_offers = _extract_offers(fresh_offers)
        except Exception as exc:
            logger.warning(
                "Vast SDK fresh offer lookup failed: mode=%s machine=%s: %s",
                mode, machine_id, short_error(exc, 300),
            )
            fresh_offers = []

        blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()
        if int(machine_id) in blacklist_snapshot or int(machine_id) in rented_snapshot:
            return None

        matching = []
        for candidate in fresh_offers:
            if get_machine_id(candidate) != int(machine_id):
                continue
            if not offer_rentable(candidate) or not gpu_matches(get_gpu_name(candidate)):
                continue
            if reference_gpu_key and get_gpu_key(get_gpu_name(candidate)) != reference_gpu_key:
                continue
            if reference_count is not None and get_gpu_count(candidate) != reference_count:
                continue
            matching.append(candidate)

        if matching:
            return min(
                matching,
                key=lambda x: (
                    float(offer_price_hour(x, mode=mode) or 1e99),
                    int(offer_id(x) or 0),
                ),
            )
        if attempt + 1 < attempts:
            time.sleep(0.35)
    return None


def rent_offer(offer: dict, mode: str = "on-demand", auto: bool = False) -> bool:
    mode = _normalize_rent_mode(mode)

    # Automatic rental must obey the configured GPU/price filters.
    # Manual Telegram rental is intentionally different: the user already
    # selected the exact offer, so a price/range change after /market must
    # not make the button silently do nothing.
    if auto:
        oid = offer_id(offer)
        machine_id = get_machine_id(offer)
        if oid is None or not offer_rentable(offer):
            return False
        if machine_id is not None:
            with state_lock:
                if machine_id in blacklist_set or machine_id in rented_machine_set:
                    return False
    else:
        oid = offer_id(offer)
        machine_id = get_machine_id(offer)
        if oid is None:
            raise RuntimeError("У offer отсутствует ID")
        if not offer_rentable(offer):
            raise RuntimeError("Этот offer больше недоступен для аренды")
        if machine_id is not None and machine_is_blacklisted(machine_id):
            raise RuntimeError(f"Machine {machine_id} находится в blacklist")
        with state_lock:
            if machine_id is not None and machine_id in rented_machine_set:
                raise RuntimeError(f"Machine {machine_id} уже используется ботом")

    if auto:
        if mode == "on-demand" and is_auto_on_demand_paused():
            logger.info("ON-DEMAND auto-rent skipped: manual pause")
            return False
        if mode == "interruptible" and is_auto_interruptible_paused():
            return False
        if mode == "reserved" and is_auto_reserved_paused():
            return False

    original_offer = offer
    attempts = 0
    max_attempts = 4 if not auto else 2

    while attempts < max_attempts:
        attempts += 1
        current_offer = original_offer

        try:
            result = create_vast_instance(current_offer, mode=mode)
            gpu = get_gpu_name(current_offer)
            count = get_gpu_count(current_offer)
            hourly = offer_price_hour(current_offer, mode=mode)
            daily = price_daily(hourly) if hourly is not None else None
            iid = result.get("instance_id")
            machine_id = result.get("machine_id")
            labels = {
                "on-demand": "ON-DEMAND",
                "interruptible": "INTERRUPTIBLE",
                "reserved": "RESERVED",
            }
            kind = labels[mode]
            send_message(
                f"🟢 <b>{kind} GPU арендован на Vast.ai</b>\n\n"
                f"GPU: <code>{html.escape(gpu)}</code>\n"
                f"Instance ID: <code>{iid if iid is not None else '?'}</code>\n"
                f"Machine ID: <code>{machine_id if machine_id is not None else '?'}</code>\n"
                f"GPU count: <code>{count}</code>\n"
                f"Цена сервера: <code>{fmt_price(daily)}/24ч</code>\n"
                f"Цена 1 GPU: <code>{fmt_price(per_gpu_daily(hourly, count) if hourly is not None else None)}/24ч</code>"
                + (
                    f"\nPrepay: <code>${get_reserved_prepay_amount():.2f}</code>"
                    if mode == "reserved" else ""
                ),
                build_rented_notification_keyboard(machine_id),
            )
            return True

        except Exception as exc:
            if _is_offer_unavailable_error(exc) and attempts == 1:
                machine_id = get_machine_id(current_offer)
                invalidate_marketplace_cache()
                logger.info(
                    "⚠️ Vast offer %s (machine=%s) исчез до создания; "
                    "обновляю marketplace и ищу свежий offer.",
                    offer_id(current_offer),
                    machine_id,
                )

                fresh_offer = _find_fresh_offer_for_machine(
                    machine_id,
                    mode,
                    auto=auto,
                    retries=2 if not auto else 1,
                    reference_offer=current_offer,
                )
                if fresh_offer is not None:
                    logger.info(
                        "🔄 Найден свежий offer %s для machine=%s; повторяю аренду (попытка %s/%s).",
                        offer_id(fresh_offer),
                        machine_id,
                        attempts + 1,
                        max_attempts,
                    )
                    original_offer = fresh_offer
                    continue

                # The selected offer is gone. Never submit the same stale
                # offer ID again: Vast returns 410 because the ask is already
                # unavailable. Auto-rental simply moves to the next candidate.
                if auto:
                    logger.info(
                        "ℹ️ Свежего offer для machine=%s больше нет; "
                        "переходим к следующему кандидату.",
                        machine_id,
                    )
                    return False

                # Manual click: do not retry the dead offer ID. Tell the user
                # to refresh/open the marketplace so a fresh ask is used.
                logger.info(
                    "ℹ️ Manual rental: offer=%s machine=%s больше недоступен; "
                    "старый offer повторно не отправляется.",
                    offer_id(current_offer),
                    machine_id,
                )
                try:
                    send_message(
                        "⚠️ <b>Offer больше недоступен</b>\n\n"
                        f"Offer: <code>{offer_id(current_offer) if offer_id(current_offer) is not None else '?'}</code>\n"
                        f"Machine: <code>{machine_id if machine_id is not None else '?'}</code>\n\n"
                        "Vast.ai вернул 410 — этот offer уже исчез. "
                        "Открой/обнови Marketplace и выбери свежий offer."
                    )
                except Exception as notify_exc:
                    logger.warning("Не удалось отправить уведомление о 410: %s", notify_exc)
                return False

            text = short_error(exc, 900)
            if "Достигнут лимит активных ригов" in text:
                logger.info("Новая аренда отклонена лимитом Vast: %s", text)
                return False
            if auto:
                logger.warning("Vast %s автоаренда не выполнена: %s", mode.upper(), text)
            send_message(
                f"❌ <b>Ошибка {mode.upper()} аренды Vast.ai</b>\n\n"
                f"Offer: <code>{offer_id(current_offer) if offer_id(current_offer) is not None else '?'}</code>\n"
                f"Machine: <code>{get_machine_id(current_offer) if get_machine_id(current_offer) is not None else '?'}</code>\n"
                f"<code>{html.escape(text)}</code>"
            )
            return False

    return False


def find_offer_fresh(offer_id_value: int, mode: str = "on-demand") -> Optional[dict]:
    mode = _normalize_rent_mode(mode)
    target = int(offer_id_value)

    # Fast path: use the short-lived marketplace cache first. The create call
    # itself still handles a race where the offer vanished between reads.
    for force_refresh in (False, True):
        offers = get_marketplace(mode=mode, force_refresh=force_refresh)
        for offer in offers:
            if offer_id(offer) == target:
                return offer
    return None


def build_manual_offer_keyboard(mode: str, oid: int, machine_id: Optional[int]) -> dict:
    """Keyboard for one marketplace notification; contains only its mode."""
    mode = _normalize_rent_mode(mode)
    callback_names = {
        "on-demand": "rent_od",
        "interruptible": "rent_bid",
    }
    labels = {
        "on-demand": "🟢 Арендовать ON-DEMAND",
        "interruptible": "🟡 Арендовать INTERRUPTIBLE",
    }
    if mode not in callback_names:
        raise ValueError("RESERVED отключён")
    suffix = f":{int(machine_id)}" if machine_id is not None else ""
    rows = [[{
        "text": labels[mode],
        "callback_data": f"{callback_names[mode]}:{int(oid)}{suffix}",
    }]]
    if machine_id is not None:
        rows.append([{
            "text": "🚫 В blacklist",
            "callback_data": f"ban:{int(machine_id)}",
        }])
    return {"inline_keyboard": rows}


def _marketplace_notification_key(offer: dict, mode: str) -> Optional[str]:
    machine_id = get_machine_id(offer)
    gpu_key = get_gpu_key(get_gpu_name(offer)) or get_gpu_name(offer).strip().lower()
    count = max(1, get_gpu_count(offer))
    if machine_id is None or not gpu_key:
        oid = offer_id(offer)
        return f"{mode}:offer:{oid}" if oid is not None else None
    return f"{mode}:machine:{int(machine_id)}:gpu:{gpu_key}:count:{count}"


def _marketplace_notification_allowed(offer: dict, mode: str, price_daily: Optional[float]) -> tuple[bool, str]:
    key = _marketplace_notification_key(offer, mode)
    if key is None:
        return False, "no-key"
    now = time.time()
    with state_lock:
        raw = state.setdefault("marketplace_notifications", {})
        entry = raw.get(key)
        if not isinstance(entry, dict):
            return True, key
        last_ts = to_float(entry.get("last_ts"), 0.0) or 0.0
        last_price = to_float(entry.get("last_price"), None)
        price_changed = (
            price_daily is not None
            and last_price is not None
            and abs(price_daily - last_price) >= MARKETPLACE_NOTIFY_PRICE_CHANGE
        )
        if last_ts > 0 and now - last_ts < MARKETPLACE_NOTIFY_COOLDOWN and not price_changed:
            return False, key
    return True, key


def _mark_marketplace_notification_sent(key: str, price_daily: Optional[float], offer_id_value: Optional[int]):
    with state_lock:
        raw = state.setdefault("marketplace_notifications", {})
        raw[key] = {
            "last_ts": time.time(),
            "last_price": float(price_daily) if price_daily is not None else None,
            "offer_id": int(offer_id_value) if offer_id_value is not None else None,
        }
        # Keep state small. The newest 500 entries are enough for cooldown tracking.
        if len(raw) > 500:
            ordered = sorted(
                raw.items(),
                key=lambda item: float(item[1].get("last_ts", 0) or 0) if isinstance(item[1], dict) else 0,
                reverse=True,
            )[:500]
            state["marketplace_notifications"] = dict(ordered)


def scan_and_notify_marketplace_offers(*, force_refresh: bool = False):
    """Backward-compatible wrapper for the live marketplace updater."""
    return update_live_marketplace_message(force_refresh=force_refresh)


# ============================================================
# SPOT NOTIFICATIONS
# ============================================================

def _spot_notification_allowed(offer: dict) -> bool:
    oid = offer_id(offer)
    hourly = offer_price_hour(offer, mode="interruptible")
    count = get_gpu_count(offer)
    if oid is None or hourly is None:
        return False
    now = time.time()
    key = str(oid)
    with state_lock:
        raw = state.setdefault("spot_notifications", {})
        last = to_float(raw.get(key), 0.0) or 0.0
        if now - last < SPOT_NOTIFY_COOLDOWN:
            return False
        # Do not update yet; send_message success below decides it.
    return True


def _notify_spot_candidates(candidates: list[dict]):
    sent = 0
    changed = False
    # Candidates are already sorted by Vast's bid order. No extra sorting pass.
    for offer in candidates[:10]:
        if not _spot_notification_allowed(offer):
            continue
        machine_id = get_machine_id(offer)
        result = send_message(
            "🔔 <b>Найден INTERRUPTIBLE-риг на Vast.ai</b>\n\n"
            + format_offer(offer, mode="interruptible"),
            build_server_keyboard(offer_id(offer), machine_id),
        )
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state.setdefault("spot_notifications", {})[str(offer_id(offer))] = time.time()
            changed = True
            sent += 1
    if changed:
        save_state()
    if sent:
        logger.info("INTERRUPTIBLE уведомления: отправлено %s", sent)


# ============================================================
# MARKETPLACE SCAN
# ============================================================

def _build_candidates(
    mode: str,
    *,
    blacklist_snapshot: Optional[set[int]] = None,
    rented_snapshot: Optional[set[int]] = None,
    price_ranges: Optional[dict] = None,
    max_candidates: Optional[int] = None,
) -> list[dict]:
    mode = _normalize_rent_mode(mode)
    offers = get_marketplace(mode=mode)
    if blacklist_snapshot is None or rented_snapshot is None:
        blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()
    if price_ranges is None:
        price_ranges = get_auto_price_ranges_snapshot(mode=mode)
    enabled_gpus = set(get_enabled_gpus())

    result = []
    for offer in offers:
        if not offer_is_candidate(
            offer,
            mode=mode,
            blacklist_snapshot=blacklist_snapshot,
            rented_snapshot=rented_snapshot,
            price_ranges=price_ranges,
            enabled_gpus=enabled_gpus,
        ):
            continue
        result.append(offer)
        if max_candidates is not None and len(result) >= max_candidates:
            break
    return result


def _mode_auto_enabled(mode: str) -> bool:
    mode = _normalize_rent_mode(mode)
    with state_lock:
        if mode == "on-demand":
            return AUTO_ON_DEMAND and not bool(state.get("auto_on_demand_paused", False))
        if mode == "interruptible":
            return AUTO_INTERRUPTIBLE and not bool(state.get("auto_interruptible_paused", False))
        if mode == "reserved":
            return False
    return False


def _auto_mode_flags_snapshot() -> dict[str, bool]:
    with state_lock:
        return {
            "on-demand": AUTO_ON_DEMAND and not bool(state.get("auto_on_demand_paused", False)),
            "interruptible": AUTO_INTERRUPTIBLE and not bool(state.get("auto_interruptible_paused", False)),
            "reserved": False,
        }


def _any_auto_mode_enabled() -> bool:
    return any(_auto_mode_flags_snapshot().values())


def check_marketplace(*, already_synced: bool = False):
    with marketplace_scan_lock:
        logger.info("Проверяю marketplace Vast.ai...")

        if not already_synced:
            if not refresh_active_rented_state(force_refresh=False):
                logger.warning("⛔ Marketplace scan остановлен: активные инстансы Vast не подтверждены.")
                return

        mode_flags = _auto_mode_flags_snapshot()
        modes = [m for m in ("on-demand", "interruptible") if mode_flags[m]]

        # Notification-only BID mode is optional and should not duplicate a
        # marketplace request when auto BID is already enabled.
        notify_bid = (
            not mode_flags["interruptible"]
            and NOTIFY_SPOT_WHEN_AUTO_DISABLED
            and not MARKETPLACE_AUTO_NOTIFY
        )

        if modes and not _active_limit_gate_allows_marketplace():
            return

        if not modes and not notify_bid:
            return

        blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()
        candidates = {}

        max_to_rent = max(1, MAX_RENT_PER_SCAN)
        for mode in modes:
            # RESERVED creation requires an explicit prepay amount. Keep the
            # mode enabled, but do not hammer the API with doomed create calls
            # when that amount has not been configured yet.

            price_ranges = get_auto_price_ranges_snapshot(mode=mode)
            candidates[mode] = _build_candidates(
                mode,
                blacklist_snapshot=blacklist_snapshot,
                rented_snapshot=rented_snapshot,
                price_ranges=price_ranges,
                max_candidates=max_to_rent,
            )
            logger.info(
                "🤖 Auto candidates: mode=%s candidates=%d/%d",
                mode, len(candidates[mode]), len(get_marketplace(mode=mode)),
            )

        if notify_bid:
            bid_price_ranges = get_auto_price_ranges_snapshot(mode="interruptible")
            interruptible_candidates = _build_candidates(
                "interruptible",
                blacklist_snapshot=blacklist_snapshot,
                rented_snapshot=rented_snapshot,
                price_ranges=bid_price_ranges,
                max_candidates=10,
            )
            _notify_spot_candidates(interruptible_candidates)

        rented_this_scan = 0
        ordered_modes = ("interruptible", "on-demand")

        for mode in ordered_modes:
            if mode not in modes or rented_this_scan >= max_to_rent:
                continue

            # Vast returns offers in the requested price order, so the
            # candidate list is already ranked. Avoid a second nsmallest() pass.
            mode_candidates = candidates.get(mode, [])
            ranked = mode_candidates[:max_to_rent - rented_this_scan]

            for offer in ranked:
                # Local state is updated immediately after a successful create,
                # so this check avoids a lock/API call for every candidate.
                active = get_active_rental_count()
                limit = get_max_active_rigs()
                if active >= limit:
                    notify_active_rental_limit(
                        mode=mode.upper(),
                        machine_id=get_machine_id(offer),
                    )
                    logger.info("%s auto-rent loop stopped: active-rig limit reached", mode.upper())
                    return

                if rent_offer(offer, mode=mode, auto=True):
                    rented_this_scan += 1
                    if rented_this_scan >= max_to_rent:
                        return


# ============================================================
# AUTO ON-DEMAND CONTROL
# ============================================================

def is_auto_on_demand_paused() -> bool:
    with state_lock:
        return bool(state.get("auto_on_demand_paused", False))


def set_auto_on_demand_paused(paused: bool):
    with state_lock:
        state["auto_on_demand_paused"] = bool(paused)
    save_state()
    logger.info("Auto ON-DEMAND %s", "PAUSED" if paused else "STARTED")


def is_auto_interruptible_paused() -> bool:
    with state_lock:
        return bool(state.get("auto_interruptible_paused", False))


def set_auto_interruptible_paused(paused: bool):
    with state_lock:
        state["auto_interruptible_paused"] = bool(paused)
    save_state()
    logger.info("Auto INTERRUPTIBLE %s", "PAUSED" if paused else "STARTED")


def is_auto_reserved_paused() -> bool:
    with state_lock:
        return bool(state.get("auto_reserved_paused", False))


def set_auto_reserved_paused(paused: bool):
    with state_lock:
        state["auto_reserved_paused"] = bool(paused)
    save_state()
    logger.info("Auto RESERVED %s", "PAUSED" if paused else "STARTED")


# ============================================================
# TELEGRAM
# ============================================================

TG_API = f"https://api.telegram.org/bot{TG_TOKEN}"


def telegram_request(method: str, payload: Optional[dict] = None, timeout: int = 20):
    try:
        response = TG_SESSION.post(
            f"{TG_API}/{method}",
            json=payload or {},
            timeout=timeout,
        )

        try:
            data = response.json()
        except ValueError:
            data = {
                "ok": False,
                "description": response.text[:500],
            }

        if response.status_code == 429:
            logger.warning(
                "Telegram rate limit HTTP 429: %s",
                data.get("description", response.text[:500]),
            )
            return data

        if response.status_code >= 400 or not data.get("ok"):
            logger.error(
                "Telegram API error HTTP %s %s: %s",
                response.status_code,
                method,
                data.get("description", response.text[:500]),
            )
            return data

        return data

    except Exception as exc:
        logger.error("Telegram request error: %s", exc)
        return None


def _strip_telegram_html(text: str) -> str:
    """Remove Telegram HTML tags for a safe plain-text retry."""
    cleaned = re.sub(r"<[^>]+>", "", str(text))
    return html.unescape(cleaned)


def send_message(text: str, reply_markup=None):
    payload = {
        "chat_id": TG_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    result = telegram_request("sendMessage", payload)
    if isinstance(result, dict) and result.get("ok"):
        return result

    description = str(result.get("description", "")) if isinstance(result, dict) else ""
    lower = description.lower()

    # A dynamic GPU/offer field can occasionally contain an HTML fragment
    # that Telegram rejects. Retry the exact message as plain text instead of
    # losing the notification completely.
    if "parse entities" in lower or "can't parse entities" in lower or "unsupported start tag" in lower:
        fallback_payload = dict(payload)
        fallback_payload.pop("parse_mode", None)
        fallback_payload["text"] = _strip_telegram_html(text)
        logger.warning("Telegram HTML-разметка отклонена; повторяю сообщение без HTML")
        return telegram_request("sendMessage", fallback_payload)

    # Telegram rejects messages above 4096 characters. Keep notifications
    # useful by retrying a safe truncated version.
    if "message is too long" in lower or "message_too_long" in lower:
        fallback_payload = dict(payload)
        fallback_payload.pop("parse_mode", None)
        fallback_payload["text"] = _strip_telegram_html(text)[:3900] + "\n…"
        logger.warning("Telegram сообщение слишком длинное; отправляю укороченную версию")
        return telegram_request("sendMessage", fallback_payload)

    return result


def edit_message(text: str, message_id: int, reply_markup=None):
    """Edit the persistent live marketplace message; return Telegram result."""
    payload = {
        "chat_id": TG_CHAT_ID,
        "message_id": int(message_id),
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    result = telegram_request("editMessageText", payload)
    if isinstance(result, dict) and result.get("ok"):
        return result

    description = str(result.get("description", "")) if isinstance(result, dict) else ""
    lower = description.lower()

    # This is a successful no-op: Telegram confirms that the requested
    # text and reply markup are already identical to the current message.
    # Treat it as success so callers do not create duplicate menus.
    if "message is not modified" in lower:
        return {
            "ok": True,
            "result": {
                "message_id": int(message_id),
                "not_modified": True,
            },
            "description": description,
        }

    # Retry without HTML if dynamic marketplace text contains unsupported markup.
    if "parse entities" in lower or "can't parse entities" in lower or "unsupported start tag" in lower:
        fallback = dict(payload)
        fallback.pop("parse_mode", None)
        fallback["text"] = _strip_telegram_html(text)
        return telegram_request("editMessageText", fallback)

    return result


def _live_mode_gpu_count_rows(
    items: list[tuple[str, dict, Optional[float]]],
) -> dict[str, dict[str, dict[int, tuple[dict, Optional[float]]]]]:
    """Group live offers as mode -> GPU -> gpu_count -> cheapest offer.

    This deliberately keeps different GPU counts separate. The previous
    implementation collapsed a whole GPU model to one cheapest offer, which
    hid 2x/3x/4x/... rigs whenever a cheaper 1-GPU offer existed.
    """
    grouped: dict[str, dict[str, dict[int, tuple[dict, Optional[float]]]]] = {
        "on-demand": {},
        "interruptible": {},
        "reserved": {},
    }

    for mode, offer, daily_per_gpu in items:
        gpu_key = get_gpu_key(get_gpu_name(offer)) or get_gpu_name(offer).strip().lower()
        count = max(1, get_gpu_count(offer))
        if not gpu_key:
            continue
        if count < max(1, MARKETPLACE_MIN_GPU_COUNT) or count > max(
            MARKETPLACE_MIN_GPU_COUNT,
            MARKETPLACE_MAX_GPU_COUNT,
        ):
            continue

        gpu_bucket = grouped.setdefault(mode, {}).setdefault(gpu_key, {})
        current = gpu_bucket.get(count)
        if current is None:
            gpu_bucket[count] = (offer, daily_per_gpu)
            continue

        current_price = float(current[1]) if current[1] is not None else float("inf")
        new_price = float(daily_per_gpu) if daily_per_gpu is not None else float("inf")
        current_oid = int(offer_id(current[0]) or 0)
        new_oid = int(offer_id(offer) or 0)
        if (new_price, new_oid) < (current_price, current_oid):
            gpu_bucket[count] = (offer, daily_per_gpu)

    return grouped


def _safe_live_marketplace_text(items: list[tuple[str, dict, Optional[float]]]) -> str:
    """Build a compact live marketplace view with prices for each GPU count.

    Price is always shown as USD per 24h for ONE GPU.  Multi-GPU rigs keep
    their own ×1/×2/.../×8 row so a cheap 1-GPU offer cannot hide a larger rig.
    """
    mode_icons = {
        "on-demand": "🟢",
        "interruptible": "🟡",
    }
    mode_names = {
        "on-demand": "ON-DEMAND",
        "interruptible": "INTERRUPTIBLE",
    }

    grouped = _live_mode_gpu_count_rows(items)
    lines = ["📡 <b>VAST.AI MARKETPLACE</b>", ""]
    total_configs = 0
    max_count = max(MARKETPLACE_MIN_GPU_COUNT, MARKETPLACE_MAX_GPU_COUNT)

    for mode in ("on-demand", "interruptible"):
        gpu_groups = grouped.get(mode, {})
        if not gpu_groups:
            continue

        lines.append(f"{mode_icons[mode]} <b>{mode_names[mode]}</b>")
        for gpu_key in ALLOWED_GPUS:
            count_map = gpu_groups.get(gpu_key)
            if not count_map:
                continue

            parts = []
            for count in range(max(1, MARKETPLACE_MIN_GPU_COUNT), max_count + 1):
                row = count_map.get(count)
                if row is None:
                    continue
                _, daily_per_gpu = row
                if daily_per_gpu is None:
                    parts.append(f"×{count} ?")
                else:
                    parts.append(f"×{count} ${float(daily_per_gpu):.2f}")
                total_configs += 1

            if parts:
                name = html.escape(gpu_display_name(gpu_key))
                lines.append(f"• <b>{name}</b>: " + " | ".join(parts) + " <i>$/24ч/GPU</i>")

        lines.append("")

    if total_configs == 0:
        lines.extend([
            "📭 <b>Подходящих offers сейчас нет.</b>",
            "",
            "Проверь GPU-фильтр и нажми 🔄 ОБНОВИТЬ.",
        ])

    lines.append(f"Конфигураций: <code>{total_configs}</code>")
    lines.append("Цена указана за 1 GPU / 24ч. Диск отдельно.")

    text = "\n".join(lines)
    if len(text) <= 3900:
        return text

    # Keep the first GPU rows readable when Telegram's 4096-char limit is hit.
    trimmed = text[:3850]
    cut = trimmed.rfind("\n")
    if cut > 0:
        trimmed = trimmed[:cut]
    return trimmed + "\n\n… список обрезан из-за лимита Telegram"


def _build_live_marketplace_keyboard(items: list[tuple[str, dict, Optional[float]]]) -> dict:
    """Show one compact button per GPU/mode; details contain all GPU counts."""
    mode_icons = {
        "on-demand": "🟢",
        "interruptible": "🟡",
    }
    grouped = _live_mode_gpu_count_rows(items)
    rows = []

    # Keep every enabled GPU in the Telegram marketplace keyboard.
    # A missing offer must not make its GPU button disappear; the detail view
    # can then report that there are no current offers for that model.
    enabled_gpu_order = [key for key in ALLOWED_GPUS if key in set(get_enabled_gpus()) and key in GPU_ALIASES]
    for mode in ("on-demand", "interruptible"):
        gpu_groups = grouped.get(mode, {})
        visible = enabled_gpu_order
        for i in range(0, len(visible), 2):
            row = []
            for gpu_key in visible[i:i + 2]:
                count_map = gpu_groups.get(gpu_key, {})
                price_rows = [
                    (count, row_data[1])
                    for count, row_data in count_map.items()
                    if row_data[1] is not None
                ]
                if price_rows:
                    best_count, best_daily = min(price_rows, key=lambda x: (float(x[1]), x[0]))
                    price_text = f"${best_daily:.2f}/24ч"
                    count_text = f"{best_count}x"
                else:
                    price_text = "нет offer"
                    count_text = "—"
                row.append({
                    "text": f"{mode_icons[mode]} {gpu_display_name(gpu_key)} — {price_text} ({count_text})",
                    "callback_data": f"market_gpu:{mode}:{gpu_key}",
                })
            if row:
                rows.append(row)

    rows.append([{
        "text": "🔄 ОБНОВИТЬ",
        "callback_data": "market_live_refresh",
    }])
    rows.append([{
        "text": "🏠 МЕНЮ",
        "callback_data": "market_live_back",
    }])
    return {"inline_keyboard": rows}


def _build_gpu_mode_detail(
    mode: str,
    gpu_key: str,
) -> tuple[str, dict]:
    """Fetch fresh offers for one GPU/mode and expose 1..8 GPU variants."""
    mode = _normalize_rent_mode(mode)
    if mode not in {"on-demand", "interruptible"}:
        raise ValueError("Режим отключён: RESERVED")
    if gpu_key not in ALLOWED_GPUS or gpu_key not in GPU_ALIASES:
        raise ValueError("Неизвестная GPU")

    aliases = GPU_ALIASES.get(gpu_key, [])
    query_name = aliases[0] if aliases else gpu_key
    try:
        offers = vast_sdk_call(
            "search_offers",
            query=(
                f"gpu_name={_sdk_gpu_token(query_name)} "
                f"num_gpus>={max(1, MARKETPLACE_MIN_GPU_COUNT)} "
                f"num_gpus<={max(1, MARKETPLACE_MAX_GPU_COUNT)}"
            ),
            type="on-demand" if mode == "on-demand" else "bid",
            order="num_gpus-,dph_total" if mode == "on-demand" else "num_gpus-,min_bid",
            limit=500,
            storage=max(1.0, float(VAST_DISK_GB)),
            no_default=False,
        )
        if not isinstance(offers, list):
            offers = _extract_offers(offers)
    except Exception as exc:
        logger.warning("GPU detail: ошибка Vast SDK %s/%s: %s", mode, gpu_key, short_error(exc, 250))
        offers = get_marketplace(mode=mode, force_refresh=False)
    blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()
    best_by_count: dict[int, tuple[dict, float]] = {}

    for offer in offers:
        if not offer_rentable(offer):
            continue
        mid = get_machine_id(offer)
        if mid is not None and (mid in blacklist_snapshot or mid in rented_snapshot):
            continue
        if get_gpu_key(get_gpu_name(offer)) != gpu_key:
            continue
        count = max(1, get_gpu_count(offer))
        if count < max(1, MARKETPLACE_MIN_GPU_COUNT) or count > max(
            MARKETPLACE_MIN_GPU_COUNT,
            MARKETPLACE_MAX_GPU_COUNT,
        ):
            continue
        hourly = offer_gpu_price_hour(offer, mode=mode)
        if hourly is None:
            continue
        daily_per_gpu_value = per_gpu_daily(hourly, count)
        current = best_by_count.get(count)
        if current is None or (
            daily_per_gpu_value,
            int(offer_id(offer) or 0),
        ) < (
            current[1],
            int(offer_id(current[0]) or 0),
        ):
            best_by_count[count] = (offer, daily_per_gpu_value)

    labels = {
        "on-demand": "🟢 ON-DEMAND",
        "interruptible": "🟡 INTERRUPTIBLE",
        "reserved": "🔵 RESERVED",
    }
    title = gpu_display_name(gpu_key)
    lines = [
        f"{labels[mode]} · <b>{html.escape(title)}</b>",
        "",
        "Стоимость: <b>$/24ч за 1 GPU</b>",
        "",
    ]
    callback_name = {
        "on-demand": "rent_od",
        "interruptible": "rent_bid",
        "reserved": "rent_reserved",
    }[mode]
    keyboard_rows = []

    for count in sorted(best_by_count):
        offer, daily_per_gpu_value = best_by_count[count]
        mid = get_machine_id(offer)
        oid = offer_id(offer)
        lines.append(
            f"• <b>×{count} GPU</b> — <code>${daily_per_gpu_value:.4f}/24ч/GPU</code>"
            f" · Machine <code>{mid if mid is not None else '?'}</code>"
        )
        if mode == "interruptible":
            min_bid = to_float(offer.get("min_bid"), None)
            if min_bid is not None:
                lines.append(
                    f"  min bid: <code>${price_daily(min_bid):.4f}/24ч/риг</code>"
                )
        if oid is not None:
            suffix = f":{int(mid)}" if mid is not None else ""
            keyboard_rows.append([{
                "text": f"{_mode_icon(mode)} Арендовать ×{count} · ${daily_per_gpu_value:.2f}/GPU/24ч",
                "callback_data": f"{callback_name}:{int(oid)}{suffix}",
            }])

    if not best_by_count:
        lines.append("❌ Сейчас подходящих конфигураций нет.")

    keyboard_rows.append([{
        "text": "↩️ К MARKETPLACE",
        "callback_data": "market_live_refresh",
    }])
    return "\n".join(lines)[:3900], {"inline_keyboard": keyboard_rows}


def _mode_icon(mode: str) -> str:
    return {"on-demand": "🟢", "interruptible": "🟡", "reserved": "🔵"}.get(mode, "•")

def update_live_marketplace_message(*, force_refresh: bool = False, target_message_id: Optional[int] = None) -> bool:
    """Refresh the single Telegram marketplace message.

    This UI path intentionally does NOT use marketplace_scan_lock. Marketplace
    fetching and Telegram button handling are separate concerns.
    """
    if not MARKETPLACE_AUTO_NOTIFY and not force_refresh:
        return False

    # Only one Telegram marketplace refresh may build/edit the live message at
    # once. This function is called from worker threads, so waiting here does
    # not block Telegram polling. Never silently drop a real button press.
    marketplace_live_update_lock.acquire()
    try:
        return _update_live_marketplace_message_locked(force_refresh=force_refresh, target_message_id=target_message_id)
    finally:
        marketplace_live_update_lock.release()


def _update_live_marketplace_message_locked(*, force_refresh: bool = False, target_message_id: Optional[int] = None) -> bool:
    global marketplace_live_message_verified

    blacklist_snapshot, rented_snapshot = get_scan_state_snapshot()
    enabled_gpus = set(get_enabled_gpus())
    candidates: list[tuple[str, dict, Optional[float]]] = []
    modes = ("on-demand", "interruptible")

    logger.info(
        "Live marketplace: старт обновления, enabled_gpus=%s, blacklist=%s, rented=%s",
        ",".join(sorted(enabled_gpus)) if enabled_gpus else "НЕТ",
        len(blacklist_snapshot),
        len(rented_snapshot),
    )

    def fetch_mode(mode: str) -> tuple[str, list[dict]]:
        try:
            offers = get_marketplace(mode=mode, force_refresh=force_refresh)
            return mode, offers
        except Exception as exc:
            logger.exception("Live marketplace: ошибка получения %s: %s", mode, short_error(exc, 250))
            return mode, []

    with ThreadPoolExecutor(max_workers=3, thread_name_prefix="vast-market") as executor:
        mode_results = dict(executor.map(fetch_mode, modes))

    for mode in modes:
        offers = mode_results.get(mode, [])
        mode_rows = []
        skipped = 0

        for offer in offers:
            oid = offer_id(offer)
            if oid is None or not offer_rentable(offer):
                skipped += 1
                continue
            mid = get_machine_id(offer)
            if mid is not None and (mid in blacklist_snapshot or mid in rented_snapshot):
                skipped += 1
                continue
            gpu_key = get_gpu_key(get_gpu_name(offer))
            if gpu_key is None or gpu_key not in enabled_gpus:
                skipped += 1
                continue
            count = max(1, get_gpu_count(offer))
            hourly = offer_gpu_price_hour(offer, mode=mode)
            daily_per_gpu = per_gpu_daily(hourly, count) if hourly is not None else None
            mode_rows.append((offer, daily_per_gpu))

        by_gpu_count = {}
        for offer, daily_per_gpu in mode_rows:
            gpu_key = get_gpu_key(get_gpu_name(offer)) or get_gpu_name(offer)
            count = max(1, get_gpu_count(offer))
            if count < max(1, MARKETPLACE_MIN_GPU_COUNT) or count > max(
                MARKETPLACE_MIN_GPU_COUNT, MARKETPLACE_MAX_GPU_COUNT
            ):
                continue
            key = (gpu_key, count)
            current = by_gpu_count.get(key)
            candidate = (offer, daily_per_gpu)
            if current is None:
                by_gpu_count[key] = candidate
                continue
            cur_price = float(current[1]) if current[1] is not None else float("inf")
            new_price = float(daily_per_gpu) if daily_per_gpu is not None else float("inf")
            if (new_price, int(offer_id(offer) or 0)) < (
                cur_price,
                int(offer_id(current[0]) or 0),
            ):
                by_gpu_count[key] = candidate

        mode_rows = list(by_gpu_count.values())
        mode_rows.sort(
            key=lambda x: (
                get_gpu_key(get_gpu_name(x[0])) or get_gpu_name(x[0]),
                get_gpu_count(x[0]),
                float(x[1]) if x[1] is not None else float("inf"),
                int(offer_id(x[0]) or 0),
            )
        )
        candidates.extend((mode, offer, daily_per_gpu) for offer, daily_per_gpu in mode_rows)
        logger.info(
            "Live marketplace: mode=%s offers=%s accepted=%s skipped=%s configs=%s",
            mode, len(offers), len(mode_rows), skipped, len(by_gpu_count),
        )

    try:
        text = _safe_live_marketplace_text(candidates)
        markup = _build_live_marketplace_keyboard(candidates)
    except Exception as exc:
        logger.exception("Live marketplace: ошибка построения Telegram-сообщения: %s", exc)
        # Never leave the user with no output because the dynamic formatter
        # broke. Send a small diagnostic marketplace message instead.
        text = (
            "📡 <b>VAST.AI MARKETPLACE</b>\n\n"
            f"Конфигураций получено: <code>{len(candidates)}</code>\n"
            "⚠️ Не удалось построить расширенный список цен. Нажми 🔄 ОБНОВИТЬ."
        )
        markup = {"inline_keyboard": [[
            {"text": "🔄 ОБНОВИТЬ", "callback_data": "market_live_refresh"},
        ], [
            {"text": "🏠 МЕНЮ", "callback_data": "market_live_back"},
        ]]}

    signature = hashlib.sha256(
        (text + "\n" + json.dumps(markup, sort_keys=True, ensure_ascii=False)).encode("utf-8")
    ).hexdigest()

    with state_lock:
        existing_id = to_int(target_message_id, None)
        if existing_id is None:
            existing_id = to_int(state.get("marketplace_live_message_id"), None)
        existing_hash = str(state.get("marketplace_live_message_hash", "") or "")

    # Do not trust a saved hash until this process has verified that the
    # Telegram message actually exists. This fixes the "bot restarted and the
    # marketplace disappeared" case caused by a stale/deleted message_id.
    if (
        not force_refresh
        and marketplace_live_message_verified
        and existing_id is not None
        and existing_hash == signature
    ):
        return True

    if existing_id is not None:
        result = edit_message(text, existing_id, markup)
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state["marketplace_live_message_hash"] = signature
            save_state()
            marketplace_live_message_verified = True
            logger.info("✅ Live marketplace Telegram message обновлено, message_id=%s", existing_id)
            return True

        description = str(result.get("description", "")) if isinstance(result, dict) else ""
        logger.warning(
            "Live marketplace edit failed (message_id=%s): %s — создаю новое сообщение",
            existing_id,
            description[:300],
        )
        with state_lock:
            state["marketplace_live_message_id"] = None
            state["marketplace_live_message_hash"] = ""
        marketplace_live_message_verified = False
        save_state()

    result = send_message(text, markup)
    if isinstance(result, dict) and result.get("ok"):
        new_id = ((result.get("result") or {}).get("message_id"))
        try:
            new_id = int(new_id)
        except (TypeError, ValueError):
            new_id = None
        with state_lock:
            state["marketplace_live_message_id"] = new_id
            state["marketplace_live_message_hash"] = signature
        save_state()
        marketplace_live_message_verified = True
        logger.info("✅ Live marketplace Telegram message отправлено, message_id=%s", new_id)
        return True

    # Last-resort Telegram fallback: send plain text with no keyboard/HTML.
    # This guarantees that a malformed dynamic keyboard or entity cannot make
    # the whole marketplace invisible.
    description = str(result.get("description", "")) if isinstance(result, dict) else "нет ответа Telegram"
    logger.warning("Live marketplace send failed: %s — пробую plain-text fallback", description[:300])
    fallback_result = telegram_request(
        "sendMessage",
        {
            "chat_id": TG_CHAT_ID,
            "text": _strip_telegram_html(text)[:3900],
            "disable_web_page_preview": True,
        },
    )
    if isinstance(fallback_result, dict) and fallback_result.get("ok"):
        new_id = ((fallback_result.get("result") or {}).get("message_id"))
        try:
            new_id = int(new_id)
        except (TypeError, ValueError):
            new_id = None
        with state_lock:
            state["marketplace_live_message_id"] = new_id
            state["marketplace_live_message_hash"] = ""
        save_state()
        marketplace_live_message_verified = True
        logger.info("✅ Live marketplace plain-text fallback отправлен, message_id=%s", new_id)
        return True

    logger.warning("❌ Live marketplace: Telegram не принял ни основной, ни fallback message")
    return False


def answer_callback(callback_id: str, text: str = ""):
    return telegram_request(
        "answerCallbackQuery",
        {"callback_query_id": callback_id, "text": text},
    )


def build_server_keyboard(offer_id_value: int, machine_id: Optional[int], allow_all: bool = True):
    # Include machine_id as well as offer_id. Offers can disappear/reappear
    # very quickly on Vast; machine_id lets the handler locate a fresh offer
    # for the same host instead of silently giving up.
    suffix = f":{int(machine_id)}" if machine_id is not None else ""
    rows = [[{
        "text": "🟢 Арендовать ON-DEMAND",
        "callback_data": f"rent_od:{offer_id_value}{suffix}",
    }]]
    if allow_all:
        rows.append([
            {
                "text": "🟡 Арендовать INTERRUPTIBLE",
                "callback_data": f"rent_bid:{offer_id_value}{suffix}",
            }
        ])
    rows.append([{
        "text": "🚫 В blacklist",
        "callback_data": f"ban:{machine_id}" if machine_id is not None else f"ban_offer:{offer_id_value}",
    }])
    return {"inline_keyboard": rows}


def build_rented_notification_keyboard(machine_id: Optional[int]):
    if machine_id is None:
        return None
    return {
        "inline_keyboard": [[
            {
                "text": "🚫 ЗАБАНИТЬ MACHINE",
                "callback_data": f"ban:{machine_id}",
            }
        ]]
    }


def build_auto_rent_keyboard():
    """Main control keyboard. Disabled auto-rent modes are visibly non-clickable."""
    od_configured = bool(AUTO_ON_DEMAND)
    bid_configured = bool(AUTO_INTERRUPTIBLE)
    reserved_configured = False

    def mode_button(label: str, configured: bool, paused: bool, start_cb: str, pause_cb: str):
        if not configured:
            return {"text": f"🚫 {label}: OFF", "callback_data": f"auto_disabled:{label}"}
        return {
            "text": f"▶️ {label}" if paused else f"⛔ {label}",
            "callback_data": start_cb if paused else pause_cb,
        }

    active = get_active_rental_count()
    limit = get_max_active_rigs()
    return {
        "inline_keyboard": [
            [
                mode_button("ON-DEMAND", od_configured, is_auto_on_demand_paused(), "auto_od_start", "auto_od_pause"),
                mode_button("INTERRUPTIBLE", bid_configured, is_auto_interruptible_paused(), "auto_bid_start", "auto_bid_pause"),
            ],
            [{"text": "🎮 ФИЛЬТР GPU", "callback_data": "gpu_filter_menu"}],
            [{"text": "⚙️ ЦЕНЫ", "callback_data": "auto_prices"}],
            [{"text": "💰 СТАВКИ INTERRUPTIBLE", "callback_data": "bid_menu"}],
            [{"text": f"🎛 ЛИМИТ АРЕНД: {active}/{limit} РИГОВ", "callback_data": "rental_limit"}],
            [
                {"text": "📊 /stats", "callback_data": "cmd_stats"},
                {"text": "📋 /status", "callback_data": "cmd_status"},
            ],
            [
                {"text": "📡 MARKETPLACE", "callback_data": "cmd_market"},
                {"text": "🔄 ОБНОВИТЬ РЫНОК", "callback_data": "cmd_scan"},
            ],
            [
                {"text": "🚫 БАН", "callback_data": "ban_menu"},
                {"text": "🔓 РАЗБАН", "callback_data": "unban_menu"},
            ],
        ]
    }


def build_ban_keyboard(machine_id: int):
    return {
        "inline_keyboard": [
            [{
                "text": "🚫 ЗАБАНИТЬ MACHINE",
                "callback_data": f"ban:{machine_id}",
            }],
            [{
                "text": "↩️ НАЗАД",
                "callback_data": "ban_menu_back",
            }],
        ]
    }


def send_ban_menu():
    offers = get_marketplace(force_refresh=True)
    seen = set()
    lines = ["🚫 <b>BLACKLIST MACHINE</b>", ""]
    buttons = []

    for offer in offers:
        mid = get_machine_id(offer)
        if mid is None or mid in seen:
            continue
        seen.add(mid)
        gpu = html.escape(get_gpu_name(offer))
        buttons.append([
            {
                "text": f"🚫 {mid} | {gpu[:24]}",
                "callback_data": f"ban:{mid}",
            }
        ])
        if len(buttons) >= 30:
            break

    if not buttons:
        lines.append("Подходящих machine ID не найдено.")
    else:
        lines.append(f"Машин в списке для выбора: <code>{len(buttons)}</code>")

    buttons.append([
        {"text": "↩️ НАЗАД", "callback_data": "ban_menu_back"}
    ])
    send_message("\n".join(lines), {"inline_keyboard": buttons})


def build_unban_keyboard():
    with state_lock:
        removable = sorted(x for x in blacklist_set if x not in BANNED_MACHINE_IDS)
    rows = []
    for mid in removable[:40]:
        rows.append([{
            "text": f"🔓 {mid}",
            "callback_data": f"unban:{mid}",
        }])
    rows.append([{"text": "↩️ НАЗАД", "callback_data": "unban_menu_back"}])
    return {"inline_keyboard": rows}


def send_unban_menu():
    with state_lock:
        removable = sorted(x for x in blacklist_set if x not in BANNED_MACHINE_IDS)
    lines = [
        "🔓 <b>РАЗБАН MACHINE</b>",
        "",
        f"Доступно: <code>{len(removable)}</code>",
    ]
    send_message("\n".join(lines), build_unban_keyboard())


def format_rental_limit_menu() -> str:
    active = get_active_rental_count()
    limit = get_max_active_rigs()
    return (
        "🎛 <b>ЛИМИТ АКТИВНЫХ АРЕНД</b>\n\n"
        f"Сейчас активно: <code>{active}</code> из <code>{limit}</code> ригов\n\n"
        "Когда лимит достигнут, бот ставит автоаренду на паузу и "
        "перестаёт сканировать marketplace.\n"
        "Он продолжает только проверять активные инстансы Vast и сам "
        "возобновляет работу после освобождения слота или увеличения лимита."
    )


def build_rental_limit_keyboard():
    limit = get_max_active_rigs()
    return {
        "inline_keyboard": [
            [
                {"text": "➖ 1", "callback_data": "rental_limit:-1"},
                {"text": f"📦 {limit} РИГОВ", "callback_data": "rental_limit:0"},
                {"text": "➕ 1", "callback_data": "rental_limit:+1"},
            ],
            [
                {"text": "➖ 5", "callback_data": "rental_limit:-5"},
                {"text": "➕ 5", "callback_data": "rental_limit:+5"},
            ],
            [{"text": "↩️ НАЗАД", "callback_data": "rental_limit_back"}],
        ]
    }


def gpu_display_name(gpu_key: str) -> str:
    return GPU_DISPLAY_NAMES.get(gpu_key, gpu_key)


def format_gpu_filter_menu() -> str:
    enabled = set(get_enabled_gpus())
    total = sum(1 for key in ALLOWED_GPUS if key in GPU_ALIASES)
    selected = sum(1 for key in ALLOWED_GPUS if key in enabled and key in GPU_ALIASES)
    lines = [
        "🎮 <b>ФИЛЬТР GPU ДЛЯ АВТОАРЕНДЫ</b>",
        "",
        f"Выбрано: <code>{selected}/{total}</code>",
        "",
        "✅ — GPU разрешена для автоаренды",
        "❌ — GPU исключена из автоаренды",
    ]
    if selected == 0:
        lines.extend(["", "⚠️ <b>Все GPU отключены.</b> Автоаренда брать ничего не будет."])
    return "\n".join(lines)


def build_gpu_filter_keyboard():
    enabled = set(get_enabled_gpus())
    rows = []
    for i in range(0, len(ALLOWED_GPUS), 2):
        row = []
        for key in ALLOWED_GPUS[i:i + 2]:
            if key not in GPU_ALIASES:
                continue
            mark = "✅" if key in enabled else "❌"
            row.append({
                "text": f"{mark} {gpu_display_name(key)}",
                "callback_data": f"gpu_filter:{key}",
            })
        if row:
            rows.append(row)
    rows.append([
        {"text": "✅ ВСЕ", "callback_data": "gpu_filter_all:on"},
        {"text": "❌ НИ ОДНОЙ", "callback_data": "gpu_filter_all:off"},
    ])
    rows.append([{"text": "↩️ НАЗАД", "callback_data": "gpu_filter_back"}])
    return {"inline_keyboard": rows}


def format_reserved_prepay_menu() -> str:
    amount = get_reserved_prepay_amount()
    status = "ВКЛЮЧЁН" if amount > 0 else "ВЫКЛЮЧЕН"
    return (
        "💳 <b>RESERVED PREPAY</b>\n\n"
        f"Текущая сумма: <code>${amount:.2f}</code>\n"
        f"Статус: <code>{status}</code>\n\n"
        "Введи сумму prepay одним сообщением, например: <code>5</code> или <code>2.50</code>.\n"
        "Можно использовать запятую: <code>2,50</code>.\n\n"
        "Чтобы отключить RESERVED prepay: <code>0</code>."
    )


def build_reserved_prepay_keyboard() -> dict:
    return {
        "inline_keyboard": [
            [
                {"text": "✏️ ЗАДАТЬ СУММУ", "callback_data": "reserved_prepay_set"},
                {"text": "0 — ВЫКЛ", "callback_data": "reserved_prepay_zero"},
            ],
            [
                {"text": "$1", "callback_data": "reserved_prepay_quick:1"},
                {"text": "$5", "callback_data": "reserved_prepay_quick:5"},
                {"text": "$10", "callback_data": "reserved_prepay_quick:10"},
            ],
            [{"text": "↩️ НАЗАД", "callback_data": "reserved_prepay_back"}],
        ]
    }


def send_reserved_prepay_menu() -> None:
    send_message(format_reserved_prepay_menu(), build_reserved_prepay_keyboard())


def format_auto_prices_menu(mode: str = "on-demand") -> str:
    mode = _normalize_rent_mode(mode)
    labels = {
        "on-demand": "ON-DEMAND",
        "interruptible": "INTERRUPTIBLE",
    }
    ranges = get_auto_price_ranges_snapshot(mode=mode)
    lines = [
        f"⚙️ <b>ЦЕНЫ {labels[mode]}</b>",
        "",
        "Цена указана за <b>1 GPU / 24 часа</b>.",
        "Vast списывает почасово; бот использует суточный эквивалент для фильтра.",
        "",
    ]
    for gpu_key in ALLOWED_GPUS:
        limits = ranges.get(gpu_key)
        if limits is None:
            continue
        lines.append(
            f"✅ <code>{html.escape(gpu_display_name(gpu_key))}</code> — "
            f"<code>${limits[0]:.2f}–${limits[1]:.2f}/24ч</code>"
        )
    lines.append("")
    lines.append("Выбери GPU для изменения диапазона.")
    return "\n".join(lines)


def build_auto_prices_keyboard(mode: str = "on-demand"):
    mode = _normalize_rent_mode(mode)
    rows = [
        [
            {"text": "🟢 ON-DEMAND", "callback_data": "prices_mode:on-demand"},
            {"text": "🟡 INTERRUPTIBLE", "callback_data": "prices_mode:interruptible"},
        ],
    ]
    for gpu_key in ALLOWED_GPUS:
        limits = get_auto_gpu_price_range(gpu_key, mode=mode)
        if limits is None:
            continue
        rows.append([{
            "text": f"{gpu_display_name(gpu_key)} ${limits[0]:.2f}–${limits[1]:.2f}",
            "callback_data": f"auto_gpu:{mode}:{gpu_key}",
        }])
    rows.append([{"text": "↩️ НАЗАД", "callback_data": "auto_prices_back"}])
    return {"inline_keyboard": rows}


def format_auto_gpu_detail(gpu_key: str, mode: str = "on-demand") -> str:
    mode = _normalize_rent_mode(mode)
    limits = get_auto_gpu_price_range(gpu_key, mode=mode)
    if limits is None:
        return "❌ GPU не настроена."
    return (
        f"⚙️ <b>{html.escape(gpu_display_name(gpu_key))} · {mode.upper()}</b>\n\n"
        f"Минимум: <code>${limits[0]:.2f}/24ч</code>\n"
        f"Максимум: <code>${limits[1]:.2f}/24ч</code>\n\n"
        "Кнопки меняют минимум и максимум на $0.10: ➖ / ➕ отдельно для каждого значения."
    )


def build_auto_gpu_detail_keyboard(gpu_key: str, mode: str = "on-demand"):
    mode = _normalize_rent_mode(mode)
    return {
        "inline_keyboard": [
            [
                {"text": "➖ Мин $0.10", "callback_data": f"price:{mode}:min:-0.10:{gpu_key}"},
                {"text": "➕ Мин $0.10", "callback_data": f"price:{mode}:min:+0.10:{gpu_key}"},
            ],
            [
                {"text": "➖ Макс $0.10", "callback_data": f"price:{mode}:max:-0.10:{gpu_key}"},
                {"text": "➕ Макс $0.10", "callback_data": f"price:{mode}:max:+0.10:{gpu_key}"},
            ],
            [{"text": "↩️ К ТИПАМ", "callback_data": "auto_prices"}],
        ]
    }


def format_status() -> str:
    sync_ok = refresh_active_rented_state(force_refresh=True)
    active = get_active_rental_count()
    limit = get_max_active_rigs()
    account = get_account(force_refresh=True)
    credit = to_float(account.get("credit"), None)
    balance = to_float(account.get("balance"), None)
    paused_manual = is_auto_on_demand_paused()
    with _active_limit_pause_lock:
        limit_paused = _active_limit_pause

    lines = [
        "📊 <b>Status Vast.ai</b>",
        "",
        f"Blacklist machine: <code>{len(blacklist_set)}</code>",
        f"Active instances: <code>{active}</code> / <code>{limit}</code>",
        f"Active limit gate: <code>{'ПАУЗА' if limit_paused else 'РАБОТАЕТ'}</code>",
        f"Vast sync: <code>{'OK' if sync_ok else 'ERROR — NEW RENTALS BLOCKED'}</code>",
        f"Auto ON-DEMAND: <code>{_mode_auto_enabled('on-demand')}</code>",
        f"Manual ON-DEMAND pause: <code>{paused_manual}</code>",
        f"Auto INTERRUPTIBLE: <code>{_mode_auto_enabled('interruptible')}</code>",
        f"Manual INTERRUPTIBLE pause: <code>{is_auto_interruptible_paused()}</code>",
        f"Автоскан marketplace: <code>{MARKETPLACE_AUTO_NOTIFY}</code>",
        f"Интервал автосканирования: <code>{MARKETPLACE_NOTIFY_INTERVAL:g}с</code>",
    ]
    if credit is not None:
        lines.append(f"Credit: <code>${credit:.6f}</code>")
    elif balance is not None:
        lines.append(f"Balance: <code>${balance:.6f}</code>")
    else:
        lines.append("Credit: <code>нет данных</code>")

    # Current run-rate is much more defensible than inventing an exact 24h
    # spend figure from changing instance start/stop times.
    try:
        instances = get_instances(force_refresh=False)
        active_instances = [x for x in instances if is_instance_active(x)]
        hourly = sum(
            max(0.0, to_float(x.get("dph_total"), 0.0) or 0.0)
            for x in active_instances
        )
        lines.append(f"Текущая ставка: <code>${hourly:.6f}/ч</code> (~<code>${hourly*24:.6f}/24ч</code>)")
    except Exception:
        pass
    return "\n".join(lines)


def format_stats() -> str:
    instances = get_instances(force_refresh=True)
    active_instances = [x for x in instances if is_instance_active(x)]
    lines = [
        "📊 <b>Активные инстансы Vast.ai</b>",
        "",
        f"Всего возвращено API: <code>{len(instances)}</code>",
        f"Активных: <code>{len(active_instances)}</code>",
        "",
    ]
    if not active_instances:
        lines.append("📭 Активных инстансов нет.")
        return "\n".join(lines)
    for inst in active_instances[:30]:
        lines.extend(["", format_instance(inst)])
    if len(active_instances) > 30:
        lines.extend(["", f"… и ещё <code>{len(active_instances)-30}</code>."])
    return "\n".join(lines)


def send_start_message():
    """Show the main control panel and always ensure its inline keyboard is attached."""
    refresh_active_rented_state(force_refresh=False)
    active = get_active_rental_count()
    auto_flags = _auto_mode_flags_snapshot()
    auto_configured = any((AUTO_ON_DEMAND, AUTO_INTERRUPTIBLE, AUTO_RESERVED))
    auto_enabled = any(auto_flags.values())
    if auto_enabled:
        auto_status = "РАБОТАЕТ"
    elif auto_configured:
        auto_status = "ПАУЗА"
    else:
        auto_status = "ВЫКЛЮЧЕНА"
    limit = get_max_active_rigs()
    selected_gpus = get_enabled_gpus()
    selected_gpu_text = ", ".join(gpu_display_name(x) for x in selected_gpus) if selected_gpus else "нет"

    text = (
        "🤖 <b>Vast.ai GPU Bot</b>\n\n"
        f"Auto ON-DEMAND: <code>{AUTO_ON_DEMAND}</code>\n"
        f"Статус автоаренды: <code>{auto_status}</code>\n"
        f"Auto INTERRUPTIBLE: <code>{AUTO_INTERRUPTIBLE}</code>\n"
        f"Активных ригов: <code>{active}</code>/<code>{limit}</code>\n"
        f"GPU фильтр: <code>{html.escape(selected_gpu_text)}</code>\n"
        f"Автоскан marketplace: <code>{MARKETPLACE_AUTO_NOTIFY}</code>\n"
        f"Интервал сканирования: <code>{MARKETPLACE_NOTIFY_INTERVAL:g}с</code>\n\n"
        "Управление — кнопками ниже.\n"
        "📡 Marketplace обновляется отдельным сообщением."
    )
    markup = build_auto_rent_keyboard()
    signature = hashlib.sha256(
        (text + "\n" + json.dumps(markup, sort_keys=True, ensure_ascii=False)).encode("utf-8")
    ).hexdigest()

    with state_lock:
        existing_id = to_int(state.get("control_message_id"), None)
        existing_hash = str(state.get("control_message_hash", "") or "")

    # Always re-apply the keyboard to the saved control message.  Telegram
    # can lose/strip inline markup after an old message edit or after a bot
    # restart; the text/hash alone is not proof that the keyboard is still
    # attached.
    if existing_id is not None:
        result = edit_message(text, existing_id, markup)
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state["control_message_hash"] = signature
            save_state()
            if (result.get("result") or {}).get("not_modified"):
                logger.debug("Главное меню уже актуально, повторное редактирование не требуется")
            return True

        description = str(result.get("description", "")) if isinstance(result, dict) else ""
        logger.warning("Не удалось обновить главное меню: %s", description[:300])

    result = send_message(text, markup)
    if isinstance(result, dict) and result.get("ok"):
        new_id = (result.get("result") or {}).get("message_id")
        try:
            new_id = int(new_id)
        except (TypeError, ValueError):
            new_id = None
        with state_lock:
            state["control_message_id"] = new_id
            state["control_message_hash"] = signature
        save_state()
        logger.info("Главное меню Telegram отправлено, message_id=%s", new_id)
        return True

    logger.warning("Не удалось отправить главное меню Telegram")
    return False


def build_bid_menu_keyboard(instances: Optional[list[dict]] = None) -> dict:
    if instances is None:
        try:
            instances = get_instances(force_refresh=False)
        except Exception:
            instances = []

    rows = []
    for inst in instances:
        iid = get_instance_id(inst)
        if iid is None or not is_bid_instance(inst):
            continue
        own = get_tracked_bid(iid)
        gpu = get_gpu_name(inst) or "GPU"
        if own is None:
            label = f"💰 {iid} | {gpu[:20]} | не отслеживается"
        else:
            min_bid = to_float(inst.get("min_bid"), None)
            suffix = " ⚠️" if min_bid is not None and min_bid > own + 1e-9 else ""
            label = f"💰 {iid} | ${own:.2f}/ч{suffix}"
        rows.append([{
            "text": label[:64],
            "callback_data": f"bid_show:{iid}",
        }])

    rows.append([{"text": "↩️ НАЗАД", "callback_data": "bid_menu_back"}])
    return {"inline_keyboard": rows}


def send_bid_menu():
    try:
        instances = get_instances(force_refresh=True)
    except Exception as exc:
        send_message(f"❌ Не удалось получить instances: <code>{html.escape(short_error(exc))}</code>")
        return

    bids = [x for x in instances if is_bid_instance(x) and get_instance_id(x) is not None]
    if not bids:
        send_message("💰 <b>INTERRUPTIBLE ставки</b>\n\nАктивных BID-инстансов не найдено.")
        return

    send_message(
        "💰 <b>INTERRUPTIBLE ставки</b>\n\nВыбери instance для просмотра и изменения ставки.",
        build_bid_menu_keyboard(instances),
    )


def _build_control_panel_content() -> tuple[str, dict]:
    """Build the same main menu content used by send_start_message."""
    active = get_active_rental_count()
    auto_flags = _auto_mode_flags_snapshot()
    auto_configured = any((AUTO_ON_DEMAND, AUTO_INTERRUPTIBLE, AUTO_RESERVED))
    auto_enabled = any(auto_flags.values())
    if auto_enabled:
        auto_status = "РАБОТАЕТ"
    elif auto_configured:
        auto_status = "ПАУЗА"
    else:
        auto_status = "ВЫКЛЮЧЕНА"
    limit = get_max_active_rigs()
    selected_gpus = get_enabled_gpus()
    selected_gpu_text = ", ".join(gpu_display_name(x) for x in selected_gpus) if selected_gpus else "нет"
    text = (
        "🤖 <b>Vast.ai GPU Bot</b>\n\n"
        f"Auto ON-DEMAND: <code>{AUTO_ON_DEMAND}</code>\n"
        f"Статус автоаренды: <code>{auto_status}</code>\n"
        f"Auto INTERRUPTIBLE: <code>{AUTO_INTERRUPTIBLE}</code>\n"
        f"Активных ригов: <code>{active}</code>/<code>{limit}</code>\n"
        f"GPU фильтр: <code>{html.escape(selected_gpu_text)}</code>\n"
        f"Автоскан marketplace: <code>{MARKETPLACE_AUTO_NOTIFY}</code>\n"
        f"Интервал сканирования: <code>{MARKETPLACE_NOTIFY_INTERVAL:g}с</code>\n\n"
        "Управление — кнопками ниже.\n"
        "📡 Marketplace обновляется отдельным сообщением."
    )
    return text, build_auto_rent_keyboard()


def _edit_message_to_control_panel(message_id: int) -> None:
    try:
        text_value, markup = _build_control_panel_content()
        result = edit_message(text_value, message_id, markup)
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state["control_message_id"] = int(message_id)
            save_state()
            logger.info("✅ Главное меню открыто в том же сообщении, message_id=%s", message_id)
            return
        logger.warning("Не удалось открыть главное меню в message_id=%s: %s", message_id, result)
        send_start_message()
    except Exception as exc:
        logger.exception("Ошибка возврата в главное меню: %s", exc)
        send_start_message()


def send_market_menu(message_id: Optional[int] = None):
    """Open/refresh marketplace without blocking Telegram callback processing.

    When called from a callback, pass the callback message_id so the live
    marketplace replaces the currently displayed detail in the SAME message.
    """
    kwargs = {"force_refresh": True}
    if message_id is not None:
        kwargs["target_message_id"] = int(message_id)
    threading.Thread(
        target=update_live_marketplace_message,
        kwargs=kwargs,
        daemon=True,
        name="vast-market-manual",
    ).start()


def handle_callback(callback):
    callback_id = str(callback.get("id", ""))
    data = str(callback.get("data", ""))
    logger.info("🔘 Telegram callback получен: %s", data)
    if callback_id:
        answer_callback(callback_id, "⏳ Обрабатываю...")

    if data in {"cmd_stats", "cmd_status", "cmd_market", "cmd_scan", "cmd_prices"}:
        message_obj = callback.get("message") or {}
        clicked_message_id = to_int(message_obj.get("message_id"), None)
        if data == "cmd_market":
            send_market_menu(message_id=clicked_message_id)
        elif data == "cmd_scan":
            send_market_menu(message_id=clicked_message_id)
        elif data == "cmd_stats":
            send_message(format_stats())
        elif data == "cmd_status":
            send_message(format_status())
        elif data == "cmd_prices":
            send_message(format_auto_prices_menu(), build_auto_prices_keyboard())
        return

    if data.startswith("auto_disabled:"):
        if callback_id:
            answer_callback(callback_id, "AUTO-аренда отключена в конфигурации; marketplace работает в ручном режиме")
        return

    if data == "auto_od_pause":
        set_auto_on_demand_paused(True); send_start_message(); return
    if data == "auto_od_start":
        set_auto_on_demand_paused(False); send_start_message(); return
    if data == "auto_bid_pause":
        set_auto_interruptible_paused(True); send_start_message(); return
    if data == "auto_bid_start":
        set_auto_interruptible_paused(False); send_start_message(); return
    if data in {"auto_reserved_pause", "auto_reserved_start", "reserved_prepay_menu", "reserved_prepay_back", "reserved_prepay_set", "reserved_prepay_cancel", "reserved_prepay_zero"} or data.startswith("reserved_prepay_quick:"):
        if callback_id:
            answer_callback(callback_id, "RESERVED отключён")
        send_start_message()
        return

    if data == "bid_menu":
        send_bid_menu(); return
    if data == "bid_menu_back":
        send_start_message(); return
    if data.startswith("bid_show:"):
        try:
            iid = int(data.split(":", 1)[1])
            text = get_bid_instance_summary(iid)
            if text is None:
                send_message(f"❌ Instance <code>{iid}</code> больше не найден.")
                return
            send_message(text, build_bid_control_keyboard(iid))
        except Exception as exc:
            send_message(f"❌ Ошибка: <code>{html.escape(short_error(exc))}</code>")
        return
    if data.startswith("bid_raise:"):
        try:
            iid = int(data.split(":", 1)[1])
            current = get_tracked_bid(iid)
            if current is None:
                raise RuntimeError("Текущая ставка этого instance не отслеживается ботом.")

            new_bid = round(current + BID_RAISE_STEP, 2)
            change_vast_bid(iid, new_bid)

            if callback_id:
                answer_callback(callback_id, f"Ставка: ${new_bid:.2f}/ч")
            send_message(
                "✅ <b>Ставка повышена</b>\n\n"
                f"Instance: <code>{iid}</code>\n"
                f"Новая ставка: <code>${new_bid:.2f}/ч</code>\n\n"
                f"Шаг изменения: <code>${BID_RAISE_STEP:.2f}/ч</code>",
                build_bid_control_keyboard(iid),
            )
        except Exception as exc:
            if callback_id:
                answer_callback(callback_id, short_error(exc, 180))
            send_message(f"❌ <b>Не удалось повысить ставку</b>\n\n<code>{html.escape(short_error(exc, 500))}</code>")
        return

    if data == "ban_menu":
        send_ban_menu(); return
    if data == "ban_menu_back":
        send_start_message(); return
    if data == "unban_menu":
        send_unban_menu(); return
    if data == "unban_menu_back":
        send_start_message(); return

    if data == "reserved_prepay_menu":
        send_reserved_prepay_menu(); return
    if data == "reserved_prepay_back":
        send_start_message(); return
    if data == "reserved_prepay_set":
        set_pending_reserved_prepay(True)
        send_message(
            "✏️ <b>Укажи RESERVED prepay</b>\n\n"
            "Напиши сумму одним сообщением, например <code>5</code> или <code>2.50</code>.\n"
            "Для отключения введи <code>0</code>.",
            {"inline_keyboard": [[{"text": "❌ ОТМЕНА", "callback_data": "reserved_prepay_cancel"}]]},
        )
        return
    if data == "reserved_prepay_cancel":
        set_pending_reserved_prepay(False)
        if callback_id:
            answer_callback(callback_id, "Отменено")
        send_reserved_prepay_menu()
        return
    if data == "reserved_prepay_zero":
        amount = set_reserved_prepay_amount(0)
        if callback_id:
            answer_callback(callback_id, "RESERVED prepay выключен")
        send_reserved_prepay_menu()
        logger.info("RESERVED prepay установлен через Telegram: $%.2f", amount)
        return
    if data.startswith("reserved_prepay_quick:"):
        try:
            amount = float(data.split(":", 1)[1])
            amount = set_reserved_prepay_amount(amount)
            if callback_id:
                answer_callback(callback_id, f"Prepay: ${amount:.2f}")
            send_reserved_prepay_menu()
            logger.info("RESERVED prepay установлен через Telegram: $%.2f", amount)
        except Exception as exc:
            if callback_id:
                answer_callback(callback_id, short_error(exc, 180))
        return

    if data == "rental_limit":
        send_message(format_rental_limit_menu(), build_rental_limit_keyboard()); return
    if data == "rental_limit_back":
        send_start_message(); return
    if data.startswith("rental_limit:"):
        try:
            delta = int(data.split(":", 1)[1])
            if delta == 0:
                send_message(format_rental_limit_menu(), build_rental_limit_keyboard()); return
            new_limit = adjust_max_active_rigs(delta)
            if callback_id:
                answer_callback(callback_id, f"Лимит: {new_limit}")
            refresh_active_rented_state(force_refresh=True)
            _active_limit_gate_allows_marketplace()
            send_message(format_rental_limit_menu(), build_rental_limit_keyboard())
        except Exception as exc:
            if callback_id: answer_callback(callback_id, short_error(exc, 180))
        return

    if data == "gpu_filter_menu":
        send_message(format_gpu_filter_menu(), build_gpu_filter_keyboard()); return
    if data == "gpu_filter_back":
        send_start_message(); return
    if data.startswith("gpu_filter_all:"):
        action = data.split(":", 1)[1]
        set_enabled_gpus(ALLOWED_GPUS if action == "on" else [])
        send_message(format_gpu_filter_menu(), build_gpu_filter_keyboard())
        return
    if data.startswith("gpu_filter:"):
        try:
            key = data.split(":", 1)[1]
            selected = toggle_gpu_filter(key)
            if callback_id:
                answer_callback(callback_id, f"{gpu_display_name(key)}: {'ON' if selected else 'OFF'}")
            send_message(format_gpu_filter_menu(), build_gpu_filter_keyboard())
        except Exception as exc:
            if callback_id:
                answer_callback(callback_id, short_error(exc, 180))
        return

    if data == "auto_prices":
        send_message(format_auto_prices_menu(), build_auto_prices_keyboard()); return
    if data == "auto_prices_back":
        send_start_message(); return
    if data.startswith("prices_mode:"):
        mode = _normalize_rent_mode(data.split(":", 1)[1])
        if mode not in {"on-demand", "interruptible"}:
            if callback_id:
                answer_callback(callback_id, "RESERVED отключён")
            return
        send_message(format_auto_prices_menu(mode), build_auto_prices_keyboard(mode)); return
    if data.startswith("auto_gpu:"):
        parts = data.split(":", 2)
        if len(parts) != 3:
            return
        _, mode, gpu_key = parts
        mode = _normalize_rent_mode(mode)
        if gpu_key not in ALLOWED_GPUS:
            return
        send_message(format_auto_gpu_detail(gpu_key, mode), build_auto_gpu_detail_keyboard(gpu_key, mode)); return
    if data.startswith("price:"):
        parts = data.split(":", 4)
        if len(parts) != 5:
            return
        _, mode, which, delta_text, gpu_key = parts
        try:
            min_price, max_price = adjust_auto_gpu_price(gpu_key, which, float(delta_text), mode=mode)
            if callback_id:
                answer_callback(callback_id, f"${min_price:.2f}–${max_price:.2f}/24ч")
            send_message(format_auto_gpu_detail(gpu_key, mode), build_auto_gpu_detail_keyboard(gpu_key, mode))
        except Exception as exc:
            if callback_id: answer_callback(callback_id, short_error(exc, 180))
        return

    if data.startswith("ban:"):
        try:
            machine_id = int(data.split(":", 1)[1])
            ban_machine(machine_id)
            send_message(f"🚫 Machine <code>{machine_id}</code> добавлен в blacklist.")
        except Exception as exc:
            send_message(f"❌ Ошибка: <code>{html.escape(short_error(exc))}</code>")
        return
    if data.startswith("unban:"):
        try:
            machine_id = int(data.split(":", 1)[1])
            ok, msg = unban_machine(machine_id)
            send_message(f"🔓 Machine <code>{machine_id}</code> удалён из blacklist." if ok else f"ℹ️ <code>{html.escape(msg)}</code>")
        except Exception as exc:
            send_message(f"❌ Ошибка: <code>{html.escape(short_error(exc))}</code>")
        return

    if data.startswith("market_gpu:"):
        # Expand the selected GPU inside the SAME marketplace message.
        # This keeps the UI compact and avoids creating a new Telegram message
        # every time the user opens a GPU. Network work runs in a background
        # thread so Telegram polling stays responsive.
        try:
            _, mode, gpu_key = data.split(":", 2)
            message_obj = callback.get("message") or {}
            live_message_id = to_int(message_obj.get("message_id"), None)
            if live_message_id is None:
                with state_lock:
                    live_message_id = to_int(state.get("marketplace_live_message_id"), None)

            if callback_id:
                answer_callback(callback_id, "🔄 Загружаю варианты...")

            def _load_gpu_detail() -> None:
                try:
                    detail_text, detail_markup = _build_gpu_mode_detail(mode, gpu_key)
                    if live_message_id is not None:
                        result = edit_message(detail_text, live_message_id, detail_markup)
                        if isinstance(result, dict) and result.get("ok"):
                            logger.info(
                                "✅ Marketplace GPU detail открыт: mode=%s gpu=%s message_id=%s",
                                mode, gpu_key, live_message_id,
                            )
                            return

                    # Fallback only when the original marketplace message is
                    # unavailable (for example, it was deleted in Telegram).
                    send_message(detail_text, detail_markup)
                except Exception as exc:
                    logger.exception(
                        "Marketplace GPU detail error: mode=%s gpu=%s: %s",
                        mode, gpu_key, exc,
                    )
                    error_text = (
                        f"❌ <b>Не удалось открыть {html.escape(gpu_display_name(gpu_key))}</b>\n\n"
                        f"<code>{html.escape(short_error(exc, 700))}</code>"
                    )
                    if live_message_id is not None:
                        edit_message(
                            error_text,
                            live_message_id,
                            {
                                "inline_keyboard": [
                                    [{"text": "↩️ К MARKETPLACE", "callback_data": "market_live_refresh"}],
                                ]
                            },
                        )
                    else:
                        send_message(error_text)

            threading.Thread(
                target=_load_gpu_detail,
                daemon=True,
                name="vast-market-gpu-detail",
            ).start()
        except Exception as exc:
            if callback_id:
                answer_callback(callback_id, short_error(exc, 180))
        return

    if data.startswith("rent_reserved:"):
        if callback_id:
            answer_callback(callback_id, "RESERVED отключён")
        send_message("🚫 <b>RESERVED отключён</b>")
        return

    rent_callbacks = {
        "rent_od": "on-demand",
        "rent_bid": "interruptible",
    }
    for prefix, mode in rent_callbacks.items():
        if data.startswith(prefix + ":"):
            try:
                parts = data.split(":")
                oid = int(parts[1])
                machine_id = int(parts[2]) if len(parts) >= 3 and parts[2] else None

                logger.info(
                    "🔘 Telegram rent callback: mode=%s offer=%s machine=%s",
                    mode.upper(),
                    oid,
                    machine_id,
                )

                # Manual Telegram buttons can easily become stale.
                # Prefer resolving a CURRENT offer for the same machine and
                # requested mode instead of accepting the old offer_id.
                # This avoids sending a stale PUT /asks/{old_id} and getting
                # a normal HTTP 410 from Vast.
                offer = None
                if machine_id is not None:
                    # Search Vast directly by machine_id and requested mode,
                    # rather than scanning only the generic top offers.
                    # Preserve the original offer shape so sliced GPU offers
                    # are not silently replaced by a different slice.
                    reference_offer = None
                    for cached_mode in (mode, "on-demand", "interruptible", "reserved"):
                        try:
                            cached_offers = get_marketplace(
                                mode=cached_mode,
                                force_refresh=False,
                            )
                        except Exception:
                            cached_offers = []
                        for cached_offer in cached_offers:
                            if offer_id(cached_offer) == oid:
                                reference_offer = cached_offer
                                break
                        if reference_offer is not None:
                            break

                    offer = _find_fresh_offer_for_machine(
                        machine_id,
                        mode=mode,
                        auto=False,
                        retries=3,
                        reference_offer=reference_offer,
                    )

                # Fallback for old Telegram messages that do not carry a
                # machine_id in their callback_data.
                if offer is None and machine_id is None:
                    offer = find_offer_fresh(oid, mode=mode)

                if offer is None:
                    # The machine may still exist, but not currently publish
                    # an offer of the requested mode. Tell the user exactly
                    # what happened instead of leaving the button seemingly
                    # broken.
                    send_message(
                        f"⚠️ <b>{mode.upper()} offer больше недоступен</b>\n\n"
                        f"Старый offer: <code>{oid}</code>\n"
                        f"Machine: <code>{machine_id if machine_id is not None else '?'}</code>\n\n"
                        "Vast больше не отдаёт этот machine в выбранном режиме. "
                        "Кнопка была устаревшей; новые offers появятся автоматически, "
                        "когда machine снова станет доступен."
                    )
                    return

                # Manual rent deliberately ignores auto price filters. The
                # exact offer was selected by the user in Telegram.
                if rent_offer(offer, mode=mode, auto=False):
                    if callback_id:
                        answer_callback(callback_id, "✅ Запрос на аренду отправлен")
            except Exception as exc:
                logger.exception("Telegram manual rent callback error: %s", exc)
                if callback_id:
                    answer_callback(callback_id, short_error(exc, 180))
                send_message(
                    f"❌ <b>Ошибка {mode.upper()} аренды Vast.ai</b>\n\n"
                    f"<code>{html.escape(short_error(exc, 700))}</code>"
                )
            return

    if data == "market_live_refresh":
        if callback_id:
            answer_callback(callback_id, "🔄 Обновляю marketplace...")
        message_obj = callback.get("message") or {}
        current_message_id = to_int(message_obj.get("message_id"), None)
        send_market_menu(message_id=current_message_id)
        return

    if data == "market_live_back":
        if callback_id:
            answer_callback(callback_id, "🏠")
        # Replace the current marketplace message with the control panel
        # instead of creating a second menu somewhere below it.
        message_obj = callback.get("message") or {}
        current_message_id = to_int(message_obj.get("message_id"), None)
        if current_message_id is not None:
            threading.Thread(
                target=_edit_message_to_control_panel,
                args=(current_message_id,),
                daemon=True,
                name="vast-control-from-market",
            ).start()
        else:
            send_start_message()
        return

    logger.warning("Неизвестный Telegram callback: %s", data)


def handle_message(message):
    text_value = str(message.get("text", "") or "").strip()
    chat = message.get("chat", {}) or {}
    chat_id = str(chat.get("id", ""))
    if chat_id != str(TG_CHAT_ID):
        return

    # Handle a RESERVED prepay amount entered after pressing the Telegram button.
    if is_waiting_reserved_prepay() and not text_value.startswith("/"):
        raw_amount = text_value.replace(",", ".").replace("$", "").strip()
        try:
            amount = float(raw_amount)
            if not (amount >= 0):
                raise ValueError
            amount = set_reserved_prepay_amount(amount)
            send_message(
                "✅ <b>RESERVED prepay сохранён</b>\n\n"
                f"Новая сумма: <code>${amount:.2f}</code>\n"
                + (
                    "🔵 RESERVED снова готов к автозахвату."
                    if amount > 0 else
                    "⏸ RESERVED автозахват приостановлен, пока сумма = $0.00."
                ),
                build_reserved_prepay_keyboard(),
            )
            return
        except Exception:
            send_message(
                "❌ <b>Неверная сумма</b>\n\n"
                "Введи число, например <code>5</code>, <code>2.50</code> или <code>2,50</code>.\n"
                "Для отключения введи <code>0</code>.",
            )
            return

    if text_value == "/prepay":
        send_reserved_prepay_menu()
        return
    if text_value.startswith("/prepay "):
        raw_amount = text_value.split(" ", 1)[1].replace(",", ".").replace("$", "").strip()
        try:
            amount = set_reserved_prepay_amount(float(raw_amount))
            send_reserved_prepay_menu()
        except Exception as exc:
            send_message(f"❌ <code>{html.escape(short_error(exc, 300))}</code>")
        return

    if text_value == "/start":
        send_start_message()
        return
    if text_value == "/status":
        send_message(format_status())
        return
    if text_value == "/stats":
        send_message(format_stats())
        return
    if text_value == "/market":
        send_market_menu()
        return
    if text_value == "/scan":
        send_message("🔎 Обновляю marketplace Vast.ai...")
        send_market_menu()
        return
    if text_value == "/prices":
        send_message(format_auto_prices_menu(), build_auto_prices_keyboard())
        return
    if text_value == "/gpu":
        send_message(format_gpu_filter_menu(), build_gpu_filter_keyboard())
        return
    if text_value == "/bids":
        send_bid_menu()
        return
    if text_value == "/limit":
        send_message(format_rental_limit_menu(), build_rental_limit_keyboard())
        return


# ============================================================
# TELEGRAM POLLING
# ============================================================

def discard_pending_telegram_updates() -> Optional[int]:
    try:
        result = telegram_request(
            "getUpdates",
            {
                "offset": -1,
                "limit": 1,
                "timeout": 0,
                "allowed_updates": ["message", "callback_query"],
            },
            timeout=10,
        )
        updates = result.get("result", []) if result else []
        if updates:
            return int(updates[-1]["update_id"]) + 1
    except Exception as exc:
        logger.warning("Не удалось очистить старые Telegram updates: %s", exc)
    return None


def telegram_polling():
    logger.info("Telegram polling запущен")
    offset = discard_pending_telegram_updates()

    while True:
        try:
            payload = {
                "timeout": 25,
                "allowed_updates": ["message", "callback_query"],
            }
            if offset is not None:
                payload["offset"] = offset

            result = telegram_request("getUpdates", payload, timeout=35)
            if not result:
                time.sleep(2)
                continue

            for update in result.get("result", []):
                offset = int(update["update_id"]) + 1
                try:
                    if "callback_query" in update:
                        handle_callback(update["callback_query"])
                    elif "message" in update:
                        handle_message(update["message"])
                except Exception as exc:
                    logger.exception("Ошибка обработки Telegram update: %s", exc)
        except Exception as exc:
            logger.error("Telegram polling error: %s", exc)
            time.sleep(5)


# ============================================================
# MAIN LOOP
# ============================================================

def marketplace_loop():
    logger.info("Marketplace loop Vast.ai запущен (FAST)")
    last_market_notify = 0.0
    last_auto_scan = 0.0
    first_cycle = True

    while True:
        try:
            now = time.monotonic()
            mode_flags = _auto_mode_flags_snapshot()
            auto_enabled = any(mode_flags.values())
            with state_lock:
                has_bids = bool(state.get("bid_tracking"))

            # Keep the real active-instance cache warm.  The cache TTL means
            # this is normally a local operation, not an API request.
            sync_ok = refresh_active_rented_state(force_refresh=False)

            # AUTO RENT HAS PRIORITY.  On the first pass run immediately;
            # afterwards scan according to SCAN_DELAY instead of repeating the
            # same cached work every second.
            if sync_ok and auto_enabled and (first_cycle or now - last_auto_scan >= max(0.5, SCAN_DELAY)):
                check_marketplace(already_synced=True)
                last_auto_scan = time.monotonic()

            if sync_ok and has_bids:
                check_interruptible_bid_status()

            # Marketplace Telegram display is lower priority than renting.
            # It shares the same cache, so this usually adds no Vast calls.
            if (
                MARKETPLACE_AUTO_NOTIFY
                and (first_cycle or now - last_market_notify >= max(2.0, MARKETPLACE_NOTIFY_INTERVAL))
            ):
                scan_and_notify_marketplace_offers(force_refresh=False)
                last_market_notify = time.monotonic()

            first_cycle = False

        except Exception as exc:
            logger.exception("Ошибка marketplace loop Vast: %s", exc)

        # Wake frequently enough to react quickly after a successful rental,
        # but do not issue an API request on every wakeup.
        time.sleep(0.25)


def main():
    load_state()

    logger.info("======================================")
    logger.info("Vast.ai GPU Telegram Bot")
    logger.info("Vast API: %s", VAST_BASE_URL)
    logger.info("Image: %s", VAST_IMAGE)
    logger.info("Runtype: %s", VAST_RUNTYPE)
    logger.info("Disk: %s GB", VAST_DISK_GB)
    logger.info("Auto ON-DEMAND: %s", AUTO_ON_DEMAND)
    logger.info("Auto INTERRUPTIBLE: %s", AUTO_INTERRUPTIBLE)
    logger.info("Auto capture modes: ON-DEMAND=%s | INTERRUPTIBLE=%s | RESERVED=DISABLED", AUTO_ON_DEMAND, AUTO_INTERRUPTIBLE)
    logger.info("Active rental limit: %s", get_max_active_rigs())
    logger.info("Speed profile: auto-first | API gate=%ss | marketplace cache=%ss | scan=%ss", VAST_GET_MIN_INTERVAL, MARKETPLACE_CACHE_TTL, SCAN_DELAY)
    logger.info("FAST scan delay: %s sec", SCAN_DELAY)
    logger.info("Active instance sync TTL: %s sec", ACTIVE_INSTANCE_SYNC_TTL)
    logger.info("======================================")

    logger.info("🔄 Проверяю уже существующие активные инстансы Vast.ai...")
    if refresh_active_rented_state(force_refresh=True):
        logger.info(
            "✅ Стартовая синхронизация: %s/%s активных ригов",
            get_active_rental_count(),
            get_max_active_rigs(),
        )
        _active_limit_gate_allows_marketplace()
    else:
        logger.warning("⛔ Стартовая синхронизация не удалась. Новые аренды заблокированы.")

    telegram_thread = threading.Thread(
        target=telegram_polling,
        daemon=True,
    )
    telegram_thread.start()
    send_start_message()

    # One marketplace worker owns the scan order.  It performs the auto-rent
    # scan first and only then refreshes the Telegram marketplace screen.
    # This avoids two startup requests racing for the same Vast API slot.
    threading.Thread(
        target=marketplace_loop,
        daemon=True,
        name="vast-market-loop",
    ).start()

    # Keep the main process alive; all work is done by the Telegram and
    # marketplace threads.
    while True:
        time.sleep(60)


logger.info("Vast.ai SDK mode: official vastai package; marketplace/create/instances/BID via SDK")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("Бот остановлен пользователем")
        try:
            send_message("🛑 <b>Vast.ai GPU Bot остановлен</b>")
        except Exception:
            pass
    except Exception as exc:
        logger.exception("Критическая ошибка главного процесса: %s", exc)
        try:
            send_message(
                "❌ <b>Бот аварийно остановлен</b>\n\n"
                f"<code>{html.escape(short_error(exc, 1000))}</code>"
            )
        except Exception:
            pass
