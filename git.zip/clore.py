# -*- coding: utf-8 -*-

import os
import json
import time
import logging
import re
import threading
import html
from heapq import nsmallest
from pathlib import Path
from typing import Any, Optional

import requests
from clore_ai import CloreAI


# ============================================================
# CONFIG
# ============================================================

# Set these through environment variables.
CLORE_API_KEY = os.getenv("CLORE_API_KEY", "l8Qsq53QlEA8eYVfHMDt89zh43BQQ8kL")
TG_TOKEN = os.getenv("TG_TOKEN", "8872932784:AAEVKqbrpEXc9L7W0_6y5bl3dK3RDcSv0a8")
TG_CHAT_ID = os.getenv("TG_CHAT_ID", "265459649")

if not CLORE_API_KEY:
    raise RuntimeError("Не задан CLORE_API_KEY")

if not TG_TOKEN:
    raise RuntimeError("Не задан TG_TOKEN")

if not TG_CHAT_ID:
    raise RuntimeError("Не задан TG_CHAT_ID")


# ------------------------------------------------------------
# Clore
# ------------------------------------------------------------

CLORE_CURRENCY = os.getenv("CLORE_CURRENCY", "USD-Blockchain")

DOCKER_IMAGE = "cloreai/jupyter:ubuntu24.04-v2"

SETUP_COMMAND = os.getenv("SETUP_COMMAND", "")
JUPYTER_TOKEN = os.getenv("JUPYTER_TOKEN", "qwep4ik")
SSH_PASSWORD = os.getenv("SSH_PASSWORD", "")


# ------------------------------------------------------------
# Marketplace limits — ALL LIMITS ARE PER 24 HOURS
# ------------------------------------------------------------

MIN_ON_DEMAND_DAILY = float(
    os.getenv("MIN_ON_DEMAND_DAILY", "0")
)

MAX_ON_DEMAND_DAILY = float(
    os.getenv("MAX_ON_DEMAND_DAILY", "999999")
)

MIN_SPOT_DAILY = float(
    os.getenv("MIN_SPOT_DAILY", "0")
)

MAX_SPOT_DAILY = float(
    os.getenv("MAX_SPOT_DAILY", "999999")
)


# ------------------------------------------------------------
# Scan
# ------------------------------------------------------------

SCAN_DELAY = int(
    os.getenv("SCAN_DELAY", "10")
)


# ------------------------------------------------------------
# Auto rent
# ------------------------------------------------------------

AUTO_ON_DEMAND = os.getenv(
    "AUTO_ON_DEMAND",
    "true"
).lower() in ("1", "true", "yes", "on")

AUTO_SPOT = os.getenv(
    "AUTO_SPOT",
    "false"
).lower() in ("1", "true", "yes", "on")

# When automatic SPOT renting is disabled, still notify Telegram about
# matching SPOT rigs. This never creates a SPOT order automatically.
NOTIFY_SPOT_WHEN_AUTO_DISABLED = os.getenv(
    "NOTIFY_SPOT_WHEN_AUTO_DISABLED",
    "true",
).lower() in ("1", "true", "yes", "on")
SPOT_NOTIFY_COOLDOWN = float(os.getenv("SPOT_NOTIFY_COOLDOWN", "300"))

MAX_RENT_PER_SCAN = int(
    os.getenv("MAX_RENT_PER_SCAN", "10")
)

# Automatically renew ON-DEMAND rentals created by this bot when they expire.
# Renewal is disabled while AUTO ON-DEMAND is paused.
AUTO_RENEW_ON_DEMAND = os.getenv(
    "AUTO_RENEW_ON_DEMAND",
    "true",
).lower() in ("1", "true", "yes", "on")
RENEW_CHECK_INTERVAL = float(os.getenv("RENEW_CHECK_INTERVAL", "10"))
RENEW_RETRY_DELAY = float(os.getenv("RENEW_RETRY_DELAY", "10"))
RENEW_PRICE_TOLERANCE = float(os.getenv("RENEW_PRICE_TOLERANCE", "0.0001"))
MAX_RENEWALS_PER_CHECK = int(os.getenv("MAX_RENEWALS_PER_CHECK", "20"))

# Telegram warning when an active rental has 5 minutes or less remaining.
EXPIRY_WARNING_SECONDS = int(os.getenv("EXPIRY_WARNING_SECONDS", "300"))
EXPIRY_CHECK_INTERVAL = float(os.getenv("EXPIRY_CHECK_INTERVAL", "30"))

# ------------------------------------------------------------
# Clore create_order rate limit
# ------------------------------------------------------------
# Clore's current API client documentation shows a dedicated createOrder
# queue and uses 6000 ms as a safe example interval. We enforce the same
# spacing here because this bot uses the REST endpoint directly.
CREATE_ORDER_MIN_INTERVAL = float(
    os.getenv("CREATE_ORDER_MIN_INTERVAL", "6.0")
)
CREATE_ORDER_MAX_RETRIES_429 = int(
    os.getenv("CREATE_ORDER_MAX_RETRIES_429", "4")
)
CREATE_ORDER_RETRY_DELAY = float(
    os.getenv("CREATE_ORDER_RETRY_DELAY", "6.0")
)

# ------------------------------------------------------------
# Telegram limit-error notification throttle
# ------------------------------------------------------------
# When the active-rig limit is reached, the marketplace can try several
# candidates in the same scan. Do not send the same Telegram error for every
# candidate. Auto-rent notifications are limited to one message per interval.
LIMIT_ERROR_NOTIFY_INTERVAL = float(
    os.getenv("LIMIT_ERROR_NOTIFY_INTERVAL", "600")
)
_limit_error_notify_lock = threading.Lock()
_last_limit_error_notify_monotonic = 0.0

# Auto-rent gate used when the active-rig limit is reached.
# While the gate is active, we do NOT scan marketplace or try create_order.
# We only keep synchronizing my_orders so the bot can resume immediately when
# the number of active rigs drops below the limit (or the configured limit is raised).
_active_limit_pause_lock = threading.Lock()
_active_limit_pause = False
_active_limit_pause_active = None
_active_limit_pause_limit = None

# ------------------------------------------------------------
# Global Clore API request gate
# ------------------------------------------------------------
# All normal Clore API requests from this process share one gate. This avoids
# marketplace / my_orders / wallets calls from different threads landing too
# close together and triggering HTTP 429. The SDK has its own limiter too;
# this application-level gate additionally serializes our threads.
CLORE_GET_MIN_INTERVAL = float(os.getenv("CLORE_GET_MIN_INTERVAL", "1.15"))
clore_request_gate_lock = threading.Lock()
_last_clore_request_monotonic = 0.0


def _wait_for_clore_request_slot(min_interval: Optional[float] = None):
    """Serialize all normal Clore API calls made by this process."""
    global _last_clore_request_monotonic

    interval = max(0.0, float(
        CLORE_GET_MIN_INTERVAL if min_interval is None else min_interval
    ))

    with clore_request_gate_lock:
        now = time.monotonic()
        wait_for = _last_clore_request_monotonic + interval - now
        if wait_for > 0:
            time.sleep(wait_for)
        _last_clore_request_monotonic = time.monotonic()


def _clore_sdk_call(method, *args, **kwargs):
    """Call one Clore SDK method through the process-wide request gate."""
    # The SDK also has its own rate limiter, so this is deliberately a little
    # more conservative than 1.0s. It prevents concurrent bot threads from
    # competing with one another before they even reach the SDK.
    with clore_request_gate_lock:
        global _last_clore_request_monotonic
        now = time.monotonic()
        wait_for = _last_clore_request_monotonic + CLORE_GET_MIN_INTERVAL - now
        if wait_for > 0:
            time.sleep(wait_for)
        _last_clore_request_monotonic = time.monotonic()
        return method(*args, **kwargs)


# ------------------------------------------------------------
# Permanent server blacklist
# ------------------------------------------------------------

BANNED_SERVER_IDS = {
    114376,
    111569,
    119631,
}


# ------------------------------------------------------------
# Excluded GPU models
# ------------------------------------------------------------

EXCLUDED_GPU_NAMES = {
    "rtx 4090 laptop gpu",
    "geforce rtx 4090 laptop gpu",
    "rtx 5090 laptop gpu",
    "geforce rtx 5090 laptop gpu",
}


# ------------------------------------------------------------
# GPU aliases
# ------------------------------------------------------------

GPU_ALIASES = {
    "5090": ["RTX 5090", "GeForce RTX 5090"],
    "4090": ["RTX 4090", "GeForce RTX 4090"],
    "5070TI": [
        "RTX 5070 Ti",
        "RTX 5070TI",
        "GeForce RTX 5070 Ti",
    ],
    "4070TI": [
        "RTX 4070 Ti",
        "RTX 4070TI",
        "GeForce RTX 4070 Ti",
    ],
    "4070TISUPER": [
        "RTX 4070 Ti SUPER",
        "RTX 4070TI SUPER",
        "GeForce RTX 4070 Ti SUPER",
    ],
    "3090": ["RTX 3090", "GeForce RTX 3090"],
    "3080TI": [
        "RTX 3080 Ti",
        "RTX 3080TI",
        "GeForce RTX 3080 Ti",
    ],
    "3080": ["RTX 3080", "GeForce RTX 3080"],
    "A100": ["A100"],
    "A6000": ["RTX A6000", "A6000"],
    "V100": ["V100"],
    "TESLAV100": [
        "Tesla V100",
        "TESLA V100",
        "V100",
    ],
    "T4": ["T4"],
    "CMP 90": ["CMP 90", "CMP 90HX"],
    "CMP 70": ["CMP 70", "CMP 70HX"],
}

ALLOWED_GPUS = [
    x.strip()
    for x in os.getenv(
        "ALLOWED_GPUS",
        "5090,4090,5070TI,4070TI,4070TISUPER,3090,3080TI,3080,A100,A6000,V100,TESLAV100,T4,CMP 90,CMP 70"
    ).split(",")
    if x.strip()
]

# Individual price limits for specific GPU models.
# IMPORTANT: values below are TOTAL PRICE FOR 24 HOURS.
GPU_PRICE_DAILY_RANGES = {
    "5090": (4.00, 6.50),
    "4090": (3.80, 5.50),
    "5070TI": (3.00, 3.50),
    "4070TI": (2.00, 3.00),
    "4070TISUPER": (2.00, 3.00),
    "3090": (2.00, 2.35),
    "3080TI": (2.00, 2.25),
    "3080": (2.00, 2.20),
    "A100": (5.00, 11.00),
    "A6000": (2.00, 6.00),
    "V100": (1.50, 2.20),
    "TESLAV100": (1.50, 2.20),
    "CMP 90": (0.30, 0.70),
    "CMP 70": (0.30, 0.60),
}

# Precomputed lowercase aliases: avoids rebuilding/lowercasing aliases for every server.
GPU_ALIAS_PAIRS = sorted(
    (
        alias.lower(),
        gpu_key,
    )
    for gpu_key, aliases in GPU_ALIASES.items()
    for alias in aliases
)
GPU_ALIAS_PAIRS.sort(key=lambda item: len(item[0]), reverse=True)

ALLOWED_GPU_KEYS = {
    gpu_key
    for gpu_key in ALLOWED_GPUS
    if gpu_key in GPU_ALIASES
}

EXCLUDED_GPU_NAMES_LOWER = tuple(
    name.lower() for name in EXCLUDED_GPU_NAMES
)

GPU_DISPLAY_NAMES = {
    gpu_key: (aliases[0] if aliases else gpu_key)
    for gpu_key, aliases in GPU_ALIASES.items()
}


def get_scan_state_snapshot():
    """Take one cheap snapshot instead of touching JSON lists per server."""
    with state_lock:
        return set(blacklist_set), set(rented_set)


def get_auto_price_ranges_snapshot():
    """Build ON-DEMAND price ranges once per marketplace scan."""
    with state_lock:
        saved = state.get("auto_gpu_price_daily_ranges")
        saved = saved if isinstance(saved, dict) else {}
        allowed = tuple(ALLOWED_GPUS)

        snapshot = {}
        for gpu_key in allowed:
            values = saved.get(gpu_key)
            if isinstance(values, (list, tuple)) and len(values) == 2:
                try:
                    snapshot[gpu_key] = (float(values[0]), float(values[1]))
                    continue
                except (TypeError, ValueError):
                    pass

            base = GPU_PRICE_DAILY_RANGES.get(gpu_key)
            if base is not None:
                snapshot[gpu_key] = (float(base[0]), float(base[1]))

    return snapshot


# ------------------------------------------------------------
# Ports
# ------------------------------------------------------------

OPEN_PORTS = {
    "22": "tcp",
    "8888": "http",
}


# ------------------------------------------------------------
# State
# ------------------------------------------------------------

STATE_FILE = Path(
    os.getenv("STATE_FILE", "bot_state.json")
)


# ============================================================
# LOGGING
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
)

logger = logging.getLogger("clore-bot")


# ============================================================
# CLORE CLIENT
# ============================================================

client = CloreAI(
    api_key=CLORE_API_KEY,
    timeout=30.0,
    max_retries=3,
)


# Reuse TCP connections. Telegram and Clore use separate sessions so the
# Clore auth header can never be sent to Telegram by accident.
TG_SESSION = requests.Session()
TG_SESSION.headers.update({"User-Agent": "Clore-GPU-Bot/Telegram"})

CLORE_SESSION = requests.Session()
CLORE_SESSION.headers.update({
    "User-Agent": "Clore-GPU-Bot/Clore",
    "auth": CLORE_API_KEY,
})
CLORE_HEADERS = {
    "Content-Type": "application/json",
}


# ============================================================
# STATE
# ============================================================

state_lock = threading.Lock()

state = {
    "blacklist": [],
    "rented": [],
    # True = automatic ON-DEMAND is paused.
    "auto_on_demand_paused": False,
    # Metadata for ON-DEMAND rentals created by this bot.
    "on_demand_renewals": [],
    # Maximum number of active rigs rented by this bot at the same time.
    "max_active_rigs": 20,
    # order_id -> timestamp of the last expiry warning sent.
    "expiry_warnings_sent": {},
    # UNIX timestamp of the last Telegram active-limit notification.
    "last_limit_error_notify_ts": 0.0,
}

# Fast O(1) membership checks for hot paths. JSON still stores lists.
blacklist_set = set(BANNED_SERVER_IDS)
rented_set = set()

# Prevent /scan, the background loop, and other callers from scanning the
# marketplace concurrently and racing each other for the same rig.
marketplace_scan_lock = threading.Lock()


def _sync_state_indexes_locked():
    global blacklist_set, rented_set

    raw_blacklist = state.get("blacklist", [])
    raw_rented = state.get("rented", [])

    if not isinstance(raw_blacklist, list):
        raw_blacklist = []
    if not isinstance(raw_rented, list):
        raw_rented = []

    normalized_blacklist = []
    seen_blacklist = set()
    for value in raw_blacklist:
        try:
            sid = int(value)
        except (TypeError, ValueError):
            continue
        if sid not in seen_blacklist:
            seen_blacklist.add(sid)
            normalized_blacklist.append(sid)

    for sid in BANNED_SERVER_IDS:
        if sid not in seen_blacklist:
            seen_blacklist.add(sid)
            normalized_blacklist.append(sid)

    normalized_rented = []
    seen_rented = set()
    for value in raw_rented:
        try:
            sid = int(value)
        except (TypeError, ValueError):
            continue
        if sid not in seen_rented:
            seen_rented.add(sid)
            normalized_rented.append(sid)

    state["blacklist"] = normalized_blacklist
    state["rented"] = normalized_rented
    state.setdefault("auto_on_demand_paused", False)
    if not isinstance(state.get("on_demand_renewals"), list):
        state["on_demand_renewals"] = []
    if not isinstance(state.get("expiry_warnings_sent"), dict):
        state["expiry_warnings_sent"] = {}

    try:
        state["last_limit_error_notify_ts"] = float(
            state.get("last_limit_error_notify_ts", 0.0) or 0.0
        )
    except (TypeError, ValueError):
        state["last_limit_error_notify_ts"] = 0.0

    try:
        limit = int(state.get("max_active_rigs", 20))
    except (TypeError, ValueError):
        limit = 20
    state["max_active_rigs"] = max(1, min(100, limit))

    blacklist_set = seen_blacklist
    rented_set = seen_rented


def load_state():
    global state

    if not STATE_FILE.exists():
        with state_lock:
            _sync_state_indexes_locked()
        return

    try:
        with STATE_FILE.open("r", encoding="utf-8") as f:
            loaded = json.load(f)

        if isinstance(loaded, dict):
            state.update(loaded)

        with state_lock:
            _sync_state_indexes_locked()

        logger.info("State загружен из %s", STATE_FILE)

    except Exception as e:
        logger.error("Ошибка загрузки state: %s", e)


def save_state():
    try:
        with state_lock:
            tmp_file = STATE_FILE.with_suffix(".tmp")

            with tmp_file.open("w", encoding="utf-8") as f:
                json.dump(
                    state,
                    f,
                    ensure_ascii=False,
                    indent=2
                )

            tmp_file.replace(STATE_FILE)

    except Exception as e:
        logger.error("Ошибка сохранения state: %s", e)


# ============================================================
# HELPERS
# ============================================================

def model_to_dict(obj: Any) -> Any:
    if obj is None:
        return None

    if isinstance(obj, dict):
        return obj

    if isinstance(obj, list):
        return [model_to_dict(x) for x in obj]

    if hasattr(obj, "model_dump"):
        try:
            return obj.model_dump(mode="python")
        except Exception:
            pass

    if hasattr(obj, "dict"):
        try:
            return obj.dict()
        except Exception:
            pass

    if hasattr(obj, "__dict__"):
        try:
            return dict(obj.__dict__)
        except Exception:
            pass

    return obj


def get_value(
    obj: Any,
    *names: str,
    default=None
):
    if obj is None:
        return default

    for name in names:
        if isinstance(obj, dict):
            if name in obj:
                return obj[name]
        else:
            try:
                value = getattr(obj, name)

                if value is not None:
                    return value

            except Exception:
                pass

    return default


def nested_get(
    obj: Any,
    path: list[str],
    default=None
):
    current = obj

    for key in path:
        current = get_value(
            current,
            key,
            default=None
        )

        if current is None:
            return default

    return current


# ============================================================
# TELEGRAM
# ============================================================

TG_API = f"https://api.telegram.org/bot{TG_TOKEN}"


def telegram_request(
    method: str,
    payload: Optional[dict] = None,
    timeout: int = 20,
):
    url = f"{TG_API}/{method}"

    try:
        response = TG_SESSION.post(
            url,
            json=payload or {},
            timeout=timeout,
        )

        if response.status_code == 429:
            logger.warning("Telegram rate limit")
            return None

        response.raise_for_status()

        data = response.json()

        if not data.get("ok"):
            logger.warning(
                "Telegram API error: %s",
                data
            )

        return data

    except Exception as e:
        logger.error(
            "Telegram request error: %s",
            e
        )

        return None


def notify_active_rental_limit(server_id: Optional[int] = None, mode: str = "ON-DEMAND") -> bool:
    """Send at most one active-limit notification during the configured interval.

    The timestamp is persisted in bot_state.json, so restarting the bot does not
    immediately generate another identical Telegram message.
    """
    now = time.time()

    with _limit_error_notify_lock:
        with state_lock:
            try:
                last_sent = float(
                    state.get("last_limit_error_notify_ts", 0.0) or 0.0
                )
            except (TypeError, ValueError):
                last_sent = 0.0

            elapsed = now - last_sent
            if last_sent > 0 and elapsed < LIMIT_ERROR_NOTIFY_INTERVAL:
                logger.info(
                    "Telegram лимит-уведомление подавлено: прошло %.0f из %.0f сек; server_id=%s",
                    elapsed,
                    LIMIT_ERROR_NOTIFY_INTERVAL,
                    server_id,
                )
                return False

        active = get_active_rental_count()
        limit = get_max_active_rigs()
        server_line = (
            f"\nПоследняя попытка: Server <code>{server_id}</code>"
            if server_id is not None
            else ""
        )

        result = send_message(
            "⛔ <b>Достигнут лимит активных ригов</b>\n\n"
            f"Активно: <code>{active}/{limit}</code>\n"
            f"Новая {html.escape(mode)} аренда сейчас не создаётся."
            f"{server_line}\n\n"
            f"Следующее такое уведомление будет не раньше чем через "
            f"<code>{max(1, int(LIMIT_ERROR_NOTIFY_INTERVAL // 60))} мин.</code>."
        )

        # Only suppress future messages after Telegram accepted this one.
        if isinstance(result, dict) and result.get("ok"):
            with state_lock:
                state["last_limit_error_notify_ts"] = now
            save_state()
            return True

        logger.warning(
            "Не удалось отправить Telegram уведомление о лимите; таймер не установлен."
        )
        return False


def send_message(
    text: str,
    reply_markup=None,
):
    payload = {
        "chat_id": TG_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }

    if reply_markup:
        payload["reply_markup"] = reply_markup

    return telegram_request(
        "sendMessage",
        payload
    )


def answer_callback(
    callback_id: str,
    text: str = "",
):
    return telegram_request(
        "answerCallbackQuery",
        {
            "callback_query_id": callback_id,
            "text": text,
        }
    )


# ============================================================
# CLORE MARKETPLACE
# ============================================================

# Short-lived cache prevents duplicate Marketplace calls from Telegram commands.
MARKETPLACE_CACHE_TTL = float(os.getenv("MARKETPLACE_CACHE_TTL", "3"))
_market_cache = {"time": 0.0, "servers": None}
_market_cache_lock = threading.Lock()
_market_fetch_lock = threading.Lock()


def invalidate_marketplace_cache():
    """Drop the short-lived marketplace cache after a stale/race result."""
    with _market_cache_lock:
        _market_cache["time"] = 0.0
        _market_cache["servers"] = None


def get_marketplace(force_refresh: bool = False):
    now = time.monotonic()

    with _market_cache_lock:
        if (
            not force_refresh
            and _market_cache["servers"] is not None
            and now - _market_cache["time"] < MARKETPLACE_CACHE_TTL
        ):
            return _market_cache["servers"]

    # Single-flight: if auto scan and /market miss the cache at the same time,
    # only one actual Clore marketplace request is made.
    with _market_fetch_lock:
        now = time.monotonic()
        if not force_refresh:
            with _market_cache_lock:
                if (
                    _market_cache["servers"] is not None
                    and now - _market_cache["time"] < MARKETPLACE_CACHE_TTL
                ):
                    return _market_cache["servers"]

        try:
            servers = _clore_sdk_call(client.marketplace, available_only=True)
        except TypeError:
            try:
                servers = _clore_sdk_call(client.marketplace)
            except Exception as e:
                logger.error("Ошибка marketplace: %s", e)
                return []
        except Exception as e:
            logger.error("Ошибка marketplace: %s", e)
            return []

        result = [model_to_dict(server) for server in servers]

        with _market_cache_lock:
            _market_cache["time"] = time.monotonic()
            _market_cache["servers"] = result

        return result


# ============================================================
# SERVER DATA
# ============================================================

def get_server_id(server):
    value = get_value(
        server,
        "id",
        "server_id"
    )

    if value is None:
        return None

    try:
        return int(value)
    except Exception:
        return None


def get_gpu_name(server) -> str:
    gpu = nested_get(
        server,
        ["specs", "gpu"],
        default=None
    )

    if gpu is None:
        gpu = get_value(
            server,
            "gpu",
            "gpu_model",
            default=""
        )

    return "" if gpu is None else str(gpu)


def get_gpu_count(server) -> int:
    """Return number of GPUs in the server."""
    for field in ("gpu_count", "gpu_cnt", "gpus_count", "count_gpu"):
        value = get_value(server, field, default=None)
        try:
            if value is not None and int(value) > 0:
                return int(value)
        except (TypeError, ValueError):
            pass

    gpu_array = get_value(server, "gpu_array", default=None)
    if isinstance(gpu_array, list) and gpu_array:
        return max(1, len(gpu_array))

    gpu_name = get_gpu_name(server)

    # Examples: "2x NVIDIA GeForce RTX 5090", "2 x RTX 5090", "2× RTX 5090".
    match = re.match(r"\s*(\d+)\s*[x×]\b", gpu_name, flags=re.IGNORECASE)
    if match:
        try:
            return max(1, int(match.group(1)))
        except (TypeError, ValueError):
            pass

    return 1


def price_per_day_per_gpu(total_daily_price: float, gpu_count: int) -> float:
    """Price of one GPU for 24h, based on the whole-server daily price."""
    return float(total_daily_price) / max(1, int(gpu_count))


def is_server_rented(server) -> bool:
    return bool(
        get_value(
            server,
            "rented",
            default=False
        )
    )


# ============================================================
# PRICE
# ============================================================

def extract_price_per_day(server, spot=False):
    """Return Clore marketplace price for the WHOLE server per 24 hours."""
    price = get_value(server, "price", default=None)

    if price is not None:
        # Current SDK/REST shape: price.usd.on_demand_usd / price.usd.spot
        usd = get_value(price, "usd", default=None)
        if usd is not None:
            value = get_value(
                usd,
                "spot" if spot else "on_demand_usd",
                "spot_usd" if spot else "on_demand",
                default=None,
            )
            if value is not None:
                try:
                    return float(value)
                except Exception:
                    pass

        # REST documentation shape: price.on_demand.<currency> / price.spot.<currency>
        section = get_value(price, "spot" if spot else "on_demand", default=None)
        if section is not None:
            if isinstance(section, (int, float, str)):
                try:
                    return float(section)
                except Exception:
                    pass
            value = get_value(
                section,
                "USD-Blockchain",
                "usd",
                "USD",
                "bitcoin",
                "CLORE-Blockchain",
                default=None,
            )
            if value is not None:
                try:
                    return float(value)
                except Exception:
                    pass

    # Fallback fields, also interpreted as DAILY server prices.
    value = get_value(
        server,
        "spot_price_usd" if spot else "price_usd",
        "spot_price" if spot else "on_demand_price",
        default=None,
    )
    if value is not None:
        try:
            return float(value)
        except Exception:
            pass

    return None


def extract_price_per_hour(server, spot=False):
    """Return whole-server price converted from 24h to 1h for display only."""
    daily = extract_price_per_day(server, spot=spot)
    return None if daily is None else daily / 24.0


def price_per_day(value):
    """Clore marketplace prices are already TOTAL prices for 24 hours."""
    return None if value is None else float(value)


def price_per_hour(value):
    """Display helper: convert a 24h server price to an hourly equivalent."""
    return None if value is None else float(value) / 24.0


# ============================================================
# GPU FILTER
# ============================================================

def get_gpu_key(gpu_name: str):
    """Return canonical GPU key, or None when excluded/unknown."""
    name_lower = gpu_name.strip().lower()
    if not name_lower:
        return None

    # Laptop RTX variants are never eligible.
    for excluded in EXCLUDED_GPU_NAMES_LOWER:
        if excluded in name_lower:
            return None

    # Longest aliases are checked first, so 4070 Ti SUPER wins over 4070 Ti.
    for alias_lower, gpu_key in GPU_ALIAS_PAIRS:
        if alias_lower in name_lower:
            return gpu_key

    return None


def gpu_price_matches(gpu_name: str, price_per_gpu_day: float, spot: bool = False) -> bool:
    """Check price range for ONE GPU over 24h. Editable ranges apply only to ON-DEMAND."""
    gpu_key = get_gpu_key(gpu_name)
    if gpu_key is None or gpu_key not in ALLOWED_GPU_KEYS:
        return False

    limits = GPU_PRICE_DAILY_RANGES.get(gpu_key) if spot else get_auto_gpu_price_range(gpu_key)
    if limits is None:
        return False

    min_price, max_price = limits
    return min_price <= price_per_gpu_day <= max_price


def gpu_matches(gpu_name: str) -> bool:
    """Return True only for explicitly allowed, non-excluded GPU models."""
    gpu_key = get_gpu_key(gpu_name)
    return gpu_key in ALLOWED_GPU_KEYS if gpu_key is not None else False


# ============================================================
# BLACKLIST
# ============================================================

def is_blacklisted(server_id: int) -> bool:
    try:
        sid = int(server_id)
    except (TypeError, ValueError):
        return False
    with state_lock:
        return sid in blacklist_set


def ban_server(server_id: int):
    server_id = int(server_id)
    changed = False
    with state_lock:
        blacklist = state.setdefault("blacklist", [])
        if server_id not in blacklist_set:
            blacklist.append(server_id)
            blacklist_set.add(server_id)
            changed = True

    if changed:
        save_state()

    logger.info(
        "Server %s добавлен в blacklist",
        server_id
    )


def unban_server(server_id: int) -> tuple[bool, str]:
    """Удалить сервер из локального blacklist через Telegram."""
    server_id = int(server_id)

    # Эти серверы добавляются автоматически и остаются постоянными.
    if server_id in BANNED_SERVER_IDS:
        logger.info(
            "Server %s нельзя разбанить: постоянный blacklist",
            server_id,
        )
        return False, "permanent"

    changed = False

    with state_lock:
        blacklist = state.setdefault("blacklist", [])
        new_blacklist = []
        found = False

        for value in blacklist:
            try:
                sid = int(value)
            except (TypeError, ValueError):
                continue

            if sid == server_id:
                found = True
                continue

            new_blacklist.append(sid)

        if found:
            state["blacklist"] = new_blacklist
            blacklist_set.discard(server_id)
            changed = True

    if changed:
        save_state()
        logger.info(
            "Server %s удалён из blacklist",
            server_id,
        )
        return True, "removed"

    return False, "not_found"


# ============================================================
# RENTED STATE
# ============================================================

def add_rented(server_id: int, persist: bool = True):
    server_id = int(server_id)
    changed = False
    with state_lock:
        rented = state.setdefault("rented", [])
        if server_id not in rented_set:
            rented.append(server_id)
            rented_set.add(server_id)
            changed = True

    if changed:
        with _active_rental_sync_lock:
            cached_ids = _active_rental_sync_cache.get("ids")
            if isinstance(cached_ids, set):
                cached_ids.add(server_id)
            else:
                _active_rental_sync_cache["ids"] = set(rented_set)

    if changed and persist:
        save_state()


def already_rented_by_bot(server_id: int) -> bool:
    try:
        sid = int(server_id)
    except (TypeError, ValueError):
        return False
    with state_lock:
        return sid in rented_set


def remove_rented(server_id: int, persist: bool = True):
    """Remove a server from the bot-owned active-rental index after expiry."""
    server_id = int(server_id)
    changed = False

    with state_lock:
        if server_id in rented_set:
            rented_set.remove(server_id)
            rented = state.setdefault("rented", [])
            state["rented"] = [
                sid for sid in rented
                if int(sid) != server_id
            ]
            changed = True

    if changed:
        with _active_rental_sync_lock:
            cached_ids = _active_rental_sync_cache.get("ids")
            if isinstance(cached_ids, set):
                cached_ids.discard(server_id)
            else:
                _active_rental_sync_cache["ids"] = set(rented_set)

    if changed and persist:
        save_state()


# ============================================================
# ON-DEMAND AUTO-RENEWAL STATE
# ============================================================

RENEWAL_STATE_LOCK = threading.Lock()
_renewal_orders_cache = {"time": 0.0, "orders": None}
_renewal_orders_cache_lock = threading.Lock()


def _order_server_id(order: dict) -> Optional[int]:
    value = (
        order.get("si")
        or order.get("server_id")
        or order.get("serverId")
        or order.get("renting_server")
    )
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _order_is_on_demand(order: dict) -> bool:
    if bool(order.get("spot", False)):
        return False
    order_type = str(order.get("type", "")).strip().lower()
    if order_type == "spot":
        return False
    return True


def _order_key(order: dict) -> str:
    order_id = order.get("id") or order.get("order_id")
    if order_id not in (None, "", "?"):
        return str(order_id)
    sid = _order_server_id(order)
    ct = order.get("ct", order.get("created_at", ""))
    price = order.get("price", "")
    return f"{sid}:{ct}:{price}"


def _order_price(order: dict) -> Optional[float]:
    try:
        value = order.get("price")
        if value is None:
            value = order.get("daily_price")
        return float(value) if value is not None else None
    except (TypeError, ValueError):
        return None


def _get_renewal_records_snapshot() -> dict[int, dict]:
    with state_lock:
        raw = state.get("on_demand_renewals", [])
        if not isinstance(raw, list):
            return {}

        result = {}
        for item in raw:
            if not isinstance(item, dict):
                continue
            try:
                sid = int(item.get("server_id"))
            except (TypeError, ValueError):
                continue
            row = dict(item)
            row["server_id"] = sid
            result[sid] = row
        return result


def _save_renewal_records(records: dict[int, dict]):
    with state_lock:
        state["on_demand_renewals"] = list(records.values())
    save_state()


def remember_on_demand_rental(
    server_id: int,
    total_daily: float,
    per_gpu_daily: float,
    gpu_name: str = "",
    gpu_count: int = 1,
    order_id: Any = "?",
):
    """Store enough metadata to renew the same ON-DEMAND rig later."""
    sid = int(server_id)
    try:
        total_daily = float(total_daily)
        per_gpu_daily = float(per_gpu_daily)
    except (TypeError, ValueError):
        return

    records = _get_renewal_records_snapshot()
    existing = records.get(sid, {})
    records[sid] = {
        "server_id": sid,
        "total_daily": total_daily,
        "per_gpu_daily": per_gpu_daily,
        "gpu_name": str(gpu_name or existing.get("gpu_name", "")),
        "gpu_count": int(gpu_count or existing.get("gpu_count", 1) or 1),
        "order_id": str(order_id if order_id not in (None, "") else existing.get("order_id", "?")),
        "order_key": str(order_id if order_id not in (None, "", "?") else existing.get("order_key", "")),
        "updated_at": time.time(),
        "miss_count": 0,
        "retry_after": 0.0,
    }

    # Keep the state compact if an old setup accumulated many records.
    if len(records) > 200:
        ordered = sorted(
            records.values(),
            key=lambda row: float(row.get("updated_at", 0) or 0),
            reverse=True,
        )[:200]
        records = {int(row["server_id"]): row for row in ordered}

    _save_renewal_records(records)


def _get_current_orders_for_renewal(force_refresh: bool = False) -> Optional[list[dict]]:
    now = time.monotonic()
    with _renewal_orders_cache_lock:
        cached = _renewal_orders_cache.get("orders")
        cached_at = _renewal_orders_cache.get("time", 0.0)
        if (
            not force_refresh
            and cached is not None
            and now - cached_at < RENEW_CHECK_INTERVAL
        ):
            return list(cached)

    try:
        # Use the same raw REST snapshot as active-rig counting. The response is
        # consumed as JSON, so SDK Pydantic validation cannot break renewal.
        orders = get_clore_orders_cached(
            force_refresh=force_refresh,
            include_completed=False,
        )
    except Exception as exc:
        logger.warning("Renewal: не удалось получить my_orders(): %s", exc)
        return None

    with _renewal_orders_cache_lock:
        _renewal_orders_cache["time"] = time.monotonic()
        _renewal_orders_cache["orders"] = list(orders)
    return list(orders)


def _renewal_price_matches(current_total: float, previous_total: float) -> bool:
    """Legacy helper kept for compatibility; exact old-price matching is no longer required."""
    tolerance = max(0.0, float(RENEW_PRICE_TOLERANCE))
    return abs(float(current_total) - float(previous_total)) <= tolerance


def renew_on_demand_server(server: dict, record: dict) -> str:
    """Renew one tracked ON-DEMAND server at its CURRENT market price, if it fits the current auto-price range."""
    sid = get_server_id(server)
    if sid is None:
        return "missing"

    if is_blacklisted(sid):
        remove_rented(sid)
        return "blacklisted"

    if is_server_rented(server) and not already_rented_by_bot(sid):
        return "occupied"

    total_daily = extract_price_per_day(server, spot=False)
    if total_daily is None:
        return "no_price"

    previous_total = record.get("total_daily")
    try:
        previous_total = float(previous_total)
    except (TypeError, ValueError):
        previous_total = None

    gpu_name = get_gpu_name(server)
    gpu_count = get_gpu_count(server)
    if gpu_count < 1 or gpu_count > 10:
        remove_rented(sid)
        return "gpu_count_changed"

    gpu_key = get_gpu_key(gpu_name)
    if gpu_key is None or gpu_key not in ALLOWED_GPU_KEYS:
        remove_rented(sid)
        return "gpu_not_allowed"

    per_gpu_daily = price_per_day_per_gpu(total_daily, gpu_count)
    limits = get_auto_gpu_price_range(gpu_key)
    if limits is None or not (limits[0] <= per_gpu_daily <= limits[1]):
        remove_rented(sid)
        return "outside_auto_price"

    # Final pause check closes the race where the pause button is pressed
    # after renewal scanning has already selected the server.
    if is_auto_on_demand_paused():
        logger.info("Renewal skipped for %s: ON-DEMAND auto-rent is paused", sid)
        return "paused"

    try:
        # IMPORTANT: renewal uses the CURRENT Clore market price.
        # The current price is already validated against the NEW Telegram/JSON
        # auto-price range above, so a changed price does not block renewal.
        logger.info(
            "♻️ Renewal price lock: server_id=%s required_price=%.4f/24ч",
            sid,
            total_daily,
        )
        result = execute_create_order(
            server_id=sid,
            spot=False,
            required_price=total_daily,
        )
    except Exception as exc:
        error_text = str(exc)
        if "server-already-rented" in error_text.lower():
            return "already_rented"
        logger.warning("Renewal create_order failed for %s: %s", sid, exc)
        return "error"

    order_id = result.get("id", "?") if isinstance(result, dict) else "?"
    remember_on_demand_rental(
        server_id=sid,
        total_daily=total_daily,
        per_gpu_daily=per_gpu_daily,
        gpu_name=gpu_name,
        gpu_count=gpu_count,
        order_id=order_id,
    )

    send_message(
        "♻️ <b>ON-DEMAND аренда продлена</b>\n\n"
        f"GPU: <code>{html.escape(gpu_name)}</code>\n"
        f"Server ID: <code>{sid}</code>\n"
        f"GPU count: <code>{gpu_count}</code>\n"
        f"Цена сервера: <code>${total_daily:.4f}/24ч</code>\n"
        f"Цена 1 GPU: <code>${per_gpu_daily:.4f}/24ч</code>\n"
        f"Order ID: <code>{html.escape(str(order_id))}</code>",
        build_rented_notification_keyboard(sid),
    )
    return "renewed"


def check_on_demand_renewals():
    """Detect expired bot ON-DEMAND orders and renew them at the same price.

    Important optimization: expired renewal records are resolved against ONE
    fresh marketplace snapshot per renewal pass instead of calling
    marketplace(force_refresh=True) once per server. This prevents a burst of
    API requests when the state file contains many stale renewal records.
    """
    if not AUTO_RENEW_ON_DEMAND or not AUTO_ON_DEMAND:
        return
    if is_auto_on_demand_paused():
        return

    now = time.monotonic()
    with _renewal_orders_cache_lock:
        # Keep renewal checks independent from the marketplace scan interval.
        last_check = _renewal_orders_cache.get("renew_check_time", 0.0)
        if now - last_check < RENEW_CHECK_INTERVAL:
            return
        _renewal_orders_cache["renew_check_time"] = now

    records = _get_renewal_records_snapshot()
    if not records:
        return

    orders = _get_current_orders_for_renewal(force_refresh=True)
    if orders is None:
        return

    # IMPORTANT: my_orders() may still return an order for a short time after
    # it has expired. The previous code treated such an order as ACTIVE and
    # therefore never put the server into renewal_candidates.
    # Treat explicit expired/completed/cancelled states and a passed ct+mrl
    # deadline as inactive so renewal can start immediately.
    now_wall = time.time()
    active_by_server = {}
    for order in orders:
        if not isinstance(order, dict) or not _order_is_on_demand(order):
            continue
        if bool(order.get("expired", False)):
            continue

        status = str(
            order.get("status")
            or order.get("state")
            or order.get("order_status")
            or ""
        ).strip().lower()
        if status in {
            "expired", "completed", "complete", "cancelled",
            "canceled", "finished", "closed", "terminated",
        }:
            continue

        expiry_at = _order_expiry_timestamp(order)
        if expiry_at is not None and expiry_at <= now_wall:
            continue

        sid = _order_server_id(order)
        if sid is not None:
            active_by_server[sid] = order

    changed = False

    # Bootstrap renewal metadata for ON-DEMAND rentals that were created by
    # an older version of the bot and are already present in rented_set.
    with state_lock:
        tracked_rented_ids = set(rented_set)

    for sid in tracked_rented_ids:
        if sid in records:
            continue
        active = active_by_server.get(sid)
        if active is None or not _order_is_on_demand(active):
            continue

        price = _order_price(active)
        if price is None or price <= 0:
            continue

        records[sid] = {
            "server_id": sid,
            "total_daily": float(price),
            "per_gpu_daily": 0.0,
            "gpu_name": "",
            "gpu_count": 0,
            "order_id": str(active.get("id", active.get("order_id", "?"))),
            "order_key": _order_key(active),
            "updated_at": time.time(),
            "miss_count": 0,
            "retry_after": 0.0,
        }
        changed = True

    # Reconcile active records and collect expired servers that actually need
    # a marketplace lookup. The lookup itself is batched below.
    renewal_candidates = []

    for sid, record in list(records.items()):
        active = active_by_server.get(sid)
        if active is not None:
            key = _order_key(active)
            price = _order_price(active)
            if key and record.get("order_key") != key:
                record["order_key"] = key
                record["order_id"] = str(active.get("id", active.get("order_id", "?")))
                changed = True
            if price is not None and price > 0 and record.get("total_daily") != price:
                record["total_daily"] = price
                changed = True
            record["miss_count"] = 0
            record["retry_after"] = 0.0
            record["updated_at"] = time.time()
            continue

        # No active order for this tracked server: it has likely expired.
        record["miss_count"] = int(record.get("miss_count", 0) or 0) + 1
        changed = True

        if record["miss_count"] < 1:
            continue
        if time.time() < float(record.get("retry_after", 0.0) or 0.0):
            continue

        if is_blacklisted(sid):
            remove_rented(sid, persist=False)
            continue

        renewal_candidates.append((sid, record))

    # Process the oldest/stalest expired records first so a server cannot be
    # starved indefinitely by newer records when MAX_RENEWALS_PER_CHECK is used.
    renewal_candidates.sort(
        key=lambda item: (
            float(item[1].get("updated_at", 0) or 0),
            int(item[0]),
        )
    )

    # Resolve all expired renewal candidates from ONE fresh marketplace call.
    # This replaces the previous per-server find_server_fresh() calls that
    # were producing a marketplace request roughly once per second.
    server_by_id = {}
    if renewal_candidates:
        try:
            servers = get_marketplace(force_refresh=True)
            server_by_id = {
                sid: server
                for server in servers
                for sid in [get_server_id(server)]
                if sid is not None
            }
        except Exception as exc:
            logger.warning(
                "Renewal marketplace refresh failed: %s",
                exc,
            )

    processed = 0
    max_renewals = max(1, MAX_RENEWALS_PER_CHECK)

    for sid, record in renewal_candidates:
        if processed >= max_renewals:
            break

        # Free the local active-rental marker before trying to reacquire the rig.
        remove_rented(sid, persist=False)

        server = server_by_id.get(sid)
        if server is None:
            record["retry_after"] = time.time() + RENEW_RETRY_DELAY
            changed = True
            processed += 1
            continue

        logger.info(
            "♻️ Renewal attempt: server_id=%s, previous_price=%s, current_server_found=True",
            sid,
            record.get("total_daily"),
        )
        result = renew_on_demand_server(server, record)
        processed += 1

        if result == "renewed":
            changed = True
            continue

        if result in {"already_rented", "no_price", "price_changed"}:
            # Keep retrying temporarily; current-price renewal is controlled by
            # the current auto-price range, not by the previous daily price.
            record["retry_after"] = time.time() + RENEW_RETRY_DELAY
            changed = True
        else:
            record["retry_after"] = time.time() + RENEW_RETRY_DELAY
            changed = True

    if changed:
        _save_renewal_records(records)


# ============================================================
# EXPIRY WARNINGS
# ============================================================

_expiry_check_lock = threading.Lock()
_last_expiry_check_monotonic = 0.0


def _order_expiry_timestamp(order: dict) -> Optional[float]:
    """Calculate order end time from Clore's ct + mrl fields."""
    try:
        created_at = float(order.get("ct", 0) or 0)
        rental_length = float(order.get("mrl", 0) or 0)
    except (TypeError, ValueError):
        return None

    if created_at <= 0 or rental_length <= 0:
        return None

    return created_at + rental_length


def check_expiry_warnings(force_refresh: bool = False):
    """Send one Telegram warning when an active order enters its last 5 minutes."""
    global _last_expiry_check_monotonic

    now_mono = time.monotonic()
    with _expiry_check_lock:
        if (
            not force_refresh
            and now_mono - _last_expiry_check_monotonic < EXPIRY_CHECK_INTERVAL
        ):
            return
        _last_expiry_check_monotonic = now_mono

    try:
        orders = get_clore_orders_cached(
            force_refresh=force_refresh,
            include_completed=False,
        )
    except Exception as exc:
        logger.warning("Expiry warning: не удалось получить my_orders(): %s", exc)
        return

    now = time.time()

    with state_lock:
        sent_map = dict(state.get("expiry_warnings_sent", {}))

    active_order_ids = set()
    warnings_sent = 0

    for order in orders:
        if not isinstance(order, dict) or bool(order.get("expired", False)):
            continue

        raw_order_id = order.get("id", order.get("order_id"))
        if raw_order_id in (None, "", "?"):
            continue
        order_id = str(raw_order_id)
        active_order_ids.add(order_id)

        expiry_at = _order_expiry_timestamp(order)
        if expiry_at is None:
            continue

        remaining = expiry_at - now
        if remaining <= 0 or remaining > EXPIRY_WARNING_SECONDS:
            continue

        if order_id in sent_map:
            continue

        sid = _order_server_id(order)
        gpu = order_gpu_name(order)
        order_type = "SPOT" if bool(order.get("spot", False)) else "ON-DEMAND"
        minutes_left = max(1, int((remaining + 59) // 60))

        send_message(
            "⏰ <b>АРЕНДА СКОРО ЗАКОНЧИТСЯ</b>\n\n"
            f"Тип: <code>{order_type}</code>\n"
            f"GPU: <code>{html.escape(gpu)}</code>\n"
            f"Server ID: <code>{html.escape(str(sid if sid is not None else '?'))}</code>\n"
            f"Order ID: <code>{html.escape(order_id)}</code>\n"
            f"Осталось: <code>~{minutes_left} мин</code>",
            build_rented_notification_keyboard(sid) if sid is not None else None,
        )

        sent_map[order_id] = now
        warnings_sent += 1

    # Bound the persisted marker map so old order IDs do not accumulate forever.
    cleaned_map = {}
    for key, value in sent_map.items():
        try:
            sent_at = float(value)
        except (TypeError, ValueError):
            continue
        if key in active_order_ids or now - sent_at < 86400:
            cleaned_map[str(key)] = sent_at

    if len(cleaned_map) > 200:
        cleaned_map = dict(
            sorted(cleaned_map.items(), key=lambda item: item[1], reverse=True)[:200]
        )

    changed = False
    with state_lock:
        if state.get("expiry_warnings_sent") != cleaned_map:
            state["expiry_warnings_sent"] = cleaned_map
            changed = True

    if changed:
        save_state()

    if warnings_sent:
        logger.info(
            "Expiry warnings: отправлено %s уведомление(ий)",
            warnings_sent,
        )


# ============================================================
# AUTO ON-DEMAND CONTROL
# ============================================================

def is_auto_on_demand_paused() -> bool:
    with state_lock:
        return bool(
            state.get("auto_on_demand_paused", False)
        )


def set_auto_on_demand_paused(paused: bool):
    with state_lock:
        state["auto_on_demand_paused"] = bool(paused)

    save_state()

    logger.info(
        "Auto ON-DEMAND %s",
        "PAUSED" if paused else "STARTED"
    )


def get_auto_gpu_price_range(gpu_key: str):
    """Get editable ON-DEMAND price range for one GPU."""
    with state_lock:
        ranges = state.get("auto_gpu_price_daily_ranges")
        if not isinstance(ranges, dict):
            ranges = {}
            state["auto_gpu_price_daily_ranges"] = ranges

        if gpu_key not in ranges:
            base = GPU_PRICE_DAILY_RANGES.get(gpu_key)
            if base is None:
                return None
            ranges[gpu_key] = [float(base[0]), float(base[1])]

        values = ranges[gpu_key]
        if not isinstance(values, (list, tuple)) or len(values) != 2:
            return None

        try:
            return float(values[0]), float(values[1])
        except (TypeError, ValueError):
            return None


def set_auto_gpu_price_range(gpu_key: str, min_price: float, max_price: float):
    min_price = round(max(0.0, float(min_price)), 2)
    max_price = round(max(0.0, float(max_price)), 2)

    if min_price > max_price:
        raise ValueError("Минимальная цена не может быть выше максимальной")

    with state_lock:
        ranges = state.setdefault("auto_gpu_price_daily_ranges", {})
        ranges[gpu_key] = [min_price, max_price]

    save_state()


def adjust_auto_gpu_price(gpu_key: str, which: str, delta: float):
    current = get_auto_gpu_price_range(gpu_key)
    if current is None:
        raise ValueError("Для этой GPU нет цены автоаренды")

    min_price, max_price = current
    delta = round(float(delta), 2)

    if which == "min":
        candidate = round(min_price + delta, 2)
        if candidate < 0:
            candidate = 0.0
        if candidate > max_price:
            raise ValueError("Минимальная цена не может быть выше максимальной")
        min_price = candidate
    elif which == "max":
        candidate = round(max_price + delta, 2)
        if candidate < 0:
            candidate = 0.0
        if candidate < min_price:
            raise ValueError("Максимальная цена не может быть ниже минимальной")
        max_price = candidate
    else:
        raise ValueError("Неизвестный параметр цены")

    set_auto_gpu_price_range(gpu_key, min_price, max_price)
    return min_price, max_price


# ============================================================
# ACTIVE RENTAL LIMIT
# ============================================================

def get_max_active_rigs() -> int:
    """Return the configured maximum number of active rigs."""
    with state_lock:
        try:
            value = int(state.get("max_active_rigs", 20))
        except (TypeError, ValueError):
            value = 20
        return max(1, min(100, value))


# Cache of the real active orders from Clore. The local rented_set is still
# used for fast O(1) checks, but it is periodically reconciled with Clore so
# the 20-rig limit reflects the actual account state after restarts/expiry.
ACTIVE_RENTAL_SYNC_TTL = float(os.getenv("ACTIVE_RENTAL_SYNC_TTL", "30"))
_active_rental_sync_cache = {"time": 0.0, "ids": None}
_active_rental_sync_lock = threading.Lock()
_active_rental_sync_ready = False


def refresh_active_rented_state(force_refresh: bool = False) -> bool:
    """Synchronize rented_set with the REAL active Clore orders.

    A failed my_orders() request is NOT treated as zero active rentals.
    Until Clore confirms the account state, NEW rentals are blocked.
    """
    global _active_rental_sync_ready

    now = time.monotonic()

    with _active_rental_sync_lock:
        cached_ids = _active_rental_sync_cache.get("ids")
        cached_at = float(_active_rental_sync_cache.get("time", 0.0) or 0.0)
        if (
            not force_refresh
            and cached_ids is not None
            and now - cached_at < ACTIVE_RENTAL_SYNC_TTL
        ):
            _active_rental_sync_ready = True
            return True

    try:
        orders = get_clore_orders_cached(
            force_refresh=force_refresh,
            include_completed=False,
        )
    except Exception as exc:
        _active_rental_sync_ready = False
        logger.error(
            "❌ Не удалось синхронизировать активные аренды Clore: %s",
            exc,
        )
        logger.error(
            "⛔ Новые аренды заблокированы до успешной синхронизации my_orders."
        )
        return False

    active_ids = set()
    for order in orders:
        if not isinstance(order, dict):
            continue
        if bool(order.get("expired", False)):
            continue
        sid = _order_server_id(order)
        if sid is not None:
            active_ids.add(sid)

    with state_lock:
        old_ids = set(rented_set)
        rented_set.clear()
        rented_set.update(active_ids)
        state["rented"] = sorted(active_ids)

    with _active_rental_sync_lock:
        _active_rental_sync_cache["time"] = time.monotonic()
        _active_rental_sync_cache["ids"] = set(active_ids)

    _active_rental_sync_ready = True

    if old_ids != active_ids:
        save_state()
        logger.info(
            "✅ Синхронизация активных аренд Clore: было %s, стало %s",
            len(old_ids),
            len(active_ids),
        )

    logger.info(
        "📦 Clore подтверждает активных ригов: %s",
        len(active_ids),
    )
    return True


def get_active_rental_count() -> int:
    """Return the last successfully confirmed active-rig count."""
    with state_lock:
        return len(rented_set)


def has_active_rental_capacity() -> bool:
    """Allow NEW rentals only after a successful Clore synchronization."""
    if not refresh_active_rented_state(force_refresh=False):
        logger.warning(
            "⛔ Лимит не подтвержден Clore. Новая аренда запрещена."
        )
        return False

    with _active_rental_sync_lock:
        ready = bool(_active_rental_sync_ready)

    if not ready:
        return False

    active = get_active_rental_count()
    limit = get_max_active_rigs()

    if active >= limit:
        logger.info(
            "⛔ Лимит активных ригов достигнут: %s/%s",
            active,
            limit,
        )
        return False

    logger.info(
        "✅ Есть место по лимиту: %s/%s",
        active,
        limit,
    )
    return True


def set_max_active_rigs(limit: int):
    limit = int(limit)
    if limit < 1 or limit > 100:
        raise ValueError("Лимит активных ригов должен быть от 1 до 100")

    with state_lock:
        state["max_active_rigs"] = limit

    save_state()
    logger.info("Лимит активных ригов установлен: %s", limit)


def adjust_max_active_rigs(delta: int) -> int:
    current = get_max_active_rigs()
    new_limit = max(1, min(100, current + int(delta)))
    set_max_active_rigs(new_limit)
    return new_limit


def format_rental_limit_menu() -> str:
    limit = get_max_active_rigs()
    active = get_active_rental_count()

    return (
        "📦 <b>ЛИМИТ АКТИВНЫХ АРЕНД</b>\n\n"
        f"Сейчас активно: <code>{active}</code> из <code>{limit}</code> ригов\n\n"
        "Когда лимит достигнут, новые автоматические и ручные аренды "
        "не создаются.\n"
        "Продление уже арендованного ON-DEMAND рига не считается новой арендой."
    )


def build_rental_limit_keyboard():
    limit = get_max_active_rigs()

    return {
        "inline_keyboard": [
            [
                {"text": "➖ 1", "callback_data": "rental_limit:-1"},
                {"text": f"📦 {limit} РИГОВ", "callback_data": "rental_limit:0"},
                {"text": "➕ 1", "callback_data": "rental_limit:+1"},
            ],
            [
                {"text": "➖ 5", "callback_data": "rental_limit:-5"},
                {"text": "➕ 5", "callback_data": "rental_limit:+5"},
            ],
            [
                {"text": "↩️ НАЗАД", "callback_data": "rental_limit_back"},
            ],
        ]
    }


# ============================================================
# ORDER
# ============================================================

def build_order_kwargs(
    spot: bool = False,
    spot_price: Optional[float] = None,
):
    kwargs = {
        "image": DOCKER_IMAGE,
        "type": "spot" if spot else "on-demand",
        "currency": CLORE_CURRENCY,
        "ports": OPEN_PORTS,
    }

    if SETUP_COMMAND:
        kwargs["command"] = SETUP_COMMAND

    if JUPYTER_TOKEN:
        kwargs["jupyter_token"] = JUPYTER_TOKEN

    if SSH_PASSWORD:
        kwargs["ssh_password"] = SSH_PASSWORD

    if spot:
        if spot_price is None:
            raise ValueError(
                "Для spot нужен spot_price"
            )

        kwargs["spot_price"] = float(spot_price)

    return kwargs


rental_create_lock = threading.Lock()
create_order_rate_lock = threading.Lock()
_last_create_order_request_monotonic = 0.0


def _wait_for_create_order_slot():
    """Serialize create_order requests and keep a safe minimum interval."""
    global _last_create_order_request_monotonic

    with create_order_rate_lock:
        now = time.monotonic()
        wait_for = (
            _last_create_order_request_monotonic
            + max(0.0, CREATE_ORDER_MIN_INTERVAL)
            - now
        )

        if wait_for > 0:
            logger.info(
                "Clore create_order throttle: ждём %.2f сек",
                wait_for,
            )
            time.sleep(wait_for)

        # Mark the instant immediately before the real HTTP request.
        _last_create_order_request_monotonic = time.monotonic()


def _retry_after_seconds(response) -> float:
    """Read numeric Retry-After when present; otherwise use configured delay."""
    try:
        value = response.headers.get("Retry-After")
        if value is not None:
            return max(0.0, float(value))
    except (TypeError, ValueError, AttributeError):
        pass

    return max(0.0, CREATE_ORDER_RETRY_DELAY)


def execute_create_order(
    server_id: int,
    spot: bool = False,
    spot_price: Optional[float] = None,
    required_price: Optional[float] = None,
):
    """Create a Clore order via the REST API.

    The REST endpoint returns {"code": 0} on success rather than an Order
    object. Calling the Python SDK here can therefore fail while validating
    the empty response as an Order.
    """
    kwargs = build_order_kwargs(
        spot=spot,
        spot_price=spot_price,
    )

    payload = {
        "currency": kwargs["currency"],
        "image": kwargs["image"],
        "renting_server": int(server_id),
        "type": kwargs["type"],
        "ports": kwargs["ports"],
    }

    for key in (
        "command",
        "jupyter_token",
        "ssh_password",
    ):
        if kwargs.get(key):
            payload[key] = kwargs[key]

    if spot:
        if spot_price is None:
            raise ValueError("Для spot нужен spot_price")
        # Clore REST API expects spotprice.
        payload["spotprice"] = float(spot_price)
    elif required_price is not None:
        # For ON-DEMAND renewal, require the same total daily price as the
        # previous rental. The public Clore client exposes this as
        # `required_price` on createOrder.
        payload["required_price"] = float(required_price)

    # Final enforcement point for the active-rig limit. The lock prevents
    # concurrent Telegram/background attempts from crossing the configured cap.
    with rental_create_lock:
        if not has_active_rental_capacity():
            active = get_active_rental_count()
            limit = get_max_active_rigs()
            logger.info(
                "Лимит активных ригов достигнут: %s/%s; server_id=%s пропущен",
                active,
                limit,
                server_id,
            )
            raise RuntimeError(
                f"Достигнут лимит активных ригов: {active}/{limit}"
            )

        logger.info(
            "Создаю %s order для server_id=%s",
            "SPOT" if spot else "ON-DEMAND",
            server_id
        )

        try:
            data = None

            for attempt in range(1, max(1, CREATE_ORDER_MAX_RETRIES_429) + 2):
                _wait_for_create_order_slot()

                # Serialize the actual create_order request with all other
                # Clore API traffic in this process. The 6s create-order
                # throttle remains the primary limit; this lock prevents a
                # simultaneous GET from colliding with the POST.
                global _last_clore_request_monotonic
                with clore_request_gate_lock:
                    _last_clore_request_monotonic = time.monotonic()
                    response = CLORE_SESSION.post(
                        "https://api.clore.ai/v1/create_order",
                        headers=CLORE_HEADERS,
                        json=payload,
                        timeout=30,
                    )

                if response.status_code == 429:
                    if attempt > max(1, CREATE_ORDER_MAX_RETRIES_429):
                        retry_after = _retry_after_seconds(response)
                        raise RuntimeError(
                            "429 Too Many Requests: лимит Clore's create_order "
                            f"не снят после {attempt - 1} повторов; "
                            f"последняя Retry-After={retry_after:.1f}s"
                        )

                    retry_after = _retry_after_seconds(response)
                    wait_seconds = max(
                        retry_after,
                        CREATE_ORDER_MIN_INTERVAL,
                    )
                    logger.warning(
                        "Clore create_order: HTTP 429 для server_id=%s "
                        "(попытка %s/%s), ждём %.1f сек",
                        server_id,
                        attempt,
                        max(1, CREATE_ORDER_MAX_RETRIES_429),
                        wait_seconds,
                    )
                    time.sleep(wait_seconds)
                    continue

                response.raise_for_status()

                try:
                    data = response.json()
                except ValueError:
                    data = {}

                logger.info(
                    "Clore create_order response: %s",
                    data
                )
                break

            if not isinstance(data, dict):
                data = {}

            if data.get("code") != 0:
                error = data.get("error") or data.get("message") or data
                error_text = str(error)

                # Marketplace data can become stale between the scan and
                # create_order. Do not treat this race as a real bot failure.
                if "server-already-rented" in error_text.lower():
                    invalidate_marketplace_cache()
                    raise RuntimeError(
                        f"server-already-rented: {server_id}"
                    )

                raise RuntimeError(
                    f"Clore create_order отклонил запрос: {error}. "
                    "Цена была защищена required_price, поэтому бот не должен брать более дорогой тариф."
                )

            # create_order normally returns only code=0. Do not call my_orders()
            # after every rental: that extra API request was the biggest avoidable
            # delay in the hot auto-rental path. Use an ID returned directly by the
            # endpoint when available; otherwise keep it as '?'.
            order_id = (
                data.get("id")
                or data.get("order_id")
                or data.get("orderId")
                or "?"
            )

            add_rented(server_id)

            with _account_stats_cache_lock:
                _account_stats_cache["time"] = 0.0
                _account_stats_cache["data"] = None

            result_dict = {
                "code": 0,
                "id": order_id,
                "server_id": int(server_id),
            }

            logger.info(
                "Order создан: %s",
                result_dict
            )

            return result_dict

        except Exception as e:
            logger.error(
                "Ошибка create_order для %s: %s",
                server_id,
                e
            )
            raise


# ============================================================
# SPOT
# ============================================================

def rent_spot(server):
    server_id = get_server_id(server)
    if server_id is None or is_blacklisted(server_id) or is_server_rented(server) or already_rented_by_bot(server_id):
        return False

    spot_daily = extract_price_per_day(server, spot=True)
    if spot_daily is None:
        logger.info("Server %s: spot price не найден", server_id)
        return False

    gpu = get_gpu_name(server)
    gpu_count = get_gpu_count(server)
    spot_per_gpu_day = price_per_day_per_gpu(spot_daily, gpu_count)

    if spot_daily < MIN_SPOT_DAILY or spot_daily > MAX_SPOT_DAILY:
        return False
    if not gpu_matches(gpu) or not gpu_price_matches(gpu, spot_per_gpu_day, spot=True):
        return False

    try:
        result = execute_create_order(
            server_id=server_id,
            spot=True,
            spot_price=spot_daily,
        )
        order_id = result.get("id", "?") if isinstance(result, dict) else "?"

        send_message(
            "🟢 <b>SPOT GPU арендован</b>\n\n"
            f"GPU: <code>{html.escape(gpu)}</code>\n"
            f"Server ID: <code>{server_id}</code>\n"
            f"GPU count: <code>{gpu_count}</code>\n"
            f"Цена сервера: <code>${spot_daily:.4f}/24ч</code>\n"
            f"Цена 1 GPU: <code>${spot_per_gpu_day:.4f}/24ч</code>\n"
            f"≈ <code>${price_per_hour(spot_daily):.4f}/ч</code>\n"
            f"Order ID: <code>{order_id}</code>"
        )
        return True
    except Exception as e:
        send_message(
            "❌ <b>Ошибка SPOT аренды</b>\n\n"
            f"Server: <code>{server_id}</code>\n"
            f"<code>{html.escape(str(e)[:1000])}</code>"
        )
        return False


# ============================================================
# ON-DEMAND
# ============================================================

def rent_on_demand(server):
    server_id = get_server_id(server)
    if server_id is None or is_blacklisted(server_id) or is_server_rented(server) or already_rented_by_bot(server_id):
        return False

    total_daily = extract_price_per_day(server, spot=False)
    if total_daily is None:
        return False

    gpu = get_gpu_name(server)
    gpu_count = get_gpu_count(server)
    price_daily_per_gpu = price_per_day_per_gpu(total_daily, gpu_count)

    if total_daily < MIN_ON_DEMAND_DAILY or total_daily > MAX_ON_DEMAND_DAILY:
        return False
    if not gpu_matches(gpu) or not gpu_price_matches(gpu, price_daily_per_gpu):
        return False

    try:
        logger.info(
            "🔒 ON-DEMAND price lock: server_id=%s required_price=%.4f/24ч",
            server_id,
            total_daily,
        )
        result = execute_create_order(
            server_id=server_id,
            spot=False,
            required_price=total_daily,
        )
        order_id = result.get("id", "?") if isinstance(result, dict) else "?"

        remember_on_demand_rental(
            server_id=server_id,
            total_daily=total_daily,
            per_gpu_daily=price_daily_per_gpu,
            gpu_name=gpu,
            gpu_count=gpu_count,
            order_id=order_id,
        )

        send_message(
            "🟢 <b>ON-DEMAND GPU арендован</b>\n\n"
            f"GPU: <code>{html.escape(gpu)}</code>\n"
            f"Server ID: <code>{server_id}</code>\n"
            f"GPU count: <code>{gpu_count}</code>\n"
            f"Цена сервера: <code>${total_daily:.4f}/24ч</code>\n"
            f"Цена 1 GPU: <code>${price_daily_per_gpu:.4f}/24ч</code>\n"
            f"≈ <code>${price_per_hour(total_daily):.4f}/ч</code>\n"
            f"Order ID: <code>{order_id}</code>",
            build_rented_notification_keyboard(server_id),
        )
        return True
    except Exception as e:
        error_text = str(e)

        if "server-already-rented" in error_text.lower():
            # This is a normal marketplace race: the server was free when
            # scanned but another renter got it before create_order.
            # Cache is already invalidated in execute_create_order().
            logger.info(
                "ON-DEMAND пропущен: server_id=%s уже арендован",
                server_id,
            )
            return False

        if "достигнут лимит активных ригов" in error_text.lower():
            # Manual Telegram rent attempts still get an immediate response.
            notify_active_rental_limit(server_id=server_id, mode="ON-DEMAND")
            return False

        send_message(
            "❌ <b>Ошибка ON-DEMAND аренды</b>\n\n"
            f"Server: <code>{server_id}</code>\n"
            f"<code>{html.escape(error_text[:1000])}</code>"
        )
        return False


# ============================================================
# FAST AUTO-RENT PATH
# ============================================================

def _rent_prevalidated(candidate, spot=False, auto=False):
    """Create an order from a candidate already validated during this scan."""
    per_gpu_daily, total_daily, server_id, server, gpu_name, gpu_count = candidate

    # A final O(1) local state check prevents duplicate auto-rent attempts when
    # the state was changed after candidate selection.
    if auto and not spot and is_auto_on_demand_paused():
        logger.info(
            "ON-DEMAND auto-rent skipped: paused before create_order, server_id=%s",
            server_id,
        )
        return False
    if is_blacklisted(server_id) or already_rented_by_bot(server_id):
        return False
    if is_server_rented(server):
        return False

    # Final capacity check is done once inside execute_create_order() under
    # rental_create_lock. Avoid a second remote/local capacity check here.
    try:
        logger.info(
            "%s price lock: server_id=%s required_price=%s/24ч",
            "SPOT" if spot else "ON-DEMAND",
            server_id,
            "n/a" if spot else f"{total_daily:.4f}",
        )
        result = execute_create_order(
            server_id=server_id,
            spot=spot,
            spot_price=total_daily if spot else None,
            required_price=None if spot else total_daily,
        )
        order_id = result.get("id", "?") if isinstance(result, dict) else "?"
        order_type = "SPOT" if spot else "ON-DEMAND"

        if not spot:
            remember_on_demand_rental(
                server_id=server_id,
                total_daily=total_daily,
                per_gpu_daily=per_gpu_daily,
                gpu_name=gpu_name,
                gpu_count=gpu_count,
                order_id=order_id,
            )
        send_message(
            f"🟢 <b>{order_type} GPU арендован</b>\n\n"
            f"GPU: <code>{html.escape(gpu_name)}</code>\n"
            f"Server ID: <code>{server_id}</code>\n"
            f"GPU count: <code>{gpu_count}</code>\n"
            f"Цена сервера: <code>${total_daily:.4f}/24ч</code>\n"
            f"Цена 1 GPU: <code>${per_gpu_daily:.4f}/24ч</code>\n"
            f"≈ <code>${total_daily / 24.0:.4f}/ч</code>\n"
            f"Order ID: <code>{order_id}</code>",
            build_rented_notification_keyboard(server_id),
        )
        return True
    except Exception as e:
        error_text = str(e)
        if "server-already-rented" in error_text.lower():
            logger.info(
                "%s пропущен: server_id=%s уже арендован",
                "SPOT" if spot else "ON-DEMAND",
                server_id,
            )
            return False

        if "достигнут лимит активных ригов" in error_text.lower():
            if auto:
                # Automatic scans may hit many matching servers while the cap
                # is full. Send at most one Telegram notification per interval.
                notify_active_rental_limit(
                    server_id=server_id,
                    mode="SPOT" if spot else "ON-DEMAND",
                )
            else:
                # A manual button press should still receive an immediate reply.
                send_message(
                    f"⛔ <b>Достигнут лимит активных ригов</b>\n\n"
                    f"Активно: <code>{get_active_rental_count()}/{get_max_active_rigs()}</code>\n"
                    f"Server: <code>{server_id}</code>"
                )
            return False

        send_message(
            f"❌ <b>Ошибка {'SPOT' if spot else 'ON-DEMAND'} аренды</b>\n\n"
            f"Server: <code>{server_id}</code>\n"
            f"<code>{html.escape(error_text[:1000])}</code>"
        )
        return False


# ============================================================
# MARKETPLACE CHECK
# ============================================================

def build_marketplace_candidate(server, spot=False):
    """Parse and validate one server once; return a sortable candidate or None."""
    server_id = get_server_id(server)
    if server_id is None:
        return None
    if is_blacklisted(server_id) or is_server_rented(server) or already_rented_by_bot(server_id):
        return None

    gpu_name = get_gpu_name(server)
    gpu_key = get_gpu_key(gpu_name)
    if gpu_key is None or gpu_key not in ALLOWED_GPU_KEYS:
        return None

    total_daily = extract_price_per_day(server, spot=spot)
    if total_daily is None:
        return None

    if spot:
        if total_daily < MIN_SPOT_DAILY or total_daily > MAX_SPOT_DAILY:
            return None
    else:
        if total_daily < MIN_ON_DEMAND_DAILY or total_daily > MAX_ON_DEMAND_DAILY:
            return None

    gpu_count = get_gpu_count(server)

    # Auto-rental works with whole rigs containing 1 to 10 GPUs.
    # The order still rents the entire server/rig, not an individual GPU.
    if gpu_count < 1 or gpu_count > 10:
        return None

    per_gpu_daily = price_per_day_per_gpu(total_daily, gpu_count)

    limits = GPU_PRICE_DAILY_RANGES.get(gpu_key) if spot else get_auto_gpu_price_range(gpu_key)
    if limits is None:
        return None

    min_price, max_price = limits
    if not (min_price <= per_gpu_daily <= max_price):
        return None

    return per_gpu_daily, total_daily, server_id, server, gpu_name, gpu_count


def _rent_best_candidates(candidates, rent_func, label):
    if not candidates:
        return 0

    # MAX_RENT_PER_SCAN limits automatic rentals per marketplace scan; nsmallest avoids sorting all candidates.
    limit = max(1, MAX_RENT_PER_SCAN)
    best = nsmallest(limit, candidates, key=lambda item: item[0])
    rented = 0

    for per_gpu_daily, total_daily, server_id, server, gpu_name, gpu_count in best:
        logger.info(
            "Кандидат %s: server_id=%s, %.4f/24ч на GPU; %.4f/24ч сервер",
            label,
            server_id,
            per_gpu_daily,
            total_daily,
        )

        if rent_func(server):
            rented += 1
            if rented >= MAX_RENT_PER_SCAN:
                break

    return rented


_spot_notify_lock = threading.Lock()
_spot_notify_seen = {}


def _spot_notification_allowed(server_id, total_daily, gpu_count):
    """Return True when this SPOT candidate has not been notified recently."""
    key = (int(server_id), round(float(total_daily), 6), int(gpu_count))
    now = time.monotonic()
    with _spot_notify_lock:
        # Cheap cleanup of old entries.
        cutoff = now - max(30.0, SPOT_NOTIFY_COOLDOWN)
        stale = [k for k, ts in _spot_notify_seen.items() if ts < cutoff]
        for k in stale:
            _spot_notify_seen.pop(k, None)

        last = _spot_notify_seen.get(key)
        if last is not None and now - last < SPOT_NOTIFY_COOLDOWN:
            return False

        _spot_notify_seen[key] = now
        return True


def _notify_spot_candidates(candidates):
    """Send matching SPOT rigs to Telegram without auto-renting them."""
    if AUTO_SPOT or not NOTIFY_SPOT_WHEN_AUTO_DISABLED or not candidates:
        return

    # Show the cheapest candidates first and cap one scan notification to 10 rigs
    # to avoid Telegram spam when the marketplace is large.
    selected = nsmallest(
        min(10, len(candidates)),
        candidates,
        key=lambda item: (item[0], item[2]),
    )

    sent = 0
    for candidate in selected:
        per_gpu_daily, total_daily, server_id, server, gpu_name, gpu_count = candidate
        if not _spot_notification_allowed(server_id, total_daily, gpu_count):
            continue

        send_message(
            "🔔 <b>Найден SPOT-риг</b>\n\n"
            + format_server(server),
            build_server_keyboard(server_id),
        )
        sent += 1

    if sent:
        logger.info("SPOT уведомления: отправлено %s риг(ов)", sent)


def _active_limit_gate_allows_marketplace() -> bool:
    """Return whether marketplace auto-rent scanning should continue.

    When the active-rig limit is reached, enter a local pause state. The bot
    then skips marketplace scanning and create_order attempts until Clore
    confirms a state change: fewer active rigs or a higher configured limit.
    """
    global _active_limit_pause
    global _active_limit_pause_active
    global _active_limit_pause_limit

    active = get_active_rental_count()
    limit = get_max_active_rigs()

    with _active_limit_pause_lock:
        was_paused = _active_limit_pause
        paused_active = _active_limit_pause_active
        paused_limit = _active_limit_pause_limit

        if active >= limit:
            if not was_paused:
                _active_limit_pause = True
                _active_limit_pause_active = active
                _active_limit_pause_limit = limit
                logger.info(
                    "⏸️ Автоаренда поставлена на паузу: достигнут лимит %s/%s. "
                    "Marketplace больше не сканируется до изменения состояния.",
                    active,
                    limit,
                )
                notify_active_rental_limit(mode="AUTO")
            elif paused_active != active or paused_limit != limit:
                _active_limit_pause_active = active
                _active_limit_pause_limit = limit
                logger.info(
                    "⏸️ Лимит всё ещё заполнен: состояние изменилось %s/%s → %s/%s. "
                    "Остаёмся на паузе.",
                    paused_active,
                    paused_limit,
                    active,
                    limit,
                )
            return False

        if was_paused:
            logger.info(
                "▶️ Лимит освободился или был увеличен: %s/%s (пауза была %s/%s). "
                "Возобновляю marketplace и автоаренду.",
                active,
                limit,
                paused_active,
                paused_limit,
            )
            _active_limit_pause = False
            _active_limit_pause_active = None
            _active_limit_pause_limit = None

        return True


def check_marketplace():
    """Fast, single-pass marketplace scan with an active-limit pause gate."""
    with marketplace_scan_lock:
        logger.info("Проверяю marketplace...")

        # Reconcile the real account state before selecting new rigs.
        # If Clore cannot confirm my_orders(), stop this scan completely.
        if not refresh_active_rented_state(force_refresh=False):
            logger.warning(
                "⛔ Marketplace scan остановлен: активные аренды Clore не подтверждены."
            )
            return

        # ON-DEMAND renewals are handled by the dedicated renewal loop so a
        # slow marketplace scan/Telegram command cannot delay re-rental.

        # IMPORTANT: check the limit BEFORE calling marketplace. When full,
        # the bot enters a real pause and makes no new-rental attempts until
        # Clore reports a state change or the configured limit is increased.
        if (AUTO_ON_DEMAND or AUTO_SPOT) and not _active_limit_gate_allows_marketplace():
            return

        auto_paused = is_auto_on_demand_paused()
        want_spot_rent = AUTO_SPOT
        want_spot_notify = (not AUTO_SPOT) and NOTIFY_SPOT_WHEN_AUTO_DISABLED
        want_od = AUTO_ON_DEMAND and not auto_paused

        if not want_spot_rent and not want_spot_notify and not want_od:
            return

        servers = get_marketplace()
        if not servers:
            logger.info("Marketplace пустой или API не вернул серверы")
            return

        banned_ids, rented_ids = get_scan_state_snapshot()
        want_spot = want_spot_rent or want_spot_notify

        spot_candidates = [] if want_spot else None
        ondemand_candidates = [] if want_od else None
        ondemand_ranges = get_auto_price_ranges_snapshot() if want_od else {}

        allowed_gpu_keys = ALLOWED_GPU_KEYS
        spot_price_ranges = GPU_PRICE_DAILY_RANGES

        for server in servers:
            server_id = get_server_id(server)
            if server_id is None or server_id in banned_ids or server_id in rented_ids:
                continue

            # Cheapest common parsing path: GPU is needed by both modes.
            gpu_name = get_gpu_name(server)
            gpu_key = get_gpu_key(gpu_name)
            if gpu_key is None or gpu_key not in allowed_gpu_keys:
                continue

            # Only calculate GPU count when at least one active auto mode needs it.
            gpu_count = get_gpu_count(server)
            if gpu_count < 1:
                gpu_count = 1

            if spot_candidates is not None:
                spot_daily = extract_price_per_day(server, spot=True)
                if spot_daily is not None and MIN_SPOT_DAILY <= spot_daily <= MAX_SPOT_DAILY:
                    limits = spot_price_ranges.get(gpu_key)
                    if limits is not None:
                        per_gpu_daily = spot_daily / gpu_count
                        if limits[0] <= per_gpu_daily <= limits[1]:
                            spot_candidates.append(
                                (per_gpu_daily, spot_daily, server_id, server, gpu_name, gpu_count)
                            )

            # 1..10 GPU restriction remains ON-DEMAND only.
            if ondemand_candidates is not None and gpu_count <= 10:
                limits = ondemand_ranges.get(gpu_key)
                if limits is not None:
                    od_daily = extract_price_per_day(server, spot=False)
                    if od_daily is not None and MIN_ON_DEMAND_DAILY <= od_daily <= MAX_ON_DEMAND_DAILY:
                        per_gpu_daily = od_daily / gpu_count
                        if limits[0] <= per_gpu_daily <= limits[1]:
                            ondemand_candidates.append(
                                (per_gpu_daily, od_daily, server_id, server, gpu_name, gpu_count)
                            )

        # With AUTO_SPOT disabled, only notify; never call the SPOT rent path.
        if want_spot_notify:
            _notify_spot_candidates(spot_candidates)

        rented_this_scan = 0
        limit = max(1, MAX_RENT_PER_SCAN)

        # The active-limit gate above already prevents entering this section
        # when the cap is full. Keep a final safety check here for races where
        # another thread fills the last slot between the initial gate and the
        # create-order loop.
        if (want_spot_rent or want_od) and not has_active_rental_capacity():
            notify_active_rental_limit(
                mode="SPOT" if want_spot_rent and not want_od else "ON-DEMAND"
            )
            logger.info(
                "Marketplace auto-rent stopped by final capacity check: %s/%s",
                get_active_rental_count(),
                get_max_active_rigs(),
            )
            return

        # SPOT priority remains unchanged when AUTO_SPOT is enabled.
        if want_spot_rent and spot_candidates:
            for candidate in nsmallest(limit, spot_candidates, key=lambda item: (item[0], item[2])):
                if not has_active_rental_capacity():
                    notify_active_rental_limit(
                        server_id=candidate[2],
                        mode="SPOT",
                    )
                    logger.info("SPOT auto-rent loop stopped: active-rig limit reached")
                    break
                if _rent_prevalidated(candidate, spot=True, auto=True):
                    rented_this_scan += 1
                    if rented_this_scan >= limit:
                        break

        if ondemand_candidates and rented_this_scan < limit:
            remaining = limit - rented_this_scan
            for candidate in nsmallest(remaining, ondemand_candidates, key=lambda item: (item[0], item[2])):
                if is_auto_on_demand_paused():
                    logger.info("ON-DEMAND auto-rent loop stopped: paused")
                    break
                if not has_active_rental_capacity():
                    notify_active_rental_limit(
                        server_id=candidate[2],
                        mode="ON-DEMAND",
                    )
                    logger.info("ON-DEMAND auto-rent loop stopped: active-rig limit reached")
                    break
                if _rent_prevalidated(candidate, spot=False, auto=True):
                    rented_this_scan += 1
                    if rented_this_scan >= limit:
                        break


# ============================================================
# FIND SERVER
# ============================================================

def find_server_fresh(server_id: int):
    servers = get_marketplace(force_refresh=True)

    for server in servers:
        sid = get_server_id(server)

        if sid == server_id:
            return server

    return None


# ============================================================
# TELEGRAM KEYBOARD
# ============================================================

def build_server_keyboard(server_id: int):
    return {
        "inline_keyboard": [
            [
                {
                    "text": "🟢 Арендовать ON-DEMAND",
                    "callback_data": f"rent_od:{server_id}",
                }
            ],
            [
                {
                    "text": "🟡 Арендовать SPOT",
                    "callback_data": f"rent_spot:{server_id}",
                }
            ],
            [
                {
                    "text": "🚫 В blacklist",
                    "callback_data": f"ban:{server_id}",
                }
            ],
        ]
    }


def build_rented_notification_keyboard(server_id: int):
    """Keyboard shown on rental notifications; currently only blacklist is needed."""
    return {
        "inline_keyboard": [
            [
                {
                    "text": "🚫 ЗАБАНИТЬ SERVER",
                    "callback_data": f"ban:{server_id}",
                }
            ]
        ]
    }


def build_auto_rent_keyboard():
    paused = is_auto_on_demand_paused()
    active = get_active_rental_count()
    limit = get_max_active_rigs()
    return {
        "inline_keyboard": [
            [
                {
                    "text": "▶️ ЗАПУСТИТЬ АВТОАРЕНДУ" if paused else "⛔ ПАУЗА АВТОАРЕНДЫ",
                    "callback_data": "auto_od_start" if paused else "auto_od_pause",
                }
            ],
            [
                {
                    "text": "⚙️ ЦЕНЫ АВТОАРЕНДЫ",
                    "callback_data": "auto_prices",
                }
            ],
            [
                {
                    "text": f"🎛 ЛИМИТ АРЕНД: {active}/{limit} РИГОВ",
                    "callback_data": "rental_limit",
                }
            ],
            [
                {"text": "📊 /stats", "callback_data": "cmd_stats"},
                {"text": "📋 /status", "callback_data": "cmd_status"},
            ],
            [
                {"text": "🖥 /market", "callback_data": "cmd_market"},
                {"text": "🔎 /scan", "callback_data": "cmd_scan"},
            ],
            [
                {"text": "⚙️ /prices", "callback_data": "cmd_prices"},
                {"text": "🚫 БАН", "callback_data": "ban_menu"},
                {"text": "🔓 РАЗБАН", "callback_data": "unban_menu"},
            ],
        ]
    }


def build_ban_keyboard(server_id: int):
    return {
        "inline_keyboard": [
            [
                {
                    "text": "🚫 ЗАБАНИТЬ SERVER",
                    "callback_data": f"ban:{server_id}",
                }
            ],
            [
                {
                    "text": "↩️ НАЗАД",
                    "callback_data": "ban_menu_back",
                }
            ],
        ]
    }


def send_ban_menu():
    servers = get_marketplace()

    if not servers:
        send_message("🚫 <b>БАН</b>\n\nMarketplace пуст.", build_auto_rent_keyboard())
        return

    send_message(
        "🚫 <b>БАН СЕРВЕРОВ</b>\n\n"
        "Выбери сервер, который нужно добавить в blacklist."
    )

    count = 0
    banned_ids, _ = get_scan_state_snapshot()
    for server in servers:
        sid = get_server_id(server)
        if sid is None or sid in banned_ids:
            continue

        gpu = get_gpu_name(server)
        if not gpu_matches(gpu):
            continue

        send_message(
            format_server(server),
            build_ban_keyboard(sid),
        )

        count += 1
        if count >= 20:
            break

    if count == 0:
        send_message(
            "✅ Нет доступных серверов для добавления в blacklist.",
            build_auto_rent_keyboard(),
        )


def build_unban_keyboard():
    """Build buttons for removable servers in the local blacklist."""
    with state_lock:
        removable_ids = sorted(
            sid for sid in blacklist_set
            if sid not in BANNED_SERVER_IDS
        )

    rows = []

    for i in range(0, len(removable_ids), 2):
        row = []
        for sid in removable_ids[i:i + 2]:
            row.append({
                "text": f"🔓 {sid}",
                "callback_data": f"unban:{sid}",
            })
        rows.append(row)

    rows.append([
        {
            "text": "↩️ НАЗАД",
            "callback_data": "unban_menu_back",
        }
    ])

    return {"inline_keyboard": rows}


def send_unban_menu():
    """Show local blacklist IDs that can be removed through Telegram."""
    with state_lock:
        removable_ids = sorted(
            sid for sid in blacklist_set
            if sid not in BANNED_SERVER_IDS
        )
        permanent_ids = sorted(BANNED_SERVER_IDS)

    if not removable_ids:
        lines = [
            "🔓 <b>РАЗБАН СЕРВЕРОВ</b>",
            "",
            "Локальный blacklist пуст.",
        ]

        if permanent_ids:
            lines.extend([
                "",
                "🔒 <b>Постоянный blacklist:</b>",
                ", ".join(str(x) for x in permanent_ids),
            ])

        send_message(
            "\n".join(lines),
            build_auto_rent_keyboard(),
        )
        return

    lines = [
        "🔓 <b>РАЗБАН СЕРВЕРОВ</b>",
        "",
        "Нажми на ID сервера, который нужно удалить из blacklist.",
        "",
    ]

    if permanent_ids:
        lines.extend([
            "🔒 Постоянные ID нельзя разблокировать из Telegram:",
            ", ".join(str(x) for x in permanent_ids),
            "",
        ])

    lines.append(
        f"Доступно для разблокировки: <code>{len(removable_ids)}</code>"
    )

    send_message(
        "\n".join(lines),
        build_unban_keyboard(),
    )


def gpu_display_name(gpu_key: str) -> str:
    return GPU_DISPLAY_NAMES.get(gpu_key, gpu_key)


def format_auto_prices_menu() -> str:
    lines = [
        "⚙️ <b>ЦЕНЫ АВТОАРЕНДЫ</b>",
        "",
        "Только <b>ON-DEMAND</b>.",
        "Цена указана за <b>1 GPU / 24 часа</b>.",
        "",
    ]

    ranges = get_auto_price_ranges_snapshot()
    active = 0
    for gpu_key in ALLOWED_GPUS:
        limits = ranges.get(gpu_key)
        if limits is None:
            lines.append(
                f"⛔ <code>{html.escape(gpu_display_name(gpu_key))}</code> — не настроена"
            )
            continue

        active += 1
        min_price, max_price = limits
        lines.append(
            f"✅ <code>{html.escape(gpu_display_name(gpu_key))}</code> — "
            f"<code>${min_price:.2f}–${max_price:.2f}/24ч</code> за 1 GPU"
        )

    if active == 0:
        lines.append("❌ Нет GPU с настроенной ценой для автоаренды.")

    lines.extend([
        "",
        "Нажми кнопку GPU ниже, чтобы изменить её цену.",
        "SPOT этими настройками не затрагивается.",
    ])
    return "\n".join(lines)


def build_auto_prices_keyboard():
    rows = []
    ranges = get_auto_price_ranges_snapshot()
    for gpu_key in ALLOWED_GPUS:
        limits = ranges.get(gpu_key)
        if limits is None:
            text_value = f"⛔ {gpu_display_name(gpu_key)} — не настроена"
        else:
            min_price, max_price = limits
            text_value = f"🎮 {gpu_display_name(gpu_key)} ${min_price:.2f}–${max_price:.2f}/24ч"

        rows.append([
            {
                "text": text_value,
                "callback_data": f"auto_gpu:{gpu_key}",
            }
        ])

    rows.append([
        {
            "text": "↩️ НАЗАД",
            "callback_data": "auto_prices_back",
        }
    ])
    return {"inline_keyboard": rows}


def format_auto_gpu_detail(gpu_key: str) -> str:
    limits = get_auto_gpu_price_range(gpu_key)
    name = gpu_display_name(gpu_key)

    if limits is None:
        return (
            f"⚙️ <b>{html.escape(name)}</b>\n\n"
            "Для этой GPU сейчас нет диапазона цены ON-DEMAND.\n"
            "Она не участвует в автоаренде.\n\n"
            "SPOT не изменяется."
        )

    min_price, max_price = limits
    return (
        f"⚙️ <b>{html.escape(name)}</b>\n\n"
        f"Мин: <code>${min_price:.2f}/24ч</code> за 1 GPU\n"
        f"Макс: <code>${max_price:.2f}/24ч</code> за 1 GPU\n\n"
        "➖/➕ меняют цену на $0.10.\n"
        "Изменения действуют только для автоматического ON-DEMAND."
    )


def build_auto_gpu_detail_keyboard(gpu_key: str):
    return {
        "inline_keyboard": [
            [
                {"text": "➖ Мин $0.10", "callback_data": f"price:min:-0.10:{gpu_key}"},
                {"text": "➕ Мин $0.10", "callback_data": f"price:min:+0.10:{gpu_key}"},
            ],
            [
                {"text": "➖ Макс $0.10", "callback_data": f"price:max:-0.10:{gpu_key}"},
                {"text": "➕ Макс $0.10", "callback_data": f"price:max:+0.10:{gpu_key}"},
            ],
            [
                {"text": "↩️ К СПИСКУ GPU", "callback_data": "auto_prices"},
            ],
        ]
    }


def format_server(server):
    server_id = get_server_id(server)
    gpu = get_gpu_name(server)
    gpu_count = get_gpu_count(server)

    od_total_day = extract_price_per_day(server, spot=False)
    spot_total_day = extract_price_per_day(server, spot=True)

    lines = [
        f"🖥 <b>{html.escape(gpu or 'Unknown GPU')}</b>",
        f"Server ID: <code>{server_id}</code>",
        f"GPU count: <code>{gpu_count}</code>",
    ]

    if od_total_day is not None:
        od_per_gpu_day = price_per_day_per_gpu(od_total_day, gpu_count)
        lines.append(
            f"ON-DEMAND сервер: <code>${od_total_day:.4f}/24ч</code> "
            f"(<code>${price_per_hour(od_total_day):.4f}/ч</code>)"
        )
        lines.append(
            f"ON-DEMAND 1 GPU: <code>${od_per_gpu_day:.4f}/24ч</code>"
        )

    if spot_total_day is not None:
        spot_per_gpu_day = price_per_day_per_gpu(spot_total_day, gpu_count)
        lines.append(
            f"SPOT сервер: <code>${spot_total_day:.4f}/24ч</code> "
            f"(<code>${price_per_hour(spot_total_day):.4f}/ч</code>)"
        )
        lines.append(
            f"SPOT 1 GPU: <code>${spot_per_gpu_day:.4f}/24ч</code>"
        )

    return "\n".join(lines)


# ============================================================
# ACCOUNT STATISTICS
# ============================================================

CLORE_BASE_URL = "https://api.clore.ai/v1"
ACCOUNT_STATS_CACHE_TTL = float(os.getenv("ACCOUNT_STATS_CACHE_TTL", "15"))
_account_stats_cache = {"time": 0.0, "data": None}
_account_stats_cache_lock = threading.Lock()


MY_ORDERS_CACHE_TTL = float(os.getenv("MY_ORDERS_CACHE_TTL", "30"))
_my_orders_cache = {"time": 0.0, "orders": None}
_my_orders_cache_lock = threading.Lock()


def _call_sdk_my_orders(include_completed: bool = False) -> list[dict]:
    """Get raw my_orders JSON without SDK model validation.

    Clore may return API fields such as pub_cluster/tcp_ports in shapes that
    are newer/different from the installed SDK Pydantic Order model. Parsing
    the raw REST response avoids validation failures while keeping the same
    process-wide request rate gate and 429 retry handling.
    """
    data = clore_get(
        "my_orders",
        {"return_completed": "true" if include_completed else "false"},
    )
    return _normalize_orders_payload(data)


def get_clore_orders_cached(
    force_refresh: bool = False,
    include_completed: bool = False,
) -> list[dict]:
    """Shared cached order snapshot for renewal and active-rental counting."""
    now = time.monotonic()

    with _my_orders_cache_lock:
        cached = _my_orders_cache.get("orders")
        cached_at = float(_my_orders_cache.get("time", 0.0) or 0.0)
        if (
            not force_refresh
            and cached is not None
            and now - cached_at < MY_ORDERS_CACHE_TTL
        ):
            return list(cached)

    # Keep authenticated order reads low as well: renewal and the 20-rig
    # counter share the same raw JSON snapshot.
    last_exc = None
    for attempt in range(2):
        try:
            orders = _call_sdk_my_orders(include_completed=include_completed)
            with _my_orders_cache_lock:
                _my_orders_cache["time"] = time.monotonic()
                _my_orders_cache["orders"] = list(orders)
            return list(orders)
        except Exception as exc:
            last_exc = exc
            if attempt == 0 and ("429" in str(exc) or "Too Many Requests" in str(exc)):
                time.sleep(2.2)
                continue
            break

    raise last_exc if last_exc is not None else RuntimeError("my_orders() failed")


def clore_get(endpoint: str, params: Optional[dict] = None):
    """GET JSON from Clore REST API using a shared process-wide rate gate."""
    url = f"{CLORE_BASE_URL}/{endpoint.lstrip('/')}"
    last_response = None

    for attempt in range(1, 4):
        try:
            _wait_for_clore_request_slot()
            response = CLORE_SESSION.get(
                url,
                params=params or {},
                timeout=30,
            )
            last_response = response

            if response.status_code == 429:
                retry_after = 0.0
                try:
                    retry_after = float(response.headers.get("Retry-After", 0) or 0)
                except (TypeError, ValueError):
                    retry_after = 0.0

                if retry_after <= 0:
                    retry_after = min(8.0, 1.5 * attempt)

                if attempt < 3:
                    logger.warning(
                        "Clore GET %s: HTTP 429 (попытка %s/3), ждём %.1f сек",
                        endpoint,
                        attempt,
                        retry_after,
                    )
                    time.sleep(max(retry_after, CLORE_GET_MIN_INTERVAL))
                    continue

            response.raise_for_status()
            data = response.json()

            if data.get("code") != 0:
                raise RuntimeError(
                    f"Clore API error {data.get('code')}: {data.get('error', data)}"
                )

            return data

        except requests.HTTPError:
            if last_response is not None and last_response.status_code == 429 and attempt < 3:
                continue
            raise

    if last_response is not None:
        last_response.raise_for_status()
    raise RuntimeError(f"Clore GET {endpoint} failed")



def money_symbol(currency: str) -> str:
    currency = (currency or "").upper()
    if currency == "USD-BLOCKCHAIN":
        return "$"
    if currency == "CLORE-BLOCKCHAIN":
        return "CLORE "
    if currency == "BITCOIN":
        return "BTC "
    return f"{currency} " if currency else ""


def fmt_money(value: float, currency: str) -> str:
    try:
        return f"{money_symbol(currency)}{float(value):.6f}"
    except Exception:
        return f"{money_symbol(currency)}0.000000"


def order_gpu_name(order: dict) -> str:
    specs = order.get("specs", {})
    gpu = get_value(
        specs,
        "gpu",
        default=None,
    )
    if gpu is None:
        gpu = order.get("gpu", "Unknown GPU")
    return str(gpu)


def estimate_order_spend_last_24h(order: dict, now: Optional[float] = None) -> float:
    """Best-effort 24h spend estimate from documented my_orders fields.

    Clore exposes order spend and creation time, but does not expose a
    per-24h spend field. For orders created within the last 24h we use their
    cumulative spend. For older active orders we use their daily price.
    """
    if now is None:
        now = time.time()

    try:
        spend = max(0.0, float(order.get("spend", 0) or 0))
    except Exception:
        spend = 0.0

    try:
        created = float(order.get("ct", 0) or 0)
    except Exception:
        created = 0.0

    age = now - created if created > 0 else 0

    # The order was created during this 24h window, so its cumulative spend
    # belongs to the current 24h period.
    if age <= 86400:
        return spend

    # For an older active order, price is documented as the cost per day.
    if not bool(order.get("expired", False)):
        try:
            return max(0.0, float(order.get("price", 0) or 0))
        except Exception:
            return 0.0

    # Older completed orders do not expose an exact completion timestamp in
    # the documented response, so they cannot be allocated precisely to the
    # last 24h without guessing.
    return 0.0


def _normalize_wallets_payload(data: Any) -> list[dict]:
    """Normalize several wallet response shapes into a list of dicts."""
    if not isinstance(data, dict):
        return []

    raw = data.get("wallets")
    if raw is None:
        raw = data.get("balances")
    if raw is None:
        raw = data.get("wallet")

    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]

    if isinstance(raw, dict):
        # Typical shape: {"USD-Blockchain": {"balance": ...}, ...}
        if all(isinstance(v, dict) for v in raw.values()):
            result = []
            for name, item in raw.items():
                row = dict(item)
                row.setdefault("name", name)
                result.append(row)
            return result

        # Alternative shape: {"USD-Blockchain": 12.34, ...}
        result = []
        for name, value in raw.items():
            if isinstance(value, (int, float, str)):
                result.append({"name": name, "balance": value})
        return result

    return []


def _normalize_orders_payload(data: Any) -> list[dict]:
    """Normalize order response to a list without changing order contents."""
    if not isinstance(data, dict):
        return []
    raw = data.get("orders")
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    if isinstance(raw, dict):
        return [item for item in raw.values() if isinstance(item, dict)]
    return []


def _short_account_error(exc: Exception) -> str:
    """Return a Telegram-safe, compact API error description."""
    text = str(exc).strip()
    if not text:
        text = type(exc).__name__
    return text[:350]


def get_account_stats() -> dict:
    """Return account data with independent wallet/order error handling.

    Wallet and order requests are intentionally independent: a failure of one
    endpoint must not make the other value show as simply "недоступно".
    """
    now_monotonic = time.monotonic()
    with _account_stats_cache_lock:
        cached = _account_stats_cache.get("data")
        cached_at = _account_stats_cache.get("time", 0.0)
        if cached is not None and now_monotonic - cached_at < ACCOUNT_STATS_CACHE_TTL:
            return cached

    result = {
        "orders": [],
        "active_orders": [],
        "wallets": [],
        "balance": None,
        "balance_currency": CLORE_CURRENCY,
        "spend_24h": None,
        "wallet_error": None,
        "orders_error": None,
    }

    # Wallets still use REST, but all direct GETs pass through the shared
    # application-level rate gate. Orders reuse the SDK-backed shared cache
    # below, so /stats and /status do not issue competing my_orders requests.
    try:
        wallets_data = clore_get("wallets")
        wallets = _normalize_wallets_payload(wallets_data)
        result["wallets"] = wallets

        target_wallet = None
        target_currency = CLORE_CURRENCY.upper()
        for wallet in wallets:
            name = str(wallet.get("name", wallet.get("currency", "")))
            if name.upper() == target_currency:
                target_wallet = wallet
                break

        if target_wallet is None and wallets:
            target_wallet = wallets[0]

        if target_wallet:
            raw_balance = target_wallet.get("balance")
            if raw_balance is None:
                raw_balance = target_wallet.get("available")
            try:
                result["balance"] = float(raw_balance or 0)
            except Exception:
                result["balance"] = 0.0

            result["balance_currency"] = str(
                target_wallet.get(
                    "name",
                    target_wallet.get("currency", CLORE_CURRENCY),
                )
            )
        elif wallets_data:
            # Some API versions may return a single balance object directly.
            raw_balance = wallets_data.get("balance")
            if raw_balance is not None:
                result["balance"] = float(raw_balance or 0)
                result["balance_currency"] = str(
                    wallets_data.get("currency", CLORE_CURRENCY)
                )

    except Exception as exc:
        result["wallet_error"] = _short_account_error(exc)
        logger.warning("Clore wallets() failed: %s", exc)

    try:
        # Reuse the same raw-JSON, rate-limited order snapshot as renewal and
        # the 20-rig capacity check. This prevents /stats and /status from
        # generating competing my_orders requests.
        orders = get_clore_orders_cached(
            force_refresh=False,
            include_completed=False,
        )

        result["orders"] = orders
        result["active_orders"] = [
            order for order in orders
            if not bool(order.get("expired", False))
        ]

        now = time.time()
        result["spend_24h"] = sum(
            estimate_order_spend_last_24h(order, now)
            for order in orders
        )

    except Exception as exc:
        result["orders_error"] = _short_account_error(exc)
        logger.warning("Clore my_orders() failed: %s", exc)

    with _account_stats_cache_lock:
        _account_stats_cache["time"] = time.monotonic()
        _account_stats_cache["data"] = result

    return result


def format_account_stats() -> str:
    stats = get_account_stats()
    active_orders = stats["active_orders"]
    all_orders = stats["orders"]

    lines = [
        "💰 <b>Статистика Clore</b>",
        "",
        f"Баланс: <code>{html.escape(fmt_money(stats['balance'], stats['balance_currency']))}</code>",
        f"Трата за 24ч: <code>{html.escape(fmt_money(stats['spend_24h'], stats['balance_currency']))}</code>",
        f"Активных ордеров: <code>{len(active_orders)}</code>",
        f"Всего ордеров в истории: <code>{len(all_orders)}</code>",
        "",
    ]

    if not active_orders:
        lines.append("📭 Активных ордеров нет.")
        return "\n".join(lines)

    lines.append("🖥 <b>Мои активные ордера:</b>")

    for order in active_orders[:20]:
        order_id = order.get("id", "?")
        server_id = order.get("si", "?")
        gpu = html.escape(order_gpu_name(order))
        currency = str(order.get("currency", stats["balance_currency"]))

        try:
            daily_price = float(order.get("price", 0) or 0)
        except Exception:
            daily_price = 0.0

        try:
            spent = float(order.get("spend", 0) or 0)
        except Exception:
            spent = 0.0

        order_type = "SPOT" if bool(order.get("spot", False)) else "ON-DEMAND"

        lines.extend([
            "",
            f"<b>#{html.escape(str(order_id))}</b> | {order_type}",
            f"GPU: <code>{gpu}</code>",
            f"Server: <code>{html.escape(str(server_id))}</code>",
            f"Цена: <code>{html.escape(fmt_money(daily_price, currency))}/24ч</code>",
            f"Потрачено: <code>{html.escape(fmt_money(spent, currency))}</code>",
        ])

    if len(active_orders) > 20:
        lines.extend([
            "",
            f"… и ещё <code>{len(active_orders) - 20}</code> ордеров."
        ])

    return "\n".join(lines)


# ============================================================
# TELEGRAM COMMANDS
# ============================================================

def send_start_message():
    # Refresh once before displaying the menu, so the counter is not based on
    # an old bot_state.json after restart.
    refresh_active_rented_state(force_refresh=True)
    paused = is_auto_on_demand_paused()

    text = (
        "🤖 <b>Clore GPU Bot</b>\n\n"
        f"Auto ON-DEMAND: <code>{AUTO_ON_DEMAND}</code>\n"
        f"Статус автоаренды: <code>{'ПАУЗА' if paused else 'РАБОТАЕТ'}</code>\n"
        f"Auto SPOT: <code>{AUTO_SPOT}</code>\n"
        f"Активных ригов: <code>{get_active_rental_count()}</code>/<code>{get_max_active_rigs()}</code>\n"
        f"Scan: <code>{SCAN_DELAY}s</code>\n\n"
        "Бот подключён к CloreAI SDK.\n\n"
        "Ниже кнопки управления ON-DEMAND и основные команды.\n"
    )

    send_message(
        text,
        build_auto_rent_keyboard()
    )


def handle_callback(callback):
    callback_id = str(callback.get("id", ""))
    data = str(callback.get("data", ""))

    # Быстро закрываем spinner Telegram. Повторно отвечаем ниже только там,
    # где пользователю нужно короткое подтверждение действия.
    if callback_id:
        answer_callback(callback_id)

    # --------------------------------------------------------
    # COMMAND BUTTONS
    # --------------------------------------------------------
    if data in {
        "cmd_stats",
        "cmd_status",
        "cmd_market",
        "cmd_scan",
        "cmd_prices",
    }:
        command = data.replace("cmd_", "/", 1)
        send_message(f"🔹 Открываю <code>{command}</code>...")
        handle_message({
            "text": command,
            "chat": {"id": TG_CHAT_ID},
        })
        return

    # --------------------------------------------------------
    # BAN MENU
    # --------------------------------------------------------
    if data == "ban_menu":
        send_ban_menu()
        return

    if data == "ban_menu_back":
        send_start_message()
        return

    # --------------------------------------------------------
    # UNBAN MENU
    # --------------------------------------------------------
    if data == "unban_menu":
        send_unban_menu()
        return

    if data == "unban_menu_back":
        send_start_message()
        return

    # --------------------------------------------------------
    # ACTIVE RENTAL LIMIT
    # --------------------------------------------------------
    if data == "rental_limit":
        send_message(
            format_rental_limit_menu(),
            build_rental_limit_keyboard(),
        )
        return

    if data == "rental_limit_back":
        send_start_message()
        return

    if data.startswith("rental_limit:"):
        try:
            delta = int(data.split(":", 1)[1])

            if delta == 0:
                send_message(
                    format_rental_limit_menu(),
                    build_rental_limit_keyboard(),
                )
                return

            new_limit = adjust_max_active_rigs(delta)

            if callback_id:
                answer_callback(
                    callback_id,
                    f"Лимит: {new_limit} активных ригов",
                )

            send_message(
                format_rental_limit_menu(),
                build_rental_limit_keyboard(),
            )
        except Exception as e:
            if callback_id:
                answer_callback(
                    callback_id,
                    str(e)[:180],
                )
        return

    if data.startswith("unban:"):
        try:
            server_id = int(data.split(":", 1)[1])
            success, reason = unban_server(server_id)

            if success:
                send_message(
                    f"🔓 <b>Server {server_id} разблокирован</b>\n\n"
                    f"Server <code>{server_id}</code> удалён из локального blacklist.",
                    build_auto_rent_keyboard(),
                )
            elif reason == "permanent":
                send_message(
                    f"🔒 <b>Server {server_id} постоянный</b>\n\n"
                    "Этот сервер находится в BANNED_SERVER_IDS и "
                    "не может быть удалён из постоянного blacklist."
                )
            else:
                send_message(
                    f"ℹ️ Server <code>{server_id}</code> не найден в blacklist.",
                    build_auto_rent_keyboard(),
                )

        except Exception as e:
            send_message(
                "❌ Ошибка разбана:\n"
                f"<code>{html.escape(str(e))}</code>"
            )
        return

    # --------------------------------------------------------
    # AUTO ON-DEMAND ONLY
    # --------------------------------------------------------
    if data == "auto_od_pause":
        if is_auto_on_demand_paused():
            if callback_id:
                answer_callback(
                    callback_id,
                    "Автоаренда ON-DEMAND уже на паузе"
                )
            return

        set_auto_on_demand_paused(True)

        send_message(
            "⛔ <b>АВТОАРЕНДА ON-DEMAND ПРИОСТАНОВЛЕНА</b>\n\n"
            "Новые автоматические ON-DEMAND аренды не создаются.\n"
            "SPOT не изменён.\n"
            "Ручная кнопка аренды ON-DEMAND продолжает работать.",
            build_auto_rent_keyboard()
        )
        return

    if data == "auto_od_start":
        if not is_auto_on_demand_paused():
            if callback_id:
                answer_callback(
                    callback_id,
                    "Автоаренда ON-DEMAND уже запущена"
                )
            return

        set_auto_on_demand_paused(False)

        send_message(
            "▶️ <b>АВТОАРЕНДА ON-DEMAND ЗАПУЩЕНА</b>\n\n"
            "Автоматическая ON-DEMAND аренда снова активна.\n"
            "SPOT не изменён.",
            build_auto_rent_keyboard()
        )
        return

    # --------------------------------------------------------
    # AUTO ON-DEMAND PRICE SETTINGS ONLY
    # --------------------------------------------------------
    if data == "auto_prices":
        send_message(
            format_auto_prices_menu(),
            build_auto_prices_keyboard(),
        )
        return

    if data == "auto_prices_back":
        send_start_message()
        return

    if data.startswith("auto_gpu:"):
        gpu_key = data.split(":", 1)[1]
        if gpu_key not in ALLOWED_GPUS:
            if callback_id:
                answer_callback(callback_id, "Неизвестная GPU")
            return

        send_message(
            format_auto_gpu_detail(gpu_key),
            build_auto_gpu_detail_keyboard(gpu_key),
        )
        return

    if data.startswith("price:"):
        parts = data.split(":", 3)
        if len(parts) != 4:
            if callback_id:
                answer_callback(callback_id, "Неверная команда цены")
            return

        _, which, delta_text, gpu_key = parts

        if gpu_key not in ALLOWED_GPUS:
            if callback_id:
                answer_callback(callback_id, "Неизвестная GPU")
            return

        try:
            min_price, max_price = adjust_auto_gpu_price(
                gpu_key,
                which,
                float(delta_text),
            )
        except Exception as e:
            if callback_id:
                answer_callback(callback_id, str(e)[:180])
            return

        if callback_id:
            answer_callback(
                callback_id,
                f"${min_price:.2f}–${max_price:.2f}/24ч"
            )

        send_message(
            format_auto_gpu_detail(gpu_key),
            build_auto_gpu_detail_keyboard(gpu_key),
        )
        return

    # --------------------------------------------------------
    # BLACKLIST
    # --------------------------------------------------------
    if data.startswith("ban:"):
        try:
            server_id = int(data.split(":", 1)[1])
            ban_server(server_id)
            send_message(
                f"🚫 Server <code>{server_id}</code> добавлен в blacklist."
            )
        except Exception as e:
            send_message(
                f"❌ Ошибка: <code>{html.escape(str(e))}</code>"
            )
        return

    # --------------------------------------------------------
    # MANUAL ON-DEMAND
    # --------------------------------------------------------
    if data.startswith("rent_od:"):
        try:
            server_id = int(data.split(":", 1)[1])
            server = find_server_fresh(server_id)

            if server is None:
                send_message(
                    "❌ Сервер больше не найден в marketplace."
                )
                return

            if is_server_rented(server):
                send_message("❌ Этот сервер уже занят.")
                return

            # Ручная аренда разрешена даже при паузе автоаренды.
            rent_on_demand(server)
        except Exception as e:
            send_message(
                f"❌ Ошибка: <code>{html.escape(str(e))}</code>"
            )
        return

    # --------------------------------------------------------
    # MANUAL SPOT (UNCHANGED)
    # --------------------------------------------------------
    if data.startswith("rent_spot:"):
        try:
            server_id = int(data.split(":", 1)[1])
            server = find_server_fresh(server_id)

            if server is None:
                send_message(
                    "❌ Сервер больше не найден в marketplace."
                )
                return

            if is_server_rented(server):
                send_message("❌ Этот сервер уже занят.")
                return

            rent_spot(server)
        except Exception as e:
            send_message(
                f"❌ Ошибка: <code>{html.escape(str(e))}</code>"
            )
        return

    logger.warning("Неизвестный Telegram callback: %s", data)


def handle_message(message):
    text = message.get(
        "text",
        ""
    ).strip()

    chat = message.get(
        "chat",
        {}
    )

    chat_id = str(
        chat.get(
            "id",
            ""
        )
    )

    if chat_id != str(TG_CHAT_ID):
        return

    if text == "/start":
        send_start_message()
        return

    if text == "/scan":
        send_message(
            "🔎 Запускаю проверку marketplace..."
        )

        check_marketplace()

        send_message(
            "✅ Проверка завершена."
        )

        return

    if text == "/stats":
        try:
            send_message(format_account_stats())
        except Exception as e:
            logger.exception("Ошибка получения статистики Clore: %s", e)
            send_message(
                "❌ <b>Не удалось получить статистику</b>\n"
                f"<code>{html.escape(str(e)[:1000])}</code>"
            )
        return

    if text == "/prices":
        send_message(
            format_auto_prices_menu(),
            build_auto_prices_keyboard(),
        )
        return

    if text == "/status":
        # /status must show the REAL current Clore state, not stale bot_state.json.
        sync_ok = refresh_active_rented_state(force_refresh=True)

        with state_lock:
            blacklist_count = len(blacklist_set)
            rented_count = len(rented_set)

        paused = is_auto_on_demand_paused()

        try:
            account = get_account_stats()

            if account.get("balance") is None:
                if account.get("wallet_error"):
                    balance_line = (
                        "Balance: <code>ошибка</code> "
                        f"<i>{html.escape(account['wallet_error'])}</i>\n"
                    )
                else:
                    balance_line = "Balance: <code>нет данных</code>\n"
            else:
                balance_line = (
                    f"Balance: <code>{html.escape(fmt_money(account['balance'], account['balance_currency']))}</code>\n"
                )

            if account.get("spend_24h") is None:
                if account.get("orders_error"):
                    spend_line = (
                        "Spend 24h: <code>ошибка</code> "
                        f"<i>{html.escape(account['orders_error'])}</i>\n"
                    )
                else:
                    spend_line = "Spend 24h: <code>нет данных</code>\n"
            else:
                spend_line = (
                    f"Spend 24h: <code>{html.escape(fmt_money(account['spend_24h'], account['balance_currency']))}</code>\n"
                )

            account_line = (
                balance_line
                + spend_line
                + f"Active orders: <code>{len(account['active_orders'])}</code>\n"
            )
        except Exception as e:
            logger.exception("Не удалось добавить Clore stats в /status: %s", e)
            account_line = (
                "Balance: <code>ошибка</code>\n"
                f"Spend 24h: <code>ошибка</code>\n"
                f"<i>{html.escape(_short_account_error(e))}</i>\n"
            )

        send_message(
            "📊 <b>Status</b>\n\n"
            f"Blacklist: <code>{blacklist_count}</code>\n"
            f"Rented by bot: <code>{rented_count}</code> / <code>{get_max_active_rigs()}</code>\n"
            f"Active rental limit: <code>{get_max_active_rigs()}</code> rigs\n"
            f"Clore sync: <code>{'OK' if sync_ok else 'ERROR — NEW RENTALS BLOCKED'}</code>\n"
            f"Auto ON-DEMAND: <code>{AUTO_ON_DEMAND}</code>\n"
            f"Auto ON-DEMAND статус: <code>{'ПАУЗА' if paused else 'РАБОТАЕТ'}</code>\n"
            f"Auto SPOT: <code>{AUTO_SPOT}</code>\n"
            + account_line
        )

        return

    if text == "/market":
        servers = get_marketplace()

        if not servers:
            send_message("Marketplace пуст.")
            return

        count = 0
        banned_ids, _ = get_scan_state_snapshot()

        for server in servers:
            sid = get_server_id(server)

            if sid is None or sid in banned_ids:
                continue

            gpu = get_gpu_name(server)

            if not gpu_matches(gpu):
                continue

            send_message(
                format_server(server),
                build_server_keyboard(sid)
            )

            count += 1

            if count >= 20:
                break

        if count == 0:
            send_message(
                "Подходящих GPU не найдено."
            )


# ============================================================
# TELEGRAM POLLING
# ============================================================

def discard_pending_telegram_updates() -> Optional[int]:
    """Удаляет из локальной очереди старые Telegram updates до старта polling.

    Это важно после ручного/системного запуска: старый callback вроде
    старые Telegram updates не должны обрабатываться повторно.
    Возвращает следующий offset, с которого нужно начать обычный polling.
    """
    try:
        result = telegram_request(
            "getUpdates",
            {
                "offset": -1,
                "limit": 1,
                "timeout": 0,
                "allowed_updates": [
                    "message",
                    "callback_query",
                ],
            },
            timeout=10,
        )
        updates = result.get("result", []) if result else []
        if updates:
            next_offset = int(updates[-1]["update_id"]) + 1
            logger.info(
                "Пропущен старый Telegram update до запуска: next offset=%s",
                next_offset,
            )
            return next_offset
    except Exception as e:
        logger.warning(
            "Не удалось очистить старые Telegram updates: %s",
            e,
        )

    return None


def telegram_polling():
    logger.info("Telegram polling запущен")

    # После любого нового запуска не обрабатываем старые Telegram updates.
    offset = discard_pending_telegram_updates()

    while True:
        try:
            payload = {
                "timeout": 25,
                "allowed_updates": [
                    "message",
                    "callback_query",
                ],
            }

            if offset is not None:
                payload["offset"] = offset

            result = telegram_request(
                "getUpdates",
                payload,
                timeout=35,
            )

            if not result:
                time.sleep(2)
                continue

            updates = result.get(
                "result",
                []
            )

            for update in updates:
                offset = update["update_id"] + 1

                try:
                    if "callback_query" in update:
                        handle_callback(update["callback_query"])
                    elif "message" in update:
                        handle_message(
                            update["message"]
                        )

                except Exception as e:
                    logger.exception(
                        "Ошибка обработки Telegram update: %s",
                        e
                    )

        except Exception as e:
            logger.error(
                "Telegram polling error: %s",
                e
            )

            time.sleep(5)


# ============================================================
# MARKETPLACE LOOP
# ============================================================

def marketplace_loop():
    logger.info(
        "Marketplace loop запущен"
    )

    while True:
        try:
            check_expiry_warnings()
            check_marketplace()

        except Exception as e:
            logger.exception(
                "Ошибка marketplace loop: %s",
                e
            )

        time.sleep(SCAN_DELAY)


def renewal_loop():
    """Independent ON-DEMAND renewal worker.

    It deliberately runs outside marketplace_scan_lock so renewal cannot be
    delayed by a slow marketplace request or a Telegram /market command.
    """
    logger.info("♻️ Renewal loop запущен")

    while True:
        try:
            check_on_demand_renewals()
        except Exception as e:
            logger.exception(
                "Ошибка renewal loop: %s",
                e
            )
        time.sleep(1.0)


# ============================================================
# MAIN
# ============================================================

def main():
    load_state()

    logger.info(
        "======================================"
    )

    logger.info(
        "Clore GPU Telegram Bot"
    )

    logger.info(
        "CLORE SDK: CloreAI"
    )

    logger.info(
        "Currency: %s",
        CLORE_CURRENCY
    )

    logger.info(
        "Auto ON-DEMAND: %s",
        AUTO_ON_DEMAND
    )

    logger.info(
        "Auto ON-DEMAND status: %s",
        "PAUSED" if is_auto_on_demand_paused() else "RUNNING"
    )

    logger.info(
        "Auto SPOT: %s",
        AUTO_SPOT
    )

    logger.info(
        "Active rental limit: %s",
        get_max_active_rigs()
    )

    logger.info(
        "Auto ON-DEMAND renewal: %s",
        AUTO_RENEW_ON_DEMAND
    )

    logger.info(
        "Scan delay: %s sec",
        SCAN_DELAY
    )

    logger.info(
        "Active rental sync TTL: %s sec",
        ACTIVE_RENTAL_SYNC_TTL,
    )

    logger.info(
        "Create order min interval: %s sec",
        CREATE_ORDER_MIN_INTERVAL,
    )

    logger.info(
        "Expiry warning: %s sec before end, check every %s sec",
        EXPIRY_WARNING_SECONDS,
        EXPIRY_CHECK_INTERVAL,
    )

    logger.info(
        "======================================"
    )

    # FIRST: synchronize real active rentals from Clore.
    # This prevents a restart from turning an existing 17/20 into 0/20 or
    # leaving an old local value such as 24/20 in the state file.
    logger.info("🔄 Проверяю уже существующие активные аренды Clore...")
    if refresh_active_rented_state(force_refresh=True):
        logger.info(
            "✅ Стартовая синхронизация: %s/%s активных ригов",
            get_active_rental_count(),
            get_max_active_rigs(),
        )
    else:
        logger.warning(
            "⛔ Стартовая синхронизация не удалась. Новые аренды заблокированы."
        )

    telegram_thread = threading.Thread(
        target=telegram_polling,
        daemon=True,
    )

    telegram_thread.start()

    renewal_thread = threading.Thread(
        target=renewal_loop,
        daemon=True,
    )
    renewal_thread.start()

    send_start_message()

    marketplace_loop()


if __name__ == "__main__":
    try:
        main()

    except KeyboardInterrupt:
        # Ctrl+C — штатная остановка. Не выполняем сетевой запрос к Telegram
        # из обработчика KeyboardInterrupt: если Telegram зависнет, второй
        # Ctrl+C снова прервёт этот обработчик и появится лишний traceback.
        logger.info("======================================")
        logger.info("🛑 Бот остановлен пользователем (Ctrl+C)")
        logger.info("Сетевые запросы при штатном завершении не выполняются.")
        logger.info("======================================")

    except Exception as e:
        logger.exception(
            "Критическая ошибка главного процесса: %s",
            e
        )

        try:
            send_message(
                "❌ <b>Бот аварийно остановлен</b>\n\n"
                f"<code>{html.escape(str(e)[:1000])}</code>"
            )
        except Exception:
            pass
