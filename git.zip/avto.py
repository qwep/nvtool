# -*- coding: utf-8 -*-
import os
import time
import threading
import requests

# --- НАСТРОЙКИ АВТОРИЗАЦИИ CLORE API ---
CLORE_API_KEY = os.getenv("CLORE_API_KEY", "wifPxZXu14V-I7jt-VrJmKexBw1Oobkf")

# --- TELEGRAM SETTINGS ---
TG_TOKEN = os.getenv("TG_TOKEN", "8808589269:AAEandz5_dtIE5KSmakvVQwAeoaceGKcq6A")
TG_CHAT_ID = os.getenv("TG_CHAT_ID", "265459649")

# --- GLOBAL FILTER SETTINGS ---
MIN_PRICE_PER_GPU = 0.50   # Минимальная цена ($ за GPU в сутки)
MAX_PRICE_PER_GPU = 10.50  # Максимальная цена ($ за GPU в сутки)
MIN_GPU_COUNT = 1          # Минимальное количество GPU

# --- НАСТРОЙКИ АРЕНДЫ (CREATE_ORDER API) ---
AUTO_BUY_ENABLED = False        # True = автовыкуп; False = покупка по кнопке в TG
RENT_TYPE = "spot"              # По умолчанию для автовыкупа ("spot" или "on_demand")
RENT_CURRENCY = "USD-Blockchain" # Баланс USD/USDT
DOCKER_IMAGE = "cloreai/jupyter:ubuntu24.04-v2"

# === НАСТРОЙКИ ДОСТУПА И АВТОРИЗАЦИИ В API ===
SSH_PASSWORD = os.getenv("SSH_PASSWORD", "qwep4ik1984")      # SSH пароль
JUPYTER_TOKEN = os.getenv("JUPYTER_TOKEN", "qwep4ik")        # Jupyter токен
JUPYTER_PASSWORD = os.getenv("JUPYTER_PASSWORD", "qwep4ik")  # Jupyter пароль

# Базовый скрипт инициализации при старте контейнера
SETUP_COMMAND = "#!/bin/sh\napt update -y && apt install htop -y"

OPEN_PORTS = {
    "22": "tcp",
    "8888": "http"
}

# --- SYSTEM SETTINGS ---
API_ENDPOINTS = [
    "https://api.clore.ai/v1/marketplace",
    "https://clore.ai/api/v1/marketplace",
    "https://api.clore.ai/v1/servers",
    "https://clore.ai/api/marketplace"
]
CREATE_ORDER_URL = "https://api.clore.ai/v1/create_order"
WORKING_URL = None
DELAY = 20

# Настройка единой HTTP-сессии
session = requests.Session()
session.headers.update({
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Content-Type": "application/json",
    "auth": CLORE_API_KEY,
    "auth-token": CLORE_API_KEY,
    "Auth": CLORE_API_KEY
})

sent_servers = set()


def get_working_endpoint():
    """Динамический поиск доступного URL API"""
    global WORKING_URL
    if WORKING_URL:
        return WORKING_URL

    for url in API_ENDPOINTS:
        try:
            res = session.get(url, timeout=10)
            if res.status_code == 200:
                WORKING_URL = url
                print(f"[+] Успешное подключение к API: {WORKING_URL}")
                return WORKING_URL
        except Exception:
            continue
    
    return API_ENDPOINTS[0]


def execute_create_order(server_id, price_btc, total_price_usd, rent_type=RENT_TYPE):
    """Отправка POST запроса на создание ордера (spot или on_demand)"""
    payload = {
        "currency": RENT_CURRENCY,
        "image": DOCKER_IMAGE,
        "renting_server": int(server_id),
        "type": rent_type
    }

    # Если Spot — указываем целевую spot-цену
    if rent_type == "spot":
        payload["spotprice"] = round(total_price_usd, 4) if RENT_CURRENCY == "USD-Blockchain" else price_btc

    # Добавление параметров авторизации в запрос ордера
    if SSH_PASSWORD:
        payload["ssh_password"] = SSH_PASSWORD
    if JUPYTER_TOKEN:
        payload["jupyter_token"] = JUPYTER_TOKEN
    if JUPYTER_PASSWORD:
        payload["jupyter_password"] = JUPYTER_PASSWORD
    if SETUP_COMMAND:
        payload["command"] = SETUP_COMMAND
    if OPEN_PORTS:
        payload["ports"] = OPEN_PORTS

    print(f"[*] Отправка CREATE_ORDER [{rent_type.upper()} | {RENT_CURRENCY} | ID {server_id} | SpotPrice: {payload.get('spotprice', 'N/A')}]...")
    try:
        res = session.post(CREATE_ORDER_URL, json=payload, timeout=15)
        res_data = res.json()

        if res.status_code == 200 and res_data.get("code") == 0:
            return True, f"Сервер {server_id} успешно арендован ({rent_type.upper()})!\nОтвет API: {res_data}"
        else:
            err = res_data.get("msg") or res_data.get("message") or res_data
            return False, f"Ошибка ордера (ID {server_id}): {err}"
    except Exception as e:
        return False, f"Ошибка сети при отправке ордера: {e}"


def send_telegram_message(text, reply_markup=None):
    tg_url = f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage"
    payload = {
        "chat_id": TG_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": False
    }
    if reply_markup:
        payload["reply_markup"] = reply_markup

    try:
        res = session.post(tg_url, json=payload, timeout=10)
        res.raise_for_status()
    except Exception as e:
        print(f"[!] Ошибка отправки в Telegram: {e}")


def answer_callback(callback_id, text):
    tg_url = f"https://api.telegram.org/bot{TG_TOKEN}/answerCallbackQuery"
    try:
        session.post(tg_url, json={"callback_query_id": callback_id, "text": text}, timeout=5)
    except Exception:
        pass


def telegram_button_listener():
    """Слушатель нажатий кнопок в Telegram"""
    offset = 0
    while True:
        try:
            tg_url = f"https://api.telegram.org/bot{TG_TOKEN}/getUpdates"
            res = session.get(tg_url, params={"offset": offset, "timeout": 5}, timeout=10)

            if res.status_code == 200:
                updates = res.json().get("result", [])
                for update in updates:
                    offset = update["update_id"] + 1

                    if "callback_query" in update:
                        cb = update["callback_query"]
                        cb_id = cb["id"]
                        cb_data = cb.get("data", "")

                        # Формат cb_data: "rent_{rent_type}_{server_id}_{price_btc}_{price_usd}"
                        if cb_data.startswith("rent_"):
                            parts = cb_data.split("_")
                            rent_type = parts[1]  # "spot" или "demand"
                            
                            # Приводим "demand" обратно к "on_demand" для API Clore
                            if rent_type == "demand":
                                rent_type = "on_demand"

                            server_id = parts[2]
                            price_btc = float(parts[3]) if len(parts) > 3 else 0.0
                            price_usd = float(parts[4]) if len(parts) > 4 else 0.0

                            answer_callback(cb_id, f"⏳ Арендуем ({rent_type.upper()})...")
                            success, message = execute_create_order(server_id, price_btc, price_usd, rent_type=rent_type)

                            if success:
                                send_telegram_message(f"✅ <b>АРЕНДА УСПЕШНА ({rent_type.upper()})!</b>\n\n<code>{message}</code>")
                            else:
                                send_telegram_message(f"❌ <b>ОШИБКА АРЕНДЫ ({rent_type.upper()})!</b>\n\n<code>{message}</code>")
        except Exception:
            pass
        time.sleep(1)


def check_marketplace():
    global sent_servers, WORKING_URL
    url = get_working_endpoint()
    print(f"[*] Сканирование (>= {MIN_GPU_COUNT} GPU) | Цель: ${MIN_PRICE_PER_GPU:.2f} - ${MAX_PRICE_PER_GPU:.2f}...")

    try:
        response = session.get(url, timeout=15)

        if response.status_code == 200:
            data = response.json()

            if isinstance(data, list):
                servers = data
                btc_usd = 98500.0
            elif isinstance(data, dict):
                servers = data.get("servers", data.get("items", []))
                market = data.get("market", {})
                btc_usd = market.get("currency_rates_in_usd", {}).get("bitcoin", 98500.0) if isinstance(market, dict) else 98500.0
            else:
                servers = []
                btc_usd = 98500.0

            current_available_ids = set()
            found_count = 0

            for server in servers:
                if not isinstance(server, dict):
                    continue

                server_id = server.get("id")
                if not server_id:
                    continue

                if server.get("rented") is False or server.get("status") == "available":
                    specs = server.get("specs") if isinstance(server.get("specs"), dict) else {}
                    partial = server.get("partial_gpu_rental") if isinstance(server.get("partial_gpu_rental"), dict) else {}
                    price_data = server.get("price") if isinstance(server.get("price"), dict) else {}

                    gpu_count = partial.get("total_gpus", specs.get("total_gpus", specs.get("gpus_count", 1)))
                    if not isinstance(gpu_count, (int, float)) or gpu_count <= 0:
                        gpu_count = 1

                    if gpu_count >= MIN_GPU_COUNT:
                        price_btc = 0
                        if price_data:
                            on_demand = price_data.get("on_demand") if isinstance(price_data.get("on_demand"), dict) else {}
                            spot = price_data.get("spot") if isinstance(price_data.get("spot"), dict) else {}

                            price_btc = spot.get("bitcoin", 0) if RENT_TYPE == "spot" else on_demand.get("bitcoin", 0)
                            if not price_btc:
                                price_btc = on_demand.get("bitcoin", 0) or spot.get("bitcoin", 0)

                        if not price_btc and isinstance(server.get("price"), (int, float)):
                            price_btc = server.get("price")

                        if not price_btc or not isinstance(price_btc, (int, float)):
                            continue

                        total_price_usd = price_btc * btc_usd
                        price_per_gpu = total_price_usd / gpu_count

                        if MIN_PRICE_PER_GPU <= price_per_gpu <= MAX_PRICE_PER_GPU:
                            current_available_ids.add(server_id)
                            found_count += 1

                            if server_id not in sent_servers:
                                gpu_info = specs.get("gpu", specs.get("gpu_model", "Unknown GPU"))
                                net_data = specs.get("net") if isinstance(specs.get("net"), dict) else {}
                                country = net_data.get("cc", "??")

                                msg = (
                                    "🔥 <b>НАЙДЕН ВЫГОДНЫЙ СЕРВЕР!</b>\n\n"
                                    f"🆔 <b>ID:</b> {server_id} [{country}]\n"
                                    f"📟 <b>Конфигурация:</b> {gpu_info} ({gpu_count} GPU)\n"
                                    f"🪙 <b>Цена в BTC:</b> {price_btc:.8f} BTC / день\n"
                                    f"💵 <b>Общая цена:</b> ${total_price_usd:.2f} / день\n"
                                    f"📊 <b>Цена за 1 GPU:</b> ${price_per_gpu:.2f} / день"
                                )

                                if AUTO_BUY_ENABLED:
                                    success, rent_msg = execute_create_order(server_id, price_btc, total_price_usd, rent_type=RENT_TYPE)
                                    msg += f"\n\n🤖 <b>АВТОВЫКУП:</b> {'УСПЕХ' if success else 'ОШИБКА'}\n<code>{rent_msg}</code>"
                                    send_telegram_message(msg)
                                else:
                                    reply_markup = {
                                        "inline_keyboard": [
                                            [
                                                {"text": "⚡ Аренда SPOT", "callback_data": f"rent_spot_{server_id}_{price_btc:.8f}_{total_price_usd:.2f}"},
                                                {"text": "⏳ Аренда ON-DEMAND", "callback_data": f"rent_demand_{server_id}_{price_btc:.8f}_{total_price_usd:.2f}"}
                                            ],
                                            [{"text": "🌐 Маркетплейс", "url": f"https://clore.ai/marketplace?id={server_id}"}]
                                        ]
                                    }
                                    send_telegram_message(msg, reply_markup=reply_markup)

                                sent_servers.add(server_id)

            sent_servers = sent_servers.intersection(current_available_ids)
            print(f"[+] Проверка завершена. Доступно серверов: {found_count}")
            print("-" * 60)

        elif response.status_code == 404:
            print(f"[!] Эндпоинт {url} вернул 404. Сбрасываем и ищем новый...")
            WORKING_URL = None

        elif response.status_code == 429:
            print("[!] Ошибка 429: Rate Limit. Пауза 60 секунд...")
            time.sleep(60)

        else:
            print(f"[!] Ошибка запроса. Статус: {response.status_code}.")

    except Exception as e:
        print(f"[!] Ошибка выполнения: {e}")


if __name__ == "__main__":
    print("=== CLORE.AI MONITOR ЗАПУЩЕН ===")
    send_telegram_message("🚀 <b>Мониторинг запущен!</b> Доступна выборная аренда SPOT / ON-DEMAND.")

    threading.Thread(target=telegram_button_listener, daemon=True).start()

    while True:
        check_marketplace()
        time.sleep(DELAY)