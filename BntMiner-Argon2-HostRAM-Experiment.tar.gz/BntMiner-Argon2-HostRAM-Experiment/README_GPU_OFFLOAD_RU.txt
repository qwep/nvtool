BntMiner: GPU PoW + GPU Stratum JSON, CPU network transport
==========================================================

CPU оставлен только для сетевого транспорта и управляющей логики:
- DNS, TCP, TLS/OpenSSL, приём и отправка сетевых байтов, reconnect;
- управление состоянием Stratum-соединения и request ID / pending shares;
- логирование и передача подготовленных сообщений в сокет.

На GPU перенесено:
- разбор входящих Stratum JSON: job, header_base, target, nonce range, login capabilities,
  notifications и ответы на submit;
- формирование исходящих login и submit JSON, включая escaping строк и claimed_hash hex;
- nonce generation и выдача batch-пачек из device-side cursor;
- непересекающиеся interleaved nonce-shards для нескольких GPU;
- копирование job header в lane-буферы внутри CUDA batch kernel;
- BLAKE2b H0, Argon2 H'(1024), Argon2i address table, Argon2i/Argon2d,
  финальный H'(32), target compare и compact candidate filtering.

Физический приём/отправка TCP/TLS-байтов остаётся на CPU. CPU также ведёт состояние соединения,
очередь отправки и соответствие request ID ответам пула; разбор и сериализация JSON выполняются CUDA.

Параметры Blocknet PoW сохранены: Argon2id v1.3, m=2 GiB, t=1, p=1.
CPU Argon2/BLAKE2b reference оставлен для независимой проверки --test.

Проверки:
  bash tests/run_linux_checks.sh
  ./build_linux.sh
  ./bntminer --test
  ./bntminer --bench 120

В среде подготовки нет nvcc и NVIDIA GPU. Host/reference tests и CPU-stub API checks прошли,
но CUDA compilation и runtime tests должны быть выполнены на целевом сервере до подключения к пулу.
GPU JSON parser/formatter запускается на редких Stratum-сообщениях; копирование и синхронизация
могут оказаться дороже CPU JSON, поэтому перенос не означает гарантированное ускорение.
Для Tesla P4 (sm_61) нужен CUDA Toolkit с поддержкой Pascal, например CUDA 12.9.
