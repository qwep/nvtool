#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

command -v nvcc >/dev/null 2>&1 || { echo "ERROR: nvcc not found; install a CUDA Toolkit compatible with your GPU." >&2; exit 2; }
command -v g++ >/dev/null 2>&1 || { echo "ERROR: g++ not found." >&2; exit 2; }

NVCC_BIN="$(readlink -f "$(command -v nvcc)")"
CUDA_ROOT="$(cd -- "$(dirname -- "$NVCC_BIN")/.." && pwd)"
CUDA_LIBDIR=""
for candidate in "$CUDA_ROOT/lib64" "$CUDA_ROOT/lib" "$CUDA_ROOT/lib/x86_64-linux-gnu" "$CUDA_ROOT/targets/x86_64-linux/lib"; do
    if [[ -e "$candidate/libcudart.so" || -e "$candidate/libcudart.so.12" || -e "$candidate/libcudart.so.13" ]]; then
        CUDA_LIBDIR="$candidate"
        break
    fi
done

# Optional shared-memory layout experiment: default to original pad=4; set BGPU_SMEM_PAD_WORDS=2
# only for an A/B benchmark. The kernel reports the selected value in its startup information.
SMEM_PAD="${BGPU_SMEM_PAD_WORDS:-4}"
if [[ "$SMEM_PAD" != "2" && "$SMEM_PAD" != "4" ]]; then
    echo "ERROR: BGPU_SMEM_PAD_WORDS must be 2 or 4 (got: $SMEM_PAD)." >&2
    exit 2
fi

# Discover this toolkit's supported architectures rather than hard-coding one GPU generation.
# Build native SASS for each supported architecture >= sm_61, plus PTX for the lowest supported
# architecture so newer compatible GPUs can JIT it when no native image is present.
mapfile -t SUPPORTED < <(nvcc --list-gpu-arch 2>/dev/null | grep -oE 'compute_[0-9]+' | sort -Vu)
if ((${#SUPPORTED[@]} == 0)); then
    echo "ERROR: could not query CUDA architectures with 'nvcc --list-gpu-arch'." >&2
    exit 2
fi

GPU_FLAGS=()
LOWEST=""
for arch in "${SUPPORTED[@]}"; do
    cc="${arch#compute_}"
    if (( cc < 61 )); then continue; fi
    [[ -n "$LOWEST" ]] || LOWEST="$arch"
    GPU_FLAGS+=("-gencode=arch=${arch},code=sm_${cc}")
done
if [[ -z "$LOWEST" ]]; then
    echo "ERROR: this CUDA Toolkit lists no supported architecture at or above sm_61." >&2
    echo "CUDA 13+ does not target Pascal (sm_61); use CUDA 12.9 for Pascal builds." >&2
    exit 2
fi
GPU_FLAGS+=("-gencode=arch=${LOWEST},code=${LOWEST}")

command -v pkg-config >/dev/null 2>&1 || { echo "ERROR: pkg-config not found." >&2; exit 2; }
pkg-config --exists openssl || { echo "ERROR: OpenSSL development package missing (e.g. libssl-dev)." >&2; exit 2; }

# Keep timestamped backups of any existing binaries before replacing them.
STAMP="$(date +%Y%m%d-%H%M%S)"
[[ ! -e libbgpu.so ]] || cp -a libbgpu.so "libbgpu.so.before-build-${STAMP}"
[[ ! -e bntminer ]] || cp -a bntminer "bntminer.before-build-${STAMP}"

NVCC_RPATH_FLAGS=()
HOST_RPATH_FLAGS=("-Wl,-rpath,\$ORIGIN")
if [[ -n "$CUDA_LIBDIR" ]]; then
    NVCC_RPATH_FLAGS+=("-Xlinker" "-rpath" "-Xlinker" "$CUDA_LIBDIR")
    HOST_RPATH_FLAGS+=("-Wl,-rpath,$CUDA_LIBDIR")
fi

set -x
nvcc -O3 -std=c++17 --cudart=shared -Xcompiler=-fPIC -shared \
    "-DBGPU_SMEM_PAD_WORDS=${SMEM_PAD}" "${GPU_FLAGS[@]}" "${NVCC_RPATH_FLAGS[@]}" \
    gpu/bnt_gpu.cu -o libbgpu.so

g++ -O3 -std=gnu++17 -pthread -Isrc -Igpu \
    src/main.cpp src/tls_conn.cpp -L"$ROOT" -lbgpu \
    $(pkg-config --cflags --libs openssl) \
    "${HOST_RPATH_FLAGS[@]}" -o bntminer
set +x

printf '\nBuild complete (shared-memory pad=%s qwords per 16-word segment). CUDA architectures included:\n' "$SMEM_PAD"
printf '  %s\n' "${GPU_FLAGS[@]}"
printf '\nNext: ./bntminer --test\n'
