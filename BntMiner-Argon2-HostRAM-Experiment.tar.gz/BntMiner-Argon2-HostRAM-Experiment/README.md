# BntMiner — NVIDIA GPU miner for Blocknet (BNT), Argon2id 2 GiB

BntMiner mines [Blocknet](https://blocknetcrypto.com/) (BNT, the privacy coin of `blocknetprivacy`) on NVIDIA GPUs.
The proof of work is **Argon2id v1.3 with 2 GiB of memory, 1 pass, 1 lane**, and the miner talks to the
[bntpool.com](https://bntpool.com/) stratum. The CUDA engine supports NVIDIA GPU architectures for which the installed CUDA Toolkit can generate code; the
Linux build script discovers supported architectures instead of hard-coding a single GPU generation.

- **No dev fee.**
- Open source, Apache-2.0.
- Linux source build emits native code for architectures supported by the installed CUDA Toolkit, plus a PTX fallback.
  Use CUDA 12.9 if you need Pascal (`sm_61`) support; newer toolkits may drop older targets.
- The test suite compares the independent CPU reference with generic Rust `argon2` known-answer vectors (100-byte salts) and checks a separate 92-byte Blocknet-header path against the CPU reference on each selected GPU (`./bntminer --test`).

Not to be confused with the older Blocknet (BLOCK) project or with Bancor (BNT).

Version française : [README.fr.md](README.fr.md).

## Quick start (Windows)

1. Get a Blocknet address with the official wallet
   ([blocknet-gui](https://github.com/blocknetprivacy/blocknet-gui/releases/latest) or the
   [CLI](https://github.com/blocknetprivacy/blocknet/releases/latest)). The node does not need to be synced to mine on
   the pool.
2. Download the zip from [Releases](https://github.com/gacanga/BntMiner/releases) and extract it.
3. Open `bntminer.conf` and replace `YOUR_BLOCKNET_ADDRESS` with your address (a blocknet.id shortname such as
   `@name` also works); `rig1` is the worker name, change it if you like.
4. Double-click `start_bnt.bat`. It restarts the miner 10 s after any exit and logs to `bntminer.log`; close the window
   to stop.

`test.bat` runs the correctness tests on every GPU, `bench.bat` a 120 s H/s benchmark (stop mining first).

Requirements: Windows 10/11 x64, an NVIDIA driver with CUDA 12 support (R525 or newer; R580 is the last branch for
Pascal), **2 GiB of free GPU memory per lane** (an 8 GB card runs 3 lanes). Nothing else needs to be installed.

## Pool

| Pool | URL | Fee |
| --- | --- | --- |
| bntpool.com | `stratum+tcp://bntpool.com:3333` | 2.5 %, PPLNS (6 h window), minimum payment 0.1 BNT, 60 confirmations |

Protocol (JSON lines, the one of the reference miner [seine](https://github.com/zpalmtree/seine); checked against the
live pool):

```
-> {"id":1,"method":"login","params":{"address","worker","protocol_version":2,"capabilities":[...]}}
<- {"id":1,"status":"ok","result":{"protocol_version":2,"capabilities":[...],"required_capabilities":["submit_claimed_hash"]}}
<- {"method":"job","params":{"job_id","header_base","target","difficulty","network_target","height","nonce_start","nonce_end"}}
-> {"id":n,"method":"submit","params":{"job_id","nonce","claimed_hash","miner_version"}}
<- {"id":n,"status":"ok","result":{"accepted":true,"difficulty":d,"status":"provisional","verified":false}}
```

`header_base` is the 92-byte serialized Blocknet PoW header without its separate 8-byte nonce (`4 + 8 + 32 + 32 + 8 + 8`); the pool gives every job its own nonce range. A share
is valid when `Argon2id(password = nonce as u64 little-endian, salt = header_base) <= target` (big-endian bytes). The
pool checks shares asynchronously ("provisional", then "verified").
Your shares and balance: `https://bntpool.com/api/miner/<address>` and `.../balance?include_pending_estimate=true`.

## Configuration

The miner reads `bntminer.conf` next to the executable (or one folder above it), or the file given with
`--config`. Each line is `key = value`; `#` and `;` start a comment. Every key is also a command-line option
(`--key value`); command-line values override the file, and `-o` on the command line replaces the pools of the file.

| Option / key | Default | Meaning |
| --- | --- | --- |
| `-o`, `--pool`, `--url` / `pool` | — | Pool URL, repeatable (failover order). `stratum+tcp://` = plain TCP, `stratum+ssl://` or `stratum+tls://` = TLS |
| `-u`, `--user`, `--wallet`, `--address` / `user` | — | Blocknet address or blocknet.id shortname |
| `--worker`, `--rig` / `worker` | `rig` | Worker name |
| `--gpus`, `--devices`, `-d` / `gpus` | `all` | `all` or a list such as `0,1,2` (PCI bus order, as nvidia-smi) |
| `--lanes` / `lanes` | `0` | Hashes in parallel per GPU (2 GiB each); `0` = as many as the free memory allows |
| `--reserve-mb` / `reserve-mb` | `160` | GPU memory left free (MB) |
| `--argon2-memory` / `argon2-memory` | `gpu` | Argon2 lane placement: `gpu`, `host`, or `hybrid` |
| `--chunk` / `chunk` | `32768` | 1 KiB blocks per kernel launch; up to four launches are synchronized as one batch |
| `--stats` / `stats` | `60` | Seconds between summary lines (minimum 10) |
| `--log` / `log` | — | Append the log to this file |
| `--cafile` / `cafile` | `ca-bundle.crt` next to the exe | CA bundle for TLS pools |
| `--config`, `-c` | `bntminer.conf` | Configuration file |
| `--args-file FILE` | — | Read more arguments from a file (whitespace separated) |
| `--test` | | Correctness tests (CPU, then every selected GPU), exit code 0 when all pass |
| `--bench [s]` | 120 s | H/s benchmark on the selected GPUs |
| `--profile` | | Time of the Argon2i and Argon2d halves of one hash, for 1 .. N lanes |
| `--help`, `-h` | | Usage |

Exit codes used by the restart loop: 2 = bad argument or missing pool/user, 3 = CUDA error, 4 = a GPU run did not
return for 60 s (unstable clocks?), 5 = test/benchmark timeout.

## Historical performance reference (older P104-100 build)

These figures describe an earlier build and are not benchmarks for the current GPU BLAKE2b/H' offload changes.
Retest the current source on the target GPU with `./bntminer --bench` before comparing performance.

NVIDIA P104-100 8 GB, bntpool:

| Setup | H/s |
| --- | --- |
| 1 × P104-100, 1 lane | ≈ 0.48 |
| 1 × P104-100, 3 lanes | ≈ 1.5 (benchmark 1.50, pool 1.48–1.65) |
| 2 × P104-100 | ≈ 3.2 |

A P104-100 draws only about 66 W on this algorithm. With a single lane (one Argon2 chain) per warp the speed is set
by the latency of the compression function, so it grows almost linearly with the number of lanes, which is limited
by the GPU memory (2 GiB each).

## How it works

- PoW (Blocknet core, `crypto-rs/src/pow.rs`): Argon2id v0x13, m = 2,097,152 KiB (2^21 blocks of 1 KiB), t = 1,
  p = 1, 32-byte tag. With one lane and one pass, blocks 0 .. m/2-1 use Argon2i addressing (indices independent of
  the data: a fixed 4 MB table computed once on the host) and blocks m/2 .. m-1 use Argon2d addressing (J1 = low 32
  bits of the previous block). The Argon2i reference-index table is generated once on the GPU at context creation. Reference index of block i: area = i − 1, x = J1²>>32, ref = area − 1 − (area·x>>32).
- The CPU receives raw newline-delimited TCP/TLS data. Each inbound Stratum JSON line is copied to a CUDA parser, which validates/extracts job fields, login replies, notifications, and share replies. CUDA also formats outbound login and submit JSON (including string escaping and the claimed-hash hex string); the CPU retains connection state, request-id/pending-share bookkeeping, logging, and socket send/receive. The job header and targets are installed once in each GPU context. The CPU supplies only the per-device shard number/count at job installation; each GPU owns its nonce cursor and creates nonce values plus per-lane headers in a CUDA batch kernel. The CPU no longer allocates or increments individual nonces and no longer copies a per-nonce header/nonce array to CUDA.
- CUDA computes BLAKE2b H0, expands the first two Argon2 blocks with H'(1024), fills the 2^21 blocks, and computes the final 32-byte H' tag. The GPU also compares the final tag against share and network targets and compacts only matching candidate records. The portable CPU code remains an independent oracle used by correctness tests. Outbound login/submit JSON serialization is also performed by CUDA; Stratum state transitions, request-id/pending-share bookkeeping, and TCP/TLS transport remain CPU-side by design.
- CUDA engine (`gpu/bnt_gpu.cu`): one warp of 32 threads per lane. Every thread keeps 4 of the 128 words of the
  current block in registers (words 2t, 2t+1, 64+2t, 65+2t, read and written as two coalesced 16-byte accesses). The
  BlaMka permutation runs in padded shared memory (row step, then column step, each thread computing one of the 32
  quarter-rounds, diagonals by warp shuffles). In the Argon2i half the reference block of i+1 is loaded while block i
  is computed. Kernel launches of 32,768 blocks keep the Windows display watchdog away. The host queues up to four launches
  on the same stream before synchronizing (at most 131,072 blocks per cancellation check at the default chunk size),
  reducing repeated host-side synchronization overhead without changing block order or the Argon2 result.
- `src/argon_ref.h`: header-only CPU reference (BLAKE2b, H', H0, G, Argon2i address table, full CPU hash), retained for independent correctness tests; the production CUDA path does not call it.

## Building from source (Windows)

Prerequisites, as expected by the scripts:

- CUDA Toolkit **12.9** (`CUDA_PATH_V12_9`, default `C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.9`);
  CUDA 13 cannot target Pascal.
- Visual Studio 2022 (or Build Tools) with the C++ x64 tools (found with `vswhere`).
- MSYS2 in `C:\msys64` with the MINGW64 packages `mingw-w64-x86_64-gcc` and `mingw-w64-x86_64-openssl`.

| Script | What it does |
| --- | --- |
| `build_all.bat` | Builds `dev\bgpu.dll` (nvcc + MSVC, `windows\build_gpu_dll.bat`) and `dev\bntminer.exe` (MSYS2 g++, `windows/build_host.sh`), then runs the tests. `build_all.bat nobuild` = tests only |
| `run_test.bat` | `dev\bntminer.exe --test`, log `logs\test.log`; extra arguments in `run\test_args.txt` |
| `run_bench.bat` | 120 s benchmark of `dev\`, log `logs\bench.log`; `run_bench.bat profile` = Argon2i / Argon2d halves (`logs\profile.log`); extra arguments in `run\bench_args.txt` |
| `deploy.bat` | Copies `dev\` to `bin\`, only if the last `logs\test.log` says `TEST RESULT: ALL OK` |
| `bnt_pool.bat` | Mines with `bin\bntminer.exe` and `bntminer.conf`, restart loop, log `logs\pool.log`; extra arguments in `run\pool_args.txt` |
| `stop_bnt.bat` | Stops the restart loop and `bntminer.exe` |

Build options (environment variables): `BM_NVCC_EXTRA` (or `run\nvcc_extra.txt`) adds nvcc flags, `BM_HOST_ARCH`
replaces `-march=native`. For a portable release build use `set BM_HOST_ARCH=-march=x86-64 -mtune=generic` before
`build_all.bat`. `bgpu.dll` uses the dynamic Microsoft C runtime (`/MD`): the release zip ships its DLLs. The zip
contains `bntminer.exe`, `bgpu.dll`, `cudart64_12.dll`, the VC++ runtime DLLs, `ca-bundle.crt` and the files of
[`dist/`](dist).

## Building from source (Linux)

Run `./build_linux.sh` on a machine with the NVIDIA CUDA Toolkit (`nvcc`), a C++17 compiler, and OpenSSL development headers.
The script builds `libbgpu.so` for every GPU architecture listed by the installed toolkit (from compute capability 6.1 upward),
adds PTX for forward-compatible driver JIT where supported, then links `bntminer` against the local library. The supplied
source archive intentionally omits stale prebuilt binaries; they must be rebuilt for these source changes to take effect.
The script does not claim to benchmark or validate GPU hashes automatically; use `./bntminer --test` on a CUDA-equipped
host after building.

## Tests

`bntminer.exe --test`:

1. CPU reference: BLAKE2b known answer and 16 Argon2id vectors (m = 8, 64, 1024 and 65,536 KiB, 4 nonces each)
   from `src/bnt_vectors.h`;
2. each selected GPU: BLAKE2b known answer, then the same 16 vectors with four kernel launch sizes (1, 5, 333 blocks
   and default) to validate GPU H0, initial H' blocks, fill kernel, final H' tag, prefetch and chunk boundaries;
   then 3 vectors of the real 2 GiB PoW computed in parallel (one lane each).

The vectors come from `tools/bntref` (Rust, `argon2 = "0.5"`, the same call as Blocknet core):

```sh
cd tools/bntref && cargo build --release
for m in 8 64 1024 65536; do ./target/release/bntref $m 4; done > ../../tests/vectors.txt
./target/release/bntref 2097152 3 >> ../../tests/vectors.txt
cd ../.. && python3 tools/gen_vectors.py      # -> src/bnt_vectors.h
```

Linux checks without a GPU:

```sh
g++ -O2 -std=c++17 -Isrc tests/cloud_test.cpp -o cloud_test && ./cloud_test tests/vectors.txt full
g++ -O2 -std=gnu++17 -Isrc -Igpu -o bntminer_stub src/main.cpp src/tls_conn.cpp tests/bg_stub.cpp -lssl -lcrypto -pthread
./bntminer_stub --test
python3 tests/fake_pool.py &  ./bntminer_stub -o stratum+tcp://127.0.0.1:13333 -u TEST --lanes 3
```

`tests/cloud_test.cpp` checks the reference code and a CPU emulation of the kernel's thread mapping (layout, padded
shared memory, shuffles) against the vectors; `tests/bg_stub.cpp` is a CPU stand-in for `bgpu.dll`;
`tests/fake_pool.py` is a minimal bntpool-like server. `tools/nvrtc_check.py` compiles the kernel for sm_61 with NVRTC
and prints the ptxas register / spill report.

## Credits and licence

- CUDA engine, reference code, host code and stratum client: gacanga. The stratum client (`src/json.h`,
  `src/tls_conn.*`) comes from FiloMiner / NullMiner (Apache-2.0).
- The pool protocol follows [seine](https://github.com/zpalmtree/seine) (BSD-3-Clause); no seine code is included.
- The Rust [argon2](https://github.com/RustCrypto/password-hashes) crate and
  [Blocknet core](https://github.com/blocknetprivacy/core) were used as correctness references for the tests only;
  they are not linked into the miner.

Apache License 2.0, see [LICENSE](LICENSE) and [NOTICE](NOTICE). No warranty: you mine at your own risk, and
mining uses electricity. Blocknet describes itself as experimental; it plans a network upgrade (around 2027-02-16)
with a different proof of work, after which this miner will need an update.


GPU share filtering, Stratum JSON parsing and nonce allocation
--------------------------------------------------------------
The final CUDA kernel compares each Argon2id tag against the share and network targets using big-endian lexicographic `<=`, then compacts only matching nonce/hash/flag records. The host does not receive full batches of tags. Incoming Stratum JSON is copied from the CPU socket buffer to a CUDA kernel; that kernel extracts the job, target, nonce interval, login capability fields, notifications and submit replies into a fixed-size result. CUDA also formats outbound login/submit JSON. The CPU still owns TCP/TLS, connection/reconnect logic, request-id/pending-share bookkeeping, job publication, logging and the final socket send/receive calls. Every GPU is assigned an interleaved, disjoint nonce shard when a job is installed; each device then reserves its own batches from a device-side cursor and creates every nonce/header on the GPU. There is no CPU per-nonce atomic allocation and no per-nonce host-to-device header/nonce array.

`./bntminer --test` now also exercises the CUDA Stratum parser, login/submit JSON formatter, and GPU nonce allocator/shard logic using a small-memory test context. `tests/run_linux_checks.sh` checks the host integration and API contract using a CPU stand-in only; that is not proof of CUDA behavior. Run `./build_linux.sh` and `./bntminer --test` on the target CUDA server before mining. JSON parsing on a GPU kernel is an offload choice, not necessarily faster than CPU parsing for small, infrequent pool messages; benchmark before assuming a speed benefit.


## CUDA kernel experiment v0.1.3 (scatter-store rounds)

This candidate keeps the canonical Blocknet PoW parameters unchanged (Argon2id v1.3, 2 GiB, t=1, p=1). In the row/column BlaMka helper, it removes the three inverse 64-bit warp shuffles after the diagonal G. Instead, each lane writes the `b`, `c`, and `d` outputs directly to the shared-memory slots belonging to logical lanes k+1, k+2, and k+3. The shared-memory barrier between the row and column steps remains in place. This is a performance experiment, not an assumed win: scattered stores retain the same address set but may have different scheduling/bank behavior on a target GPU.

The added `tests/round4_scatter_test.cpp` compares the inverse-shuffle and scatter-store round results for 100,000 deterministic randomized BlaMka test vectors and checks that the b/c/d store address sets are preserved for both `pad=2` and `pad=4`. `bash tests/run_linux_checks.sh` passes in the preparation environment, including the 16 CPU Argon2id vectors and host stub checks. There is no `nvcc` or NVIDIA GPU in the preparation environment, so the CUDA translation unit has not been compiled here and no GPU hash-rate gain is claimed. On the target GPU, run `./build_linux.sh`, `./bntminer --test`, then compare `./bntminer --bench 120` against the same machine/version/settings. Keep the previous source/binaries until the CUDA vector test passes.

## CUDA kernel micro-optimization (v0.1.1-cuda-kernel-opt)

This source adds a fixed-rotation BlaMka fast path for the Argon2 compression hot loop. The 64-bit right rotations by 16, 24, and 63 bits are computed from 32-bit halves via CUDA funnel-shift intrinsics. BlaMka's `(uint32)x * (uint32)y` term is explicitly lowered with PTX `mul.wide.u32`. These changes do not change Argon2id parameters, byte ordering, memory layout, target comparisons, or protocol.

Version 0.1.2 rolls back the split-32-bit funnel-shift rotates and explicit PTX multiply from v0.1.1 because the user measured lower throughput on Tesla P4. The hot fill loop reuses `qa/qb` to hold `R = previous XOR reference`, removing the separate live `ra/rb` vectors (four live 64-bit values per thread). The default shared-memory padding remains the known-good pad=4. An optional pad=2 layout can be compiled for A/B testing via `BGPU_SMEM_PAD_WORDS=2 ./build_linux.sh`; pad=4 is the default. `tests/smem_layout_test.cpp` checks address bounds, uniqueness and 16-byte vector alignment for both layouts, but does not establish which layout is faster. Run `bash tests/run_linux_checks.sh` for CPU-side checks, then build and test on the actual CUDA machine with `./build_linux.sh`, `./bntminer --test`, and `./bntminer --bench 120`. This packaging environment has no `nvcc` or NVIDIA GPU, so no CUDA compile or H/s gain is claimed here. Compare bench results on the same GPU, same lane count, same chunk size, same clocks/power limit, with the prior `bntminer` stopped.


## CUDA kernel experiment v0.1.2 (2026-10-28)

This variant reverses the v0.1.1 fast-rotate/inline-multiply experiment (measured slower on Tesla P4), and reduces register live ranges in `fill_kernel` by reusing `qa/qb` for the `R = previous XOR reference` vectors instead of retaining separate `ra/rb`. The default shared-memory layout remains pad=4 to keep the known-good mapping. A pad=2 alternative is available for controlled A/B performance testing:

```bash
# Known-good pad=4 default
./build_linux.sh
./bntminer --test
./bntminer --bench 120

# Optional alternate padding layout, then test/benchmark again
BGPU_SMEM_PAD_WORDS=2 ./build_linux.sh
./bntminer --test
./bntminer --bench 120

# Return to default pad=4
./build_linux.sh
```

Use the same GPU, lanes and chunk settings, stop any competing miner between tests, and compare only after each `--test` passes. The pad=2 option is an experiment, not an assumed optimization. This package was prepared without `nvcc`/a CUDA GPU in the build environment; no CUDA-build or hash-rate improvement is claimed until tested on the target GPU.


## Experimental Argon2 host-RAM mode

The default remains `argon2-memory = gpu`: every 2 GiB Argon2 lane is allocated in VRAM with `cudaMalloc`.

For an experiment, set `argon2-memory = host` and an explicit `lanes = N`. Each full lane is allocated
with `cudaHostAllocMapped | cudaHostAllocPortable`; CUDA kernels access the mapped device pointer while
the physical 2 GiB backing store remains page-locked system RAM. This is **not** Unified Memory and it
does not migrate the lane into VRAM. All Argon2 arithmetic still executes on the GPU.

`argon2-memory = hybrid` allocates as many requested lanes as fit in VRAM (respecting `reserve-mb`),
then allocates remaining lanes in mapped pinned system RAM. For `host` and `hybrid`, set an explicit
`lanes` value; auto-lane mode is rejected to avoid unexpectedly pinning large amounts of system RAM.

Warning: mapped host RAM is accessed over PCIe. Argon2d uses dependent random memory references, so
`host` mode can be substantially slower than VRAM and can consume large amounts of non-swappable
pinned RAM. Start with one lane, compare throughput, and stop the miner if the system becomes memory
pressured. The watchdog allowance is extended for host/hybrid mode because a PCIe-backed pass can
be much longer than a VRAM pass. A successful build does not prove the GPU/driver/platform can map a
2 GiB allocation; the CUDA runtime reports any mapping/allocation failure at startup.
