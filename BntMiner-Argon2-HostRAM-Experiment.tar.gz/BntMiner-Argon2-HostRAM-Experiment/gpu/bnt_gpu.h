// bnt_gpu.h - C API of bgpu.dll, the CUDA Argon2id engine of BntMiner (Blocknet PoW).
// One "lane" = one hash in progress = m_blocks KiB of GPU memory (2 GiB for Blocknet),
// computed by one warp of 32 threads.  All lanes of a device advance together.
#pragma once
#include <stdint.h>

#ifdef _WIN32
#ifdef BGPU_BUILD
#define BG_API extern "C" __declspec(dllexport)
#else
#define BG_API extern "C" __declspec(dllimport)
#endif
#else
#define BG_API extern "C"
#endif

#define BG_BLOCK_WORDS 128

// Argon2 lane storage placement: GPU VRAM, mapped pinned system RAM, or VRAM-first hybrid.
#define BG_MEMORY_GPU 0
#define BG_MEMORY_HOST 1
#define BG_MEMORY_HYBRID 2

// Compact GPU-produced results: only hashes that meet the pool share target or
// network block target are copied back to the host. The CPU still owns network I/O.
#define BG_CANDIDATE_SHARE 1u
#define BG_CANDIDATE_BLOCK 2u

// GPU-decoded Stratum JSON message. TCP/TLS framing and socket I/O remain on the CPU;
// the complete inbound JSON line is parsed and the relevant fields are extracted on GPU.
#define BG_STRATUM_OTHER 0u
#define BG_STRATUM_JOB 1u
#define BG_STRATUM_NOTIFICATION 2u
#define BG_STRATUM_RESPONSE 3u
#define BG_STRATUM_FORMAT_CAPACITY 2048u
typedef struct BgStratumMessage {
    uint32_t valid;
    uint32_t type;
    int64_t id;
    uint32_t has_id;
    uint32_t has_error;
    uint32_t status_ok;
    uint32_t accepted;
    uint32_t has_accepted;
    uint32_t protocol_version;
    uint32_t has_protocol_version;
    uint32_t can_submit_claimed_hash;
    uint32_t header_len;
    uint32_t has_target;
    uint32_t has_network_target;
    uint32_t has_height;
    uint32_t has_difficulty;
    uint32_t has_nonce_start;
    uint32_t has_nonce_end;
    uint64_t height;
    uint64_t difficulty;
    uint64_t nonce_start;
    uint64_t nonce_end;
    uint8_t header[100];
    uint8_t target[32];
    uint8_t network_target[32];
    char method[32];
    char status[16];
    char job_id[256];
    char message[512];
    char kind[64];
    char error[128];
} BgStratumMessage;

// GPU JSON formatter input. Only fixed-size POD data crosses the API; TCP/TLS
// framing and the actual send operation remain on the CPU.
typedef struct BgStratumFormatInput {
    uint32_t kind;                 // 1 = login, 2 = submit
    uint32_t include_claimed_hash;
    uint64_t id;
    uint64_t nonce;
    uint8_t claimed_hash[32];
    char address[256];
    char worker[128];
    char job_id[256];
    char miner_version[96];
} BgStratumFormatInput;

typedef struct BgShareCandidate {
    uint64_t nonce;
    uint32_t lane_index;
    uint32_t flags;       // BG_CANDIDATE_SHARE and/or BG_CANDIDATE_BLOCK
    uint8_t hash[32];
} BgShareCandidate;

BG_API int bg_device_count(void);
// m_blocks: lane size in 1 KiB blocks (Blocknet: 2097152), multiple of 8.
// lanes: wanted lanes, 0 = as many as the free memory allows (minus reserve_mb).
// chunk: blocks per kernel launch (0 = default).
BG_API void* bg_create(int device, uint32_t m_blocks, int lanes, int reserve_mb, int chunk);
// Extended constructor. For HOST/HYBRID, lanes must be explicit (> 0).
// HOST stores the complete 2 GiB lane(s) in mapped pinned system RAM accessed by CUDA over PCIe.
// HYBRID allocates as many lanes as possible in VRAM, then places remaining lanes in mapped RAM.
BG_API void* bg_create_memory(int device, uint32_t m_blocks, int lanes, int reserve_mb, int chunk, int memory_mode);
BG_API int bg_gpu_lane_count(void* h);
BG_API int bg_host_lane_count(void* h);
BG_API double bg_host_memory_used(void* h);
BG_API const char* bg_memory_mode_name(void* h);
BG_API void bg_destroy(void* h);
BG_API int bg_lanes(void* h);
BG_API const char* bg_name(void* h);
BG_API int bg_compute_capability(void* h);   // 61 for sm_61
BG_API int bg_sm_count(void* h);
BG_API double bg_memory_total(void* h);      // bytes
BG_API double bg_memory_used(void* h);       // bytes allocated by the engine
BG_API const char* bg_last_error(void* h);   // h may be null (create errors)
BG_API const char* bg_kernel_info(void);
// One hash per lane (nlanes <= bg_lanes):
//   init: nlanes x 2 blocks (blocks 0 and 1 of every lane, 256 words per lane)
//   last: nlanes x 1 block (last block of every lane, 128 words per lane)
//   abort: polled between synchronized launch batches; if *abort != 0 the run stops and 1 is returned.
// Returns 0 on success, 1 if aborted, -1 on a CUDA error (bg_last_error).
BG_API int bg_hash(void* h, const uint64_t* init, uint64_t* last, int nlanes, volatile int* abort, double* ms);
// Full hash path with a tightly-packed, per-lane salt/header and one nonce per lane.
// Blocknet production header_base is 92 bytes; generic self-test vectors may use up to 100.
// GPU computes BLAKE2b H0, Argon2 initial blocks, memory fill, and the final 32-byte tag.
BG_API int bg_hash_full(void* h, const uint8_t* headers, uint32_t header_bytes,
                        const uint64_t* nonces, uint8_t* tags, int nlanes,
                        volatile int* abort, double* ms);
// Same full hash path, but the GPU also checks each final tag against the
// pool share target and network target. targets are 32-byte big-endian byte strings.
// share_flags[l] = tag <= share_target; block_flags[l] = nonzero network_target && tag <= network_target.
// CPU still owns Stratum/TLS and sends only the candidates flagged by the GPU.
BG_API int bg_hash_full_checked(void* h, const uint8_t* headers, uint32_t header_bytes,
                                const uint64_t* nonces,
                                const uint8_t share_target[32], const uint8_t network_target[32],
                                uint8_t* tags, uint8_t* share_flags, uint8_t* block_flags,
                                int nlanes, volatile int* abort, double* ms);
// Compact candidate API for production. CUDA compares the final tag against both
// targets, compacts only share/block candidates on-device, and copies only those
// records to host memory. candidate_capacity must be >= nlanes; candidate_count is
// written by the API. Network/TLS/Stratum submission remains a host responsibility.
BG_API int bg_hash_full_candidates(void* h, const uint8_t* headers, uint32_t header_bytes,
                                   const uint64_t* nonces,
                                   const uint8_t share_target[32], const uint8_t network_target[32],
                                   BgShareCandidate* candidates, uint32_t candidate_capacity,
                                   uint32_t* candidate_count, int nlanes,
                                   volatile int* abort, double* ms);

// Parse one inbound newline-delimited Stratum JSON message on the selected GPU.
// The caller still owns TCP/TLS framing, protocol state, and outbound serialization.
BG_API int bg_parse_stratum(void* h, const char* json_line, uint32_t line_bytes, BgStratumMessage* out);
// Format outbound login/submit JSON on the selected GPU. The returned buffer
// contains JSON bytes without the newline; TlsConn::send_line adds framing.
BG_API int bg_format_stratum_login(void* h, const char* address, const char* worker,
                                   char* out, uint32_t out_capacity, uint32_t* out_bytes);
BG_API int bg_format_stratum_submit(void* h, uint64_t id, const char* job_id, uint64_t nonce,
                                    const uint8_t claimed_hash[32], uint32_t include_claimed_hash,
                                    const char* miner_version, char* out, uint32_t out_capacity,
                                    uint32_t* out_bytes);

// Install a new mining job on the GPU. Nonce space is split into disjoint interleaved
// shards: shard_index in [0, shard_count), and then generated/allocated on the GPU.
BG_API int bg_set_gpu_job(void* h, const uint8_t* header, uint32_t header_bytes,
                          const uint8_t share_target[32], const uint8_t network_target[32],
                          uint64_t nonce_start, uint64_t nonce_end,
                          uint64_t shard_index, uint64_t shard_count);
// Generate the next nonce batch on GPU, hash it and return only share/block candidates.
// hashes_done reports how many valid nonce values were actually generated.
BG_API int bg_hash_next_candidates(void* h, BgShareCandidate* candidates, uint32_t candidate_capacity,
                                   uint32_t* candidate_count, uint32_t* hashes_done, int nlanes,
                                   volatile int* abort, double* ms);

// Compute BLAKE2b-512("abc") on the selected GPU for the GPU self-test.
BG_API int bg_test_blake2b(int device, uint8_t out64[64]);
// Same with a time limit per kernel launch reported (profiling): ms_kernel = summed GPU time.
BG_API int bg_profile(void* h, int nlanes, double* ms_i_part, double* ms_d_part);
