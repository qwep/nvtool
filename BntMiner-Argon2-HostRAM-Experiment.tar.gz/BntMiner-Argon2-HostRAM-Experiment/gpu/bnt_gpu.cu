// bnt_gpu.cu - CUDA Argon2id engine of BntMiner (Blocknet PoW: Argon2id v0x13, m = 2 GiB,
// t = 1, p = 1).  Target: NVIDIA GPUs supported by the installed CUDA Toolkit.  Apache-2.0.
//
// One lane (one hash) = one warp of 32 threads = m_blocks KiB of GPU memory.  The 1 KiB
// blocks are filled in order: block i = G(block i-1, block ref(i)).  Every thread keeps 4 of
// the 128 words of the current block in registers ("g layout": words 2t, 2t+1, 64+2t, 65+2t,
// loaded and stored as two 16-byte accesses, coalesced over the warp).  The BlaMka permutation
// works in shared memory (padded, 2 transactions per access): row step, then column step,
// each thread computing one of the 32 quarter-rounds, diagonals done with warp shuffles.
//
// Argon2i part (first half): reference indices from a fixed table (GPU-computed at startup), the
// reference block of i+1 is loaded while block i is computed.  Argon2d part: the index comes
// from the first word of block i-1, so the load latency cannot be hidden inside a lane.
// Each thread only reads words it wrote itself (same g layout), so no extra memory fence is
// needed between iterations.
#define BGPU_BUILD
#include "bnt_gpu.h"
#include <cuda_runtime.h>
#include <stdio.h>
#include <algorithm>
#include <string>
#include <vector>
#include <chrono>
#include <mutex>

#define FULL_MASK 0xffffffffu

// Shared-memory padding can be tested per GPU. Four qwords (the original layout) is
// the default; two qwords is an optional A/B candidate. Both preserve 16-byte alignment
// for the ulonglong2 loads/stores used by the warp.
#ifndef BGPU_SMEM_PAD_WORDS
#define BGPU_SMEM_PAD_WORDS 4
#endif
#if BGPU_SMEM_PAD_WORDS != 2 && BGPU_SMEM_PAD_WORDS != 4
#error "BGPU_SMEM_PAD_WORDS must be 2 or 4"
#endif
#define SP(w) ((w) + (((w) >> 4) * BGPU_SMEM_PAD_WORDS))
#define SMEM_WORDS (128 + 8 * BGPU_SMEM_PAD_WORDS)
#define BG_STR2(x) #x
#define BG_STR(x) BG_STR2(x)

// Keep the original 64-bit rotate and BlaMka expressions. The split-32-bit funnel-shift
// variant benchmarked about 5% slower on the Tesla P4, so this build rolls it back.
__device__ __forceinline__ uint64_t d_rotr(uint64_t x, int n) { return (x >> n) | (x << (64 - n)); }
__device__ __forceinline__ uint64_t d_rotr32(uint64_t x)
{
    return ((uint64_t)(uint32_t)x << 32) | (x >> 32);
}
__device__ __forceinline__ uint64_t d_fBlaMka(uint64_t x, uint64_t y)
{
    uint64_t m = (uint64_t)(uint32_t)x * (uint64_t)(uint32_t)y;
    return x + y + 2 * m;
}
__device__ __forceinline__ void d_G(uint64_t& a, uint64_t& b, uint64_t& c, uint64_t& d)
{
    a = d_fBlaMka(a, b);
    d = d_rotr32(d ^ a);
    c = d_fBlaMka(c, d);
    b = d_rotr(b ^ c, 24);
    a = d_fBlaMka(a, b);
    d = d_rotr(d ^ a, 16);
    c = d_fBlaMka(c, d);
    b = d_rotr(b ^ c, 63);
}

// Scalar Argon2 compression used only while constructing the fixed Argon2i
// address table. It computes compress(0, ref) = P(ref) XOR ref. The table is
// generated once on the GPU during context creation; it is not part of the
// per-nonce hot loop.
__device__ __forceinline__ void d_argon_round16(uint64_t* v)
{
    d_G(v[0], v[4], v[8], v[12]);
    d_G(v[1], v[5], v[9], v[13]);
    d_G(v[2], v[6], v[10], v[14]);
    d_G(v[3], v[7], v[11], v[15]);
    d_G(v[0], v[5], v[10], v[15]);
    d_G(v[1], v[6], v[11], v[12]);
    d_G(v[2], v[7], v[8], v[13]);
    d_G(v[3], v[4], v[9], v[14]);
}

__device__ void d_argon_compress_zero_inplace(uint64_t* block)
{
    uint64_t r[128];
    for (int i = 0; i < 128; ++i) r[i] = block[i];
    for (int row = 0; row < 8; ++row) d_argon_round16(block + 16 * row);
    for (int col = 0; col < 8; ++col) {
        uint64_t v[16];
        for (int row = 0; row < 8; ++row) {
            v[2 * row] = block[16 * row + 2 * col];
            v[2 * row + 1] = block[16 * row + 2 * col + 1];
        }
        d_argon_round16(v);
        for (int row = 0; row < 8; ++row) {
            block[16 * row + 2 * col] = v[2 * row];
            block[16 * row + 2 * col + 1] = v[2 * row + 1];
        }
    }
    for (int i = 0; i < 128; ++i) block[i] ^= r[i];
}

// One Argon2/BlaMka row/column round on a group of four threads.
// After the diagonal G, b/c/d still belong to source lanes k+1/k+2/k+3.
// Instead of shuffling those 64-bit values back (three more warp shuffles), the
// caller scatters them to the shared-memory slots owned by those destination lanes.
// This preserves the exact permutation while removing 3 x 64-bit shuffle operations
// from each row and column round. Validate on the target GPU before benchmarking.
__device__ __forceinline__ void d_round4_scatter(uint64_t& a, uint64_t& b, uint64_t& c, uint64_t& d, int gbase, int k)
{
    d_G(a, b, c, d);
    b = __shfl_sync(FULL_MASK, b, gbase | ((k + 1) & 3));
    c = __shfl_sync(FULL_MASK, c, gbase | ((k + 2) & 3));
    d = __shfl_sync(FULL_MASK, d, gbase | ((k + 3) & 3));
    d_G(a, b, c, d);
}

__device__ __forceinline__ uint32_t d_ref_index(uint32_t i, uint32_t j1)
{
    uint32_t area = i - 1;
    uint32_t x = __umulhi(j1, j1);
    uint32_t y = __umulhi(area, x);
    return area - 1 - y;
}

// Build the fixed Argon2i reference-index table directly on the selected GPU.
// One CUDA block generates one 128-address block. This is startup-only work;
// the hot Argon2id fill kernel consumes the resulting table from device memory.
__global__ void build_ref_table_kernel(uint32_t* __restrict__ table, uint32_t m_blocks,
                                       uint32_t groups_per_slice)
{
    const uint32_t slice = blockIdx.x / groups_per_slice;
    const uint32_t group = blockIdx.x - slice * groups_per_slice;
    if (slice >= 2) return;

    uint64_t input[128];
    for (int i = 0; i < 128; ++i) input[i] = 0;
    input[2] = slice;
    input[3] = m_blocks;
    input[4] = 1; // passes
    input[5] = 2; // Argon2i
    input[6] = group + 1; // address counter restarts at each slice

    d_argon_compress_zero_inplace(input);
    d_argon_compress_zero_inplace(input);

    const uint32_t seg = m_blocks / 4;
    uint32_t begin = group * 128;
    uint32_t end = begin + 128;
    if (end > seg) end = seg;
    if (slice == 0 && begin < 2) begin = 2; // first slice starts after initial blocks 0 and 1
    for (uint32_t idx = begin; idx < end; ++idx) {
        const uint32_t i = slice * seg + idx;
        table[i] = d_ref_index(i, (uint32_t)input[idx & 127u]);
    }
}

__device__ __forceinline__ ulonglong2 xor2(ulonglong2 a, ulonglong2 b)
{
    ulonglong2 r;
    r.x = a.x ^ b.x;
    r.y = a.y ^ b.y;
    return r;
}

// Device BLAKE2b used for Argon2 H0, H' expansion of the first two blocks,
// and final 32-byte tag. The CPU implementation remains in argon_ref.h as an
// independent test oracle; normal mining uses this GPU implementation.
__device__ __constant__ uint64_t D_B2_IV[8] = {
    0x6a09e667f3bcc908ULL, 0xbb67ae8584caa73bULL,
    0x3c6ef372fe94f82bULL, 0xa54ff53a5f1d36f1ULL,
    0x510e527fade682d1ULL, 0x9b05688c2b3e6c1fULL,
    0x1f83d9abfb41bd6bULL, 0x5be0cd19137e2179ULL
};
__device__ __constant__ uint8_t D_B2_SIGMA[12][16] = {
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3},
    {11,8,12,0,5,2,15,13,10,14,3,6,7,1,9,4},
    {7,9,3,1,13,12,11,14,2,6,5,10,4,0,15,8},
    {9,0,5,7,2,4,10,15,14,1,11,12,6,8,3,13},
    {2,12,6,10,0,11,8,3,4,13,7,5,15,14,1,9},
    {12,5,1,15,14,13,4,10,0,7,6,3,9,2,8,11},
    {13,11,7,14,12,1,3,9,5,0,15,4,8,6,2,10},
    {6,15,14,9,11,3,0,8,12,2,13,7,1,4,10,5},
    {10,2,8,4,7,6,1,5,15,11,9,14,3,12,13,0},
    {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15},
    {14,10,4,8,9,15,13,6,1,12,0,2,11,7,5,3}
};

__device__ __forceinline__ uint64_t d_b2_load64(const uint8_t* p)
{
    uint64_t v = 0;
#pragma unroll
    for (int i = 0; i < 8; ++i) v |= (uint64_t)p[i] << (8 * i);
    return v;
}
__device__ __forceinline__ void d_b2_store32(uint8_t* p, uint32_t v)
{
#pragma unroll
    for (int i = 0; i < 4; ++i) p[i] = (uint8_t)(v >> (8 * i));
}
__device__ __forceinline__ void d_b2_store64(uint8_t* p, uint64_t v)
{
#pragma unroll
    for (int i = 0; i < 8; ++i) p[i] = (uint8_t)(v >> (8 * i));
}
__device__ __forceinline__ uint64_t d_b2_rotr(uint64_t x, int n)
{
    return (x >> n) | (x << (64 - n));
}
__device__ __forceinline__ void d_b2_mix(uint64_t& a, uint64_t& b, uint64_t& c, uint64_t& d,
                                         uint64_t x, uint64_t y)
{
    a = a + b + x;
    d = d_b2_rotr(d ^ a, 32);
    c = c + d;
    b = d_b2_rotr(b ^ c, 24);
    a = a + b + y;
    d = d_b2_rotr(d ^ a, 16);
    c = c + d;
    b = d_b2_rotr(b ^ c, 63);
}

__device__ __forceinline__ void d_b2_compress(uint64_t h[8], const uint8_t block[128],
                                               uint64_t t0, uint64_t t1, bool last)
{
    uint64_t m[16], v[16];
#pragma unroll
    for (int i = 0; i < 16; ++i) m[i] = d_b2_load64(block + 8 * i);
#pragma unroll
    for (int i = 0; i < 8; ++i) { v[i] = h[i]; v[i + 8] = D_B2_IV[i]; }
    v[12] ^= t0;
    v[13] ^= t1;
    if (last) v[14] = ~v[14];
#pragma unroll 1
    for (int r = 0; r < 12; ++r) {
        d_b2_mix(v[0], v[4], v[8], v[12], m[D_B2_SIGMA[r][0]], m[D_B2_SIGMA[r][1]]);
        d_b2_mix(v[1], v[5], v[9], v[13], m[D_B2_SIGMA[r][2]], m[D_B2_SIGMA[r][3]]);
        d_b2_mix(v[2], v[6], v[10], v[14], m[D_B2_SIGMA[r][4]], m[D_B2_SIGMA[r][5]]);
        d_b2_mix(v[3], v[7], v[11], v[15], m[D_B2_SIGMA[r][6]], m[D_B2_SIGMA[r][7]]);
        d_b2_mix(v[0], v[5], v[10], v[15], m[D_B2_SIGMA[r][8]], m[D_B2_SIGMA[r][9]]);
        d_b2_mix(v[1], v[6], v[11], v[12], m[D_B2_SIGMA[r][10]], m[D_B2_SIGMA[r][11]]);
        d_b2_mix(v[2], v[7], v[8], v[13], m[D_B2_SIGMA[r][12]], m[D_B2_SIGMA[r][13]]);
        d_b2_mix(v[3], v[4], v[9], v[14], m[D_B2_SIGMA[r][14]], m[D_B2_SIGMA[r][15]]);
    }
#pragma unroll
    for (int i = 0; i < 8; ++i) h[i] ^= v[i] ^ v[i + 8];
}

__device__ void d_blake2b(uint8_t* out, uint32_t outlen, const uint8_t* in, size_t inlen)
{
    uint64_t h[8];
#pragma unroll
    for (int i = 0; i < 8; ++i) h[i] = D_B2_IV[i];
    h[0] ^= 0x01010000ULL ^ (uint64_t)outlen;
    size_t off = 0;
    uint64_t t0 = 0, t1 = 0;
    while (inlen - off > 128) {
        t0 += 128;
        d_b2_compress(h, in + off, t0, t1, false);
        off += 128;
    }
    uint8_t tail[128];
    size_t rem = inlen - off;
#pragma unroll
    for (int i = 0; i < 128; ++i) tail[i] = (size_t)i < rem ? in[off + i] : 0;
    t0 += rem;
    d_b2_compress(h, tail, t0, t1, true);
    for (uint32_t i = 0; i < outlen; ++i)
        out[i] = (uint8_t)(h[i >> 3] >> (8 * (i & 7)));
}

// Argon2 H'(1024, input[72]): stream the expansion directly to the lane block
// to avoid a 1 KiB local output array. out is a byte view of a 1 KiB block.
__device__ void d_hprime1024(const uint8_t input[72], uint8_t* out)
{
    uint8_t first[76], v[64], next[64], last[64];
    d_b2_store32(first, 1024);
#pragma unroll
    for (int i = 0; i < 72; ++i) first[4 + i] = input[i];
    d_blake2b(v, 64, first, 76);
#pragma unroll
    for (int i = 0; i < 32; ++i) out[i] = v[i];
    uint32_t remain = 1024 - 32;
    uint32_t offset = 32;
    while (remain > 64) {
        d_blake2b(next, 64, v, 64);
#pragma unroll
        for (int i = 0; i < 64; ++i) v[i] = next[i];
#pragma unroll
        for (int i = 0; i < 32; ++i) out[offset + i] = v[i];
        offset += 32;
        remain -= 32;
    }
    d_blake2b(last, remain, v, 64);
#pragma unroll
    for (uint32_t i = 0; i < remain; ++i) out[offset + i] = last[i];
}

__device__ void d_hprime32_from_words(uint8_t out[32], const uint64_t* words)
{
    uint8_t input[1028];
    d_b2_store32(input, 32);
    for (int i = 0; i < 128; ++i) d_b2_store64(input + 4 + 8 * i, words[i]);
    d_blake2b(out, 32, input, sizeof(input));
}

// Targets arrive as the same 32-byte big-endian values compared by the host
// reference (memcmp(hash, target, 32) <= 0). Keep the exact byte ordering.
__device__ __forceinline__ bool d_hash_le_target(const uint8_t hash[32], const uint8_t target[32])
{
    for (int i = 0; i < 32; ++i) {
        const uint8_t h = hash[i], t = target[i];
        if (h < t) return true;
        if (h > t) return false;
    }
    return true;
}

__device__ __forceinline__ bool d_target_nonzero(const uint8_t target[32])
{
    for (int i = 0; i < 32; ++i) if (target[i] != 0) return true;
    return false;
}

__global__ void b2b_known_answer_kernel(uint8_t* out)
{
    if (threadIdx.x || blockIdx.x) return;
    const uint8_t abc[3] = {'a', 'b', 'c'};
    d_blake2b(out, 64, abc, 3);
}

// Called by the first fill_kernel launch. Threads 0 and 1 independently compute
// blocks 0 and 1; each calculates H0 and one H'(1024) expansion.
__device__ void d_generate_initial_block(const uint8_t* header, uint32_t header_bytes,
                                         uint64_t nonce, uint32_t m_blocks,
                                         uint32_t block_index, uint8_t* out)
{
    uint8_t h0_input[148], h0[64], hprime_input[72];
    size_t p = 0;
    d_b2_store32(h0_input + p, 1); p += 4;       // lanes
    d_b2_store32(h0_input + p, 32); p += 4;      // tag length
    d_b2_store32(h0_input + p, m_blocks); p += 4;
    d_b2_store32(h0_input + p, 1); p += 4;       // passes
    d_b2_store32(h0_input + p, 0x13); p += 4;    // version
    d_b2_store32(h0_input + p, 2); p += 4;       // Argon2id
    d_b2_store32(h0_input + p, 8); p += 4;       // password length
    d_b2_store64(h0_input + p, nonce); p += 8;
    d_b2_store32(h0_input + p, header_bytes); p += 4; // salt length
    for (uint32_t i = 0; i < header_bytes; ++i) h0_input[p + i] = header[i];
    p += header_bytes;
    d_b2_store32(h0_input + p, 0); p += 4;       // secret length
    d_b2_store32(h0_input + p, 0); p += 4;       // associated data length
    d_blake2b(h0, 64, h0_input, p);
#pragma unroll
    for (int i = 0; i < 64; ++i) hprime_input[i] = h0[i];
    d_b2_store32(hprime_input + 64, block_index);
    d_b2_store32(hprime_input + 68, 0);          // lane index
    d_hprime1024(hprime_input, out);
}

// blocks [start, end) of every lane (blockIdx.x = lane); start >= 2
__global__ void __launch_bounds__(32) fill_kernel(uint64_t* const* __restrict__ lanes, const uint32_t* __restrict__ table, uint32_t half,
                                                  uint32_t start, uint32_t end,
                                                  const uint8_t* __restrict__ init_headers,
                                                  const uint64_t* __restrict__ init_nonces,
                                                  uint32_t header_bytes,
                                                  uint8_t* __restrict__ out_tags,
                                                  const uint8_t* __restrict__ share_target,
                                                  const uint8_t* __restrict__ network_target,
                                                  uint8_t* __restrict__ out_share_flags,
                                                  uint8_t* __restrict__ out_block_flags,
                                                  BgShareCandidate* __restrict__ out_candidates,
                                                  uint32_t* __restrict__ out_candidate_count,
                                                  uint32_t candidate_capacity,
                                                  const uint8_t* __restrict__ valid_flags)
{
    if (valid_flags && valid_flags[blockIdx.x] == 0) return;
    __shared__ __align__(16) uint64_t s[SMEM_WORDS];
    const int t = threadIdx.x;
    ulonglong2* m2 = (ulonglong2*)lanes[blockIdx.x];
    // The first fill launch also builds Argon2 blocks 0 and 1 on-device. Threads 0 and 1
    // independently compute H0 and one H'(1024) block; the warp barrier makes them visible
    // before every thread loads block 1 as its initial predecessor.
    if (start == 2 && init_headers && init_nonces) {
        if (t < 2) {
            const uint8_t* header = init_headers + (size_t)blockIdx.x * header_bytes;
            uint8_t* dst = (uint8_t*)(m2 + (size_t)t * 64);
            d_generate_initial_block(header, header_bytes, init_nonces[blockIdx.x], half * 2, (uint32_t)t, dst);
        }
        __syncwarp(FULL_MASK);
    }
    const int row = t >> 2, k = t & 3, gbase = t & ~3;
    const int rw = 16 * row + k;                          // row step: words rw + 4j
    const int cw = 2 * row + (k & 1) + 16 * (k >> 1);     // column step: words cw + 32j
    const int sr0 = SP(rw), sr1 = SP(rw + 4), sr2 = SP(rw + 8), sr3 = SP(rw + 12);
    const int sc0 = SP(cw), sc1 = SP(cw + 32), sc2 = SP(cw + 64), sc3 = SP(cw + 96);
    // Scatter destinations undo the lane rotations by redirecting stores rather than
    // issuing three inverse shuffles inside d_round4_scatter(). The lane rotation is
    // confined to each four-thread group, including its wraparound at k == 3.
    const int kr1 = (k + 1) & 3, kr2 = (k + 2) & 3, kr3 = (k + 3) & 3;
    const int sr1dst = SP(16 * row + kr1 + 4);
    const int sr2dst = SP(16 * row + kr2 + 8);
    const int sr3dst = SP(16 * row + kr3 + 12);
    const int cw1 = 2 * row + (kr1 & 1) + 16 * (kr1 >> 1);
    const int cw2 = 2 * row + (kr2 & 1) + 16 * (kr2 >> 1);
    const int cw3 = 2 * row + (kr3 & 1) + 16 * (kr3 >> 1);
    const int sc1dst = SP(cw1 + 32);
    const int sc2dst = SP(cw2 + 64);
    const int sc3dst = SP(cw3 + 96);
    ulonglong2* s2 = (ulonglong2*)s;
    const int sg0 = SP(2 * t) >> 1, sg1 = SP(64 + 2 * t) >> 1;   // g layout in 16-byte units

    ulonglong2 pa = m2[(size_t)(start - 1) * 64 + t];
    ulonglong2 pb = m2[(size_t)(start - 1) * 64 + 32 + t];
    ulonglong2 fa, fb;                                    // prefetched reference block (i-part)
    fa.x = fa.y = fb.x = fb.y = 0;
    if (start < half) {
        uint32_t r = __ldg(table + start);
        fa = m2[(size_t)r * 64 + t];
        fb = m2[(size_t)r * 64 + 32 + t];
    }
    for (uint32_t i = start; i < end; i++) {
        ulonglong2 qa, qb;
        if (i < half) {
            qa = fa;
            qb = fb;
            if (i + 1 < half && i + 1 < end) {
                uint32_t r = __ldg(table + i + 1);
                fa = m2[(size_t)r * 64 + t];
                fb = m2[(size_t)r * 64 + 32 + t];
            }
        } else {
            uint64_t w0 = __shfl_sync(FULL_MASK, pa.x, 0);
            uint32_t r = d_ref_index(i, (uint32_t)w0);
            qa = m2[(size_t)r * 64 + t];
            qb = m2[(size_t)r * 64 + 32 + t];
        }
        // Reuse qa/qb for R = previous XOR reference instead of keeping separate ra/rb
        // vectors live for the entire row/column permutation. That removes four live uint64_t
        // values per thread in the hot loop. qa/qb are no longer needed as raw reference data.
        qa = xor2(pa, qa);
        qb = xor2(pb, qb);
        // Each thread stores to distinct shared-memory words, and no shared values from the
        // previous iteration are still needed here. The barrier after these stores is sufficient
        // to make the whole warp's writes visible before row-step reads.
        s2[sg0] = qa;
        s2[sg1] = qb;
        __syncwarp();
        uint64_t a = s[sr0], b = s[sr1], c = s[sr2], d = s[sr3];
        d_round4_scatter(a, b, c, d, gbase, k);
        // a remains owned by this lane; the diagonal-round b/c/d values are stored
        // to the logical slots owned by lanes k+1/k+2/k+3 in the same four-lane group.
        s[sr0] = a; s[sr1dst] = b; s[sr2dst] = c; s[sr3dst] = d;
        __syncwarp();
        a = s[sc0]; b = s[sc1]; c = s[sc2]; d = s[sc3];
        d_round4_scatter(a, b, c, d, gbase, k);
        s[sc0] = a; s[sc1dst] = b; s[sc2dst] = c; s[sc3dst] = d;
        __syncwarp();
        pa = xor2(s2[sg0], qa);
        pb = xor2(s2[sg1], qb);
        m2[(size_t)i * 64 + t] = pa;
        m2[(size_t)i * 64 + 32 + t] = pb;
    }
    // The last fill launch also computes H'(32, last_block). All threads' global stores
    // must be visible before thread 0 reads the complete final block.
    if ((out_tags || out_share_flags || out_block_flags || out_candidates) && end == half * 2) {
        __syncwarp(FULL_MASK);
        if (t == 0) {
            const uint64_t* last_words = (const uint64_t*)(m2 + (size_t)(end - 1) * 64);
            uint8_t tag[32];
            d_hprime32_from_words(tag, last_words);
            if (out_tags) {
                uint8_t* out = out_tags + (size_t)blockIdx.x * 32;
#pragma unroll
                for (int j = 0; j < 32; ++j) out[j] = tag[j];
            }
            // Target checks and candidate compaction run on-device. The host only
            // receives compact records for hashes that meet a target, not every tag.
            const bool share_ok = share_target && d_hash_le_target(tag, share_target);
            const bool block_ok = network_target && d_target_nonzero(network_target) &&
                                  d_hash_le_target(tag, network_target);
            if (out_share_flags) out_share_flags[blockIdx.x] = share_ok ? 1u : 0u;
            if (out_block_flags) out_block_flags[blockIdx.x] = block_ok ? 1u : 0u;
            // Preserve a network-block candidate even if a misconfigured pool share
            // target happens to be stricter than network_target.
            if (out_candidates && out_candidate_count && (share_ok || block_ok)) {
                const uint32_t slot = atomicAdd(out_candidate_count, 1u);
                if (slot < candidate_capacity) {
                    BgShareCandidate* cnd = out_candidates + slot;
                    cnd->nonce = init_nonces ? init_nonces[blockIdx.x] : 0ULL;
                    cnd->lane_index = blockIdx.x;
                    cnd->flags = (share_ok ? BG_CANDIDATE_SHARE : 0u) |
                                 (block_ok ? BG_CANDIDATE_BLOCK : 0u);
#pragma unroll
                    for (int j = 0; j < 32; ++j) cnd->hash[j] = tag[j];
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// GPU Stratum JSON lexer / schema extractor. The CPU still does socket I/O and
// maintains connection state, but every inbound JSON line is parsed here.
// ---------------------------------------------------------------------------
struct DJsonCursor { const char* s; uint32_t n, p; int bad; };

__device__ __forceinline__ void dj_ws(DJsonCursor& c)
{
    while (c.p < c.n) {
        char x = c.s[c.p];
        if (x != ' ' && x != '\t' && x != '\r' && x != '\n') break;
        ++c.p;
    }
}
__device__ __forceinline__ bool dj_take(DJsonCursor& c, char x)
{
    dj_ws(c);
    if (c.p >= c.n || c.s[c.p] != x) { c.bad = 1; return false; }
    ++c.p; return true;
}
__device__ __forceinline__ int dj_hex(char x)
{
    if (x >= '0' && x <= '9') return x - '0';
    if (x >= 'a' && x <= 'f') return x - 'a' + 10;
    if (x >= 'A' && x <= 'F') return x - 'A' + 10;
    return -1;
}
__device__ bool dj_hex4(DJsonCursor& c, uint32_t& v)
{
    if (c.p + 4 > c.n) { c.bad = 1; return false; }
    v = 0;
    #pragma unroll
    for (int i = 0; i < 4; ++i) {
        int h = dj_hex(c.s[c.p++]);
        if (h < 0) { c.bad = 1; return false; }
        v = (v << 4) | (uint32_t)h;
    }
    return true;
}
__device__ void dj_emit_utf8(char* out, uint32_t cap, uint32_t& used, uint32_t cp)
{
    if (!out || cap == 0) return;
    uint8_t b[4]; uint32_t n = 0;
    if (cp < 0x80) { b[0] = (uint8_t)cp; n = 1; }
    else if (cp < 0x800) { b[0] = 0xc0 | (cp >> 6); b[1] = 0x80 | (cp & 63); n = 2; }
    else if (cp < 0x10000) { b[0] = 0xe0 | (cp >> 12); b[1] = 0x80 | ((cp >> 6) & 63); b[2] = 0x80 | (cp & 63); n = 3; }
    else { b[0] = 0xf0 | (cp >> 18); b[1] = 0x80 | ((cp >> 12) & 63); b[2] = 0x80 | ((cp >> 6) & 63); b[3] = 0x80 | (cp & 63); n = 4; }
    for (uint32_t i = 0; i < n; ++i) {
        if (used + 1 < cap) out[used] = (char)b[i];
        ++used;
    }
}
__device__ bool dj_string(DJsonCursor& c, char* out, uint32_t cap, uint32_t* out_len = nullptr)
{
    dj_ws(c);
    if (c.p >= c.n || c.s[c.p++] != '"') { c.bad = 1; return false; }
    uint32_t used = 0;
    while (c.p < c.n) {
        uint8_t x = (uint8_t)c.s[c.p++];
        if (x == '"') {
            if (out && cap) {
                if (used >= cap) { c.bad = 1; return false; }
                out[used] = 0;
            }
            if (out_len) *out_len = used;
            return true;
        }
        if (x < 0x20) { c.bad = 1; return false; }
        if (x == '\\') {
            if (c.p >= c.n) { c.bad = 1; return false; }
            char e = c.s[c.p++];
            switch (e) {
                case '"': x = '"'; break; case '\\': x = '\\'; break; case '/': x = '/'; break;
                case 'b': x = '\b'; break; case 'f': x = '\f'; break; case 'n': x = '\n'; break;
                case 'r': x = '\r'; break; case 't': x = '\t'; break;
                case 'u': {
                    uint32_t cp;
                    if (!dj_hex4(c, cp)) return false;
                    if (cp >= 0xd800 && cp <= 0xdbff && c.p + 6 <= c.n && c.s[c.p] == '\\' && c.s[c.p + 1] == 'u') {
                        c.p += 2; uint32_t lo;
                        if (!dj_hex4(c, lo) || lo < 0xdc00 || lo > 0xdfff) { c.bad = 1; return false; }
                        cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                    }
                    dj_emit_utf8(out, cap, used, cp);
                    continue;
                }
                default: c.bad = 1; return false;
            }
        }
        if (out && cap && used + 1 < cap) out[used++] = (char)x;
        else if (out && cap) used++;
    }
    c.bad = 1; return false;
}
__device__ bool dj_eq(const char* a, const char* b)
{
    uint32_t i = 0;
    while (a[i] && b[i] && a[i] == b[i]) ++i;
    return a[i] == 0 && b[i] == 0;
}
__device__ bool dj_null(DJsonCursor& c)
{
    dj_ws(c);
    if (c.p + 4 <= c.n && c.s[c.p] == 'n' && c.s[c.p+1] == 'u' && c.s[c.p+2] == 'l' && c.s[c.p+3] == 'l') { c.p += 4; return true; }
    return false;
}
__device__ bool dj_skip_string(DJsonCursor& c)
{
    return dj_string(c, nullptr, 0, nullptr);
}
__device__ bool dj_skip_value(DJsonCursor& c)
{
    dj_ws(c);
    if (c.p >= c.n) { c.bad = 1; return false; }
    char x = c.s[c.p];
    if (x == '"') return dj_skip_string(c);
    if (x == '{' || x == '[') {
        int depth = 0; bool in_string = false, escape = false;
        do {
            char q = c.s[c.p++];
            if (in_string) {
                if (escape) escape = false;
                else if (q == '\\') escape = true;
                else if (q == '"') in_string = false;
                continue;
            }
            if (q == '"') in_string = true;
            else if (q == '{' || q == '[') ++depth;
            else if (q == '}' || q == ']') --depth;
            if (depth < 0) { c.bad = 1; return false; }
        } while (c.p < c.n && depth > 0);
        if (depth != 0 || in_string) { c.bad = 1; return false; }
        return true;
    }
    uint32_t start = c.p;
    while (c.p < c.n) {
        char q = c.s[c.p];
        if (q == ',' || q == '}' || q == ']' || q == ' ' || q == '\t' || q == '\r' || q == '\n') break;
        ++c.p;
    }
    if (c.p == start) { c.bad = 1; return false; }
    return true;
}
__device__ bool dj_u64(DJsonCursor& c, uint64_t& out)
{
    dj_ws(c); bool quoted = c.p < c.n && c.s[c.p] == '"';
    if (quoted) ++c.p;
    if (c.p >= c.n || c.s[c.p] < '0' || c.s[c.p] > '9') { c.bad = 1; return false; }
    uint64_t v = 0;
    while (c.p < c.n && c.s[c.p] >= '0' && c.s[c.p] <= '9') {
        uint32_t d = (uint32_t)(c.s[c.p++] - '0');
        if (v > (UINT64_MAX - d) / 10ULL) { c.bad = 1; return false; }
        v = v * 10ULL + d;
    }
    // Difficulty (and some pool implementations' numeric strings) can be
    // represented with a decimal/exponent. The previous host strtoull path
    // consumed the integer prefix; preserve that conversion for both JSON
    // numbers and quoted numeric strings while still validating the full token.
    if (c.p < c.n && c.s[c.p] == '.') {
        ++c.p; uint32_t digits = 0;
        while (c.p < c.n && c.s[c.p] >= '0' && c.s[c.p] <= '9') { ++c.p; ++digits; }
        if (!digits) { c.bad = 1; return false; }
    }
    if (c.p < c.n && (c.s[c.p] == 'e' || c.s[c.p] == 'E')) {
        ++c.p;
        if (c.p < c.n && (c.s[c.p] == '+' || c.s[c.p] == '-')) ++c.p;
        uint32_t digits = 0;
        while (c.p < c.n && c.s[c.p] >= '0' && c.s[c.p] <= '9') { ++c.p; ++digits; }
        if (!digits) { c.bad = 1; return false; }
    }
    if (quoted) {
        if (c.p >= c.n || c.s[c.p++] != '"') { c.bad = 1; return false; }
    } else if (c.p < c.n) {
        char d = c.s[c.p];
        if (d != ',' && d != '}' && d != ']' && d != ' ' && d != '\t' && d != '\r' && d != '\n') { c.bad = 1; return false; }
    }
    out = v; return true;
}

__device__ bool dj_i64(DJsonCursor& c, int64_t& out)
{
    dj_ws(c); bool neg = c.p < c.n && c.s[c.p] == '-';
    if (neg) ++c.p;
    uint64_t v;
    if (!dj_u64(c, v)) return false;
    if (neg) {
        if (v > (uint64_t)INT64_MAX + 1ULL) { c.bad = 1; return false; }
        out = v == (uint64_t)INT64_MAX + 1ULL ? INT64_MIN : -(int64_t)v;
    } else {
        if (v > (uint64_t)INT64_MAX) { c.bad = 1; return false; }
        out = (int64_t)v;
    }
    return true;
}
__device__ bool dj_bool(DJsonCursor& c, uint32_t& out)
{
    dj_ws(c);
    if (c.p + 4 <= c.n && c.s[c.p] == 't' && c.s[c.p+1] == 'r' && c.s[c.p+2] == 'u' && c.s[c.p+3] == 'e') { c.p += 4; out = 1; return true; }
    if (c.p + 5 <= c.n && c.s[c.p] == 'f' && c.s[c.p+1] == 'a' && c.s[c.p+2] == 'l' && c.s[c.p+3] == 's' && c.s[c.p+4] == 'e') { c.p += 5; out = 0; return true; }
    c.bad = 1; return false;
}
__device__ bool dj_hex_bytes(const char* s, uint32_t n, uint8_t* out, uint32_t want)
{
    if (n >= 2 && s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) { s += 2; n -= 2; }
    if (n != want * 2) return false;
    for (uint32_t i = 0; i < want; ++i) {
        int a = dj_hex(s[2*i]), b = dj_hex(s[2*i+1]);
        if (a < 0 || b < 0) return false;
        out[i] = (uint8_t)((a << 4) | b);
    }
    return true;
}
__device__ bool dj_string_field(DJsonCursor& c, char* out, uint32_t cap)
{
    return dj_string(c, out, cap, nullptr);
}
__device__ bool dj_parse_params(DJsonCursor& c, BgStratumMessage* o)
{
    if (!dj_take(c, '{')) return false;
    dj_ws(c);
    if (c.p < c.n && c.s[c.p] == '}') { ++c.p; return true; }
    while (!c.bad) {
        char key[64] = {};
        if (!dj_string(c, key, sizeof(key)) || !dj_take(c, ':')) return false;
        if (dj_eq(key, "job_id")) { if (!dj_string_field(c, o->job_id, sizeof(o->job_id))) return false; }
        else if (dj_eq(key, "header_base")) {
            char h[256] = {}; uint32_t n = 0;
            if (!dj_string(c, h, sizeof(h), &n) || !dj_hex_bytes(h, n, o->header, 92)) { c.bad = 1; return false; }
            o->header_len = 92;
        }
        else if (dj_eq(key, "target")) {
            char h[80] = {}; uint32_t n = 0;
            if (!dj_string(c, h, sizeof(h), &n) || !dj_hex_bytes(h, n, o->target, 32)) { c.bad = 1; return false; }
            o->has_target = 1;
        }
        else if (dj_eq(key, "network_target")) {
            char h[80] = {}; uint32_t n = 0;
            if (dj_null(c)) o->has_network_target = 0;
            else {
                if (!dj_string(c, h, sizeof(h), &n)) return false;
                if (dj_hex_bytes(h, n, o->network_target, 32)) o->has_network_target = 1;
                else o->has_network_target = 0;
            }
        }
        else if (dj_eq(key, "height")) { if (!dj_null(c)) { if (!dj_u64(c, o->height)) return false; o->has_height = 1; } }
        else if (dj_eq(key, "difficulty")) { if (!dj_null(c)) { if (!dj_u64(c, o->difficulty)) return false; o->has_difficulty = 1; } }
        else if (dj_eq(key, "nonce_start")) { if (!dj_null(c)) { if (!dj_u64(c, o->nonce_start)) return false; o->has_nonce_start = 1; } }
        else if (dj_eq(key, "nonce_end")) { if (!dj_null(c)) { if (!dj_u64(c, o->nonce_end)) return false; o->has_nonce_end = 1; } }
        else if (dj_eq(key, "message")) { if (!dj_string_field(c, o->message, sizeof(o->message))) return false; }
        else if (dj_eq(key, "kind")) { if (!dj_string_field(c, o->kind, sizeof(o->kind))) return false; }
        else if (!dj_skip_value(c)) return false;
        dj_ws(c);
        if (c.p < c.n && c.s[c.p] == ',') { ++c.p; continue; }
        if (c.p < c.n && c.s[c.p] == '}') { ++c.p; return true; }
        c.bad = 1; return false;
    }
    return false;
}
__device__ bool dj_parse_capabilities(DJsonCursor& c, BgStratumMessage* o)
{
    if (!dj_take(c, '[')) return false;
    dj_ws(c);
    if (c.p < c.n && c.s[c.p] == ']') { ++c.p; return true; }
    while (!c.bad) {
        dj_ws(c);
        if (c.p < c.n && c.s[c.p] == '"') {
            char value[96] = {};
            if (!dj_string(c, value, sizeof(value))) return false;
            if (dj_eq(value, "submit_claimed_hash")) o->can_submit_claimed_hash = 1;
        } else if (!dj_skip_value(c)) return false;
        dj_ws(c);
        if (c.p < c.n && c.s[c.p] == ',') { ++c.p; continue; }
        if (c.p < c.n && c.s[c.p] == ']') { ++c.p; return true; }
        c.bad = 1; return false;
    }
    return false;
}
__device__ bool dj_parse_result(DJsonCursor& c, BgStratumMessage* o)
{
    if (!dj_take(c, '{')) return false;
    dj_ws(c);
    if (c.p < c.n && c.s[c.p] == '}') { ++c.p; return true; }
    while (!c.bad) {
        char key[64] = {};
        if (!dj_string(c, key, sizeof(key)) || !dj_take(c, ':')) return false;
        if (dj_eq(key, "accepted")) { if (!dj_null(c)) { if (!dj_bool(c, o->accepted)) return false; o->has_accepted = 1; } }
        else if (dj_eq(key, "protocol_version")) {
            if (!dj_null(c)) {
                uint64_t pv = 0;
                if (!dj_u64(c, pv) || pv > UINT32_MAX) return false;
                o->protocol_version = (uint32_t)pv; o->has_protocol_version = 1;
            }
        }
        else if (dj_eq(key, "capabilities")) { if (!dj_parse_capabilities(c, o)) return false; }
        else if (!dj_skip_value(c)) return false;
        dj_ws(c);
        if (c.p < c.n && c.s[c.p] == ',') { ++c.p; continue; }
        if (c.p < c.n && c.s[c.p] == '}') { ++c.p; return true; }
        c.bad = 1; return false;
    }
    return false;
}
__device__ bool dj_parse_top(DJsonCursor& c, BgStratumMessage* o)
{
    if (!dj_take(c, '{')) return false;
    dj_ws(c);
    if (c.p < c.n && c.s[c.p] == '}') { ++c.p; return true; }
    while (!c.bad) {
        char key[64] = {};
        if (!dj_string(c, key, sizeof(key)) || !dj_take(c, ':')) return false;
        if (dj_eq(key, "id")) { if (!dj_i64(c, o->id)) return false; o->has_id = 1; }
        else if (dj_eq(key, "method")) { if (!dj_null(c) && !dj_string_field(c, o->method, sizeof(o->method))) return false; }
        else if (dj_eq(key, "status")) {
            if (!dj_null(c) && !dj_string_field(c, o->status, sizeof(o->status))) return false;
            o->status_ok = dj_eq(o->status, "ok") || dj_eq(o->status, "OK");
        }
        else if (dj_eq(key, "params")) {
            dj_ws(c);
            if (dj_null(c)) { }
            else if (c.p < c.n && c.s[c.p] == '"') { if (!dj_string_field(c, o->message, sizeof(o->message))) return false; }
            else if (c.p < c.n && c.s[c.p] == '{') { if (!dj_parse_params(c, o)) return false; }
            else if (!dj_skip_value(c)) return false;
        }
        else if (dj_eq(key, "result")) { if (!dj_null(c)) { if (c.p < c.n && c.s[c.p] == '{') { if (!dj_parse_result(c, o)) return false; } else if (!dj_skip_value(c)) return false; } }
        else if (dj_eq(key, "error")) {
            if (!dj_null(c)) { o->has_error = 1; if (!dj_skip_value(c)) return false; }
        }
        else if (!dj_skip_value(c)) return false;
        dj_ws(c);
        if (c.p < c.n && c.s[c.p] == ',') { ++c.p; continue; }
        if (c.p < c.n && c.s[c.p] == '}') { ++c.p; break; }
        c.bad = 1; return false;
    }
    dj_ws(c);
    return !c.bad && c.p == c.n;
}
__global__ void stratum_json_kernel(const char* input, uint32_t bytes, BgStratumMessage* output)
{
    if (blockIdx.x || threadIdx.x) return;
    BgStratumMessage out = {};
    DJsonCursor c{ input, bytes, 0, 0 };
    if (dj_parse_top(c, &out) && !c.bad) {
        out.valid = 1;
        if (dj_eq(out.method, "job")) out.type = BG_STRATUM_JOB;
        else if (dj_eq(out.method, "notification")) out.type = BG_STRATUM_NOTIFICATION;
        else if (out.has_id) out.type = BG_STRATUM_RESPONSE;
        else out.type = BG_STRATUM_OTHER;
    }
    *output = out;
}

// Minimal JSON writer used for outbound Stratum payloads. Formatting is done by
// CUDA; the host only hands the completed byte string to the TCP/TLS transport.
struct DJsonWriter { char* out; uint32_t cap, pos; int bad; };
__device__ __forceinline__ void jw_char(DJsonWriter& w, char c)
{
    if (w.bad) return;
    if (w.pos + 1 >= w.cap) { w.bad = 1; return; }
    w.out[w.pos++] = c;
}
__device__ void jw_lit(DJsonWriter& w, const char* s)
{
    for (uint32_t i = 0; s[i] && !w.bad; ++i) jw_char(w, s[i]);
}
__device__ void jw_u64(DJsonWriter& w, uint64_t x)
{
    char tmp[20]; uint32_t n = 0;
    do { tmp[n++] = (char)('0' + (x % 10ULL)); x /= 10ULL; } while (x && n < sizeof(tmp));
    while (n && !w.bad) jw_char(w, tmp[--n]);
}
__device__ __forceinline__ char jw_hex_digit(uint32_t v)
{
    return (char)(v < 10 ? ('0' + v) : ('a' + v - 10));
}
__device__ void jw_string(DJsonWriter& w, const char* s)
{
    jw_char(w, '"');
    for (uint32_t i = 0; s[i] && !w.bad; ++i) {
        const uint8_t c = (uint8_t)s[i];
        if (c == '"' || c == '\\') { jw_char(w, '\\'); jw_char(w, (char)c); }
        else if (c < 0x20) {
            jw_lit(w, "\\u00"); jw_char(w, jw_hex_digit(c >> 4)); jw_char(w, jw_hex_digit(c & 15));
        } else jw_char(w, (char)c);
    }
    jw_char(w, '"');
}
__device__ void jw_hex32(DJsonWriter& w, const uint8_t* bytes)
{
    jw_char(w, '"');
    for (int i = 0; i < 32 && !w.bad; ++i) {
        jw_char(w, jw_hex_digit(bytes[i] >> 4));
        jw_char(w, jw_hex_digit(bytes[i] & 15));
    }
    jw_char(w, '"');
}
__global__ void stratum_format_kernel(const BgStratumFormatInput* input, char* output,
                                      uint32_t capacity, uint32_t* output_bytes)
{
    if (blockIdx.x || threadIdx.x) return;
    DJsonWriter w{ output, capacity, 0, 0 };
    if (input->kind == 1u) {
        jw_lit(w, "{\"id\":1,\"method\":\"login\",\"params\":{\"address\":");
        jw_string(w, input->address);
        jw_lit(w, ",\"worker\":"); jw_string(w, input->worker);
        jw_lit(w, ",\"protocol_version\":2,\"capabilities\":[\"login_negotiation\",\"share_validation_status\",\"submit_claimed_hash\"]}}");
    } else if (input->kind == 2u) {
        jw_lit(w, "{\"id\":"); jw_u64(w, input->id);
        jw_lit(w, ",\"method\":\"submit\",\"params\":{\"job_id\":"); jw_string(w, input->job_id);
        jw_lit(w, ",\"nonce\":"); jw_u64(w, input->nonce);
        if (input->include_claimed_hash) {
            jw_lit(w, ",\"claimed_hash\":"); jw_hex32(w, input->claimed_hash);
        }
        jw_lit(w, ",\"miner_version\":"); jw_string(w, input->miner_version);
        jw_lit(w, "}}");
    } else w.bad = 1;
    if (!w.bad && w.pos < capacity) {
        output[w.pos] = 0;
        *output_bytes = w.pos;
    } else {
        output[0] = 0;
        *output_bytes = 0;
    }
}

__global__ void prepare_gpu_nonce_batch_kernel(
    const uint8_t* job_header, uint32_t header_bytes,
    uint8_t* lane_headers, uint64_t* lane_nonces, uint8_t* lane_valid,
    uint64_t nonce_base, uint64_t nonce_stride, uint64_t max_index, uint32_t empty_range,
    uint64_t* cursor, uint32_t* exhausted, uint32_t* valid_count, uint32_t nlanes)
{
    __shared__ unsigned long long base_index;
    __shared__ uint32_t count;
    if (threadIdx.x == 0) {
        uint64_t base = *cursor;
        count = 0;
        if (!empty_range && !*exhausted && base <= max_index) {
            uint64_t remaining = max_index - base;
            count = remaining >= (uint64_t)(nlanes - 1) ? nlanes : (uint32_t)(remaining + 1ULL);
            if (remaining < (uint64_t)nlanes) *exhausted = 1u;
            else *cursor = base + (uint64_t)nlanes;
        } else {
            *exhausted = 1u;
        }
        base_index = (unsigned long long)base;
        *valid_count = count;
    }
    __syncthreads();
    const uint32_t lane = threadIdx.x;
    if (lane < nlanes) {
        if (lane < count) {
            const uint64_t index = (uint64_t)base_index + lane;
            const uint64_t nonce = nonce_base + index * nonce_stride;
            lane_nonces[lane] = nonce;
            uint8_t* dst = lane_headers + (size_t)lane * header_bytes;
            for (uint32_t j = 0; j < header_bytes; ++j) dst[j] = job_header[j];
            lane_valid[lane] = 1u;
        } else {
            lane_nonces[lane] = 0;
            lane_valid[lane] = 0u;
        }
    }
}

// ---------------------------------------------------------------------------
// host side
// ---------------------------------------------------------------------------
static const char* KERNEL_INFO = "pinned H2D/D2H staging + CUDA events, GPU Stratum JSON parser/formatter, GPU nonce allocator/shards, BLAKE2b H0/Hprime, Argon2i address table, share/block filter, R-register reuse, scatter-store, smem pad" BG_STR(BGPU_SMEM_PAD_WORDS) ", i-part prefetch, sync-batched launches";

struct BgPinnedJobStage {
    uint8_t header[100];
    uint8_t share_target[32];
    uint8_t network_target[32];
    uint64_t nonce_cursor;
    uint32_t nonce_exhausted;
};

struct BgCtx {
    int dev = -1;
    uint32_t m_blocks = 0;
    int lanes = 0;
    int chunk = 32768;
    int memory_mode = BG_MEMORY_GPU;
    int gpu_lanes = 0;
    int host_lanes = 0;
    // lane_mem is the CPU-visible allocation base (cudaMalloc pointer for GPU lanes,
    // host pointer for mapped RAM lanes). lane_dev_mem always contains the pointer
    // that CUDA kernels must dereference.
    std::vector<uint64_t*> lane_mem;
    std::vector<uint64_t*> lane_dev_mem;
    std::vector<uint8_t> lane_is_host;
    uint64_t** d_lanes = nullptr;
    uint32_t* d_table = nullptr;
    uint8_t* d_headers = nullptr;   // lanes * 100-byte salt/header
    uint64_t* d_nonces = nullptr;
    uint8_t* d_valid_flags = nullptr;
    uint32_t* d_valid_count = nullptr;
    uint8_t* d_job_header = nullptr;
    uint64_t* d_nonce_cursor = nullptr;
    uint32_t* d_nonce_exhausted = nullptr;
    uint64_t gpu_nonce_base = 0, gpu_nonce_stride = 1, gpu_nonce_max_index = 0;
    uint32_t gpu_nonce_empty = 1, gpu_job_header_bytes = 0;
    char* d_stratum_json = nullptr;
    BgStratumMessage* d_stratum_out = nullptr;
    BgStratumFormatInput* d_stratum_format_in = nullptr;
    char* d_stratum_format_out = nullptr;
    uint32_t* d_stratum_format_len = nullptr;
    cudaStream_t parse_stream = nullptr;
    cudaEvent_t parse_done = nullptr;
    std::mutex parse_mtx;

    // Pinned host staging: cudaMemcpyAsync is genuinely asynchronous only when
    // host endpoints are page-locked. These buffers are owned by this context.
    char* h_stratum_json = nullptr;                    // 4 MiB RX staging
    BgStratumMessage* h_stratum_out = nullptr;
    BgStratumFormatInput* h_stratum_format_in = nullptr;
    char* h_stratum_format_out = nullptr;
    uint32_t* h_stratum_format_len = nullptr;
    BgPinnedJobStage* h_job_stage = nullptr;

    uint32_t* h_valid_count = nullptr;
    uint32_t* h_candidate_count = nullptr;
    BgShareCandidate* h_candidates = nullptr;          // at most lanes records
    uint8_t* h_full_headers = nullptr;                  // lanes * 100
    uint64_t* h_full_nonces = nullptr;                  // lanes
    uint8_t* h_full_targets = nullptr;                  // share + network target
    uint8_t* h_full_tags = nullptr;                     // lanes * 32
    uint8_t* h_full_flags = nullptr;                    // share flags + block flags
    uint64_t* h_compat_init = nullptr;                   // legacy API: lanes * 256 qwords
    uint64_t* h_compat_last = nullptr;                   // legacy API: lanes * 128 qwords
    cudaEvent_t work_done = nullptr;
    std::mutex work_mtx;
    uint8_t* d_tags = nullptr;      // lanes * 32-byte final tags
    uint8_t* d_share_target = nullptr; // big-endian pool target, 32 bytes
    uint8_t* d_network_target = nullptr; // big-endian block target, 32 bytes
    uint8_t* d_share_flags = nullptr; // lanes: final tag <= share target
    uint8_t* d_block_flags = nullptr; // lanes: nonzero network target && final tag <= target
    BgShareCandidate* d_candidates = nullptr; // compact device-side matching results
    uint32_t* d_candidate_count = nullptr; // atomic compact-output counter
    cudaStream_t stream = nullptr;
    cudaEvent_t ev0 = nullptr, ev1 = nullptr;
    std::string name, err;
    int cc = 0, sms = 0;
    double mem_total = 0, mem_used = 0, host_mem_used = 0;
};

// Declared here because bg_hash_next_candidates() uses run_range() before
// its implementation below. Default arguments are specified only once here.
static int run_range(BgCtx* c, int nlanes, uint32_t start, uint32_t end, volatile int* abort,
                     const uint8_t* init_headers = nullptr, const uint64_t* init_nonces = nullptr,
                     uint32_t header_bytes = 100u, uint8_t* out_tags = nullptr,
                     const uint8_t* share_target = nullptr, const uint8_t* network_target = nullptr,
                     uint8_t* out_share_flags = nullptr, uint8_t* out_block_flags = nullptr,
                     BgShareCandidate* out_candidates = nullptr, uint32_t* out_candidate_count = nullptr,
                     uint32_t candidate_capacity = 0, const uint8_t* valid_flags = nullptr);

static std::string g_create_err;

static bool ck(BgCtx* c, cudaError_t e, const char* what)
{
    if (e == cudaSuccess) return true;
    char b[256];
    snprintf(b, sizeof b, "%s: %s (%d)", what, cudaGetErrorString(e), (int)e);
    if (c) c->err = b; else g_create_err = b;
    return false;
}

BG_API int bg_device_count(void)
{
    int n = 0;
    if (cudaGetDeviceCount(&n) != cudaSuccess) return 0;
    return n;
}

BG_API void bg_destroy(void* h)
{
    BgCtx* c = (BgCtx*)h;
    if (!c) return;
    (void)cudaSetDevice(c->dev);
    // Drain queued DMA and kernels before releasing either device or pinned host memory.
    if (c->stream) (void)cudaStreamSynchronize(c->stream);
    if (c->parse_stream) (void)cudaStreamSynchronize(c->parse_stream);

    for (size_t i = 0; i < c->lane_mem.size(); ++i) {
        if (i < c->lane_is_host.size() && c->lane_is_host[i]) cudaFreeHost(c->lane_mem[i]);
        else cudaFree(c->lane_mem[i]);
    }
    if (c->d_lanes) cudaFree(c->d_lanes);
    if (c->d_table) cudaFree(c->d_table);
    if (c->d_headers) cudaFree(c->d_headers);
    if (c->d_nonces) cudaFree(c->d_nonces);
    if (c->d_valid_flags) cudaFree(c->d_valid_flags);
    if (c->d_valid_count) cudaFree(c->d_valid_count);
    if (c->d_job_header) cudaFree(c->d_job_header);
    if (c->d_nonce_cursor) cudaFree(c->d_nonce_cursor);
    if (c->d_nonce_exhausted) cudaFree(c->d_nonce_exhausted);
    if (c->d_stratum_json) cudaFree(c->d_stratum_json);
    if (c->d_stratum_out) cudaFree(c->d_stratum_out);
    if (c->d_stratum_format_in) cudaFree(c->d_stratum_format_in);
    if (c->d_stratum_format_out) cudaFree(c->d_stratum_format_out);
    if (c->d_stratum_format_len) cudaFree(c->d_stratum_format_len);
    if (c->d_tags) cudaFree(c->d_tags);
    if (c->d_share_target) cudaFree(c->d_share_target);
    if (c->d_network_target) cudaFree(c->d_network_target);
    if (c->d_share_flags) cudaFree(c->d_share_flags);
    if (c->d_block_flags) cudaFree(c->d_block_flags);
    if (c->d_candidates) cudaFree(c->d_candidates);
    if (c->d_candidate_count) cudaFree(c->d_candidate_count);

    if (c->h_stratum_json) cudaFreeHost(c->h_stratum_json);
    if (c->h_stratum_out) cudaFreeHost(c->h_stratum_out);
    if (c->h_stratum_format_in) cudaFreeHost(c->h_stratum_format_in);
    if (c->h_stratum_format_out) cudaFreeHost(c->h_stratum_format_out);
    if (c->h_stratum_format_len) cudaFreeHost(c->h_stratum_format_len);
    if (c->h_job_stage) cudaFreeHost(c->h_job_stage);
    if (c->h_valid_count) cudaFreeHost(c->h_valid_count);
    if (c->h_candidate_count) cudaFreeHost(c->h_candidate_count);
    if (c->h_candidates) cudaFreeHost(c->h_candidates);
    if (c->h_full_headers) cudaFreeHost(c->h_full_headers);
    if (c->h_full_nonces) cudaFreeHost(c->h_full_nonces);
    if (c->h_full_targets) cudaFreeHost(c->h_full_targets);
    if (c->h_full_tags) cudaFreeHost(c->h_full_tags);
    if (c->h_full_flags) cudaFreeHost(c->h_full_flags);
    if (c->h_compat_init) cudaFreeHost(c->h_compat_init);
    if (c->h_compat_last) cudaFreeHost(c->h_compat_last);

    if (c->ev0) cudaEventDestroy(c->ev0);
    if (c->ev1) cudaEventDestroy(c->ev1);
    if (c->parse_done) cudaEventDestroy(c->parse_done);
    if (c->work_done) cudaEventDestroy(c->work_done);
    if (c->stream) cudaStreamDestroy(c->stream);
    if (c->parse_stream) cudaStreamDestroy(c->parse_stream);
    delete c;
}

BG_API void* bg_create_memory(int device, uint32_t m_blocks, int lanes, int reserve_mb, int chunk, int memory_mode)
{
    g_create_err.clear();
    if (m_blocks < 8 || m_blocks % 8) { g_create_err = "m_blocks must be a multiple of 8"; return nullptr; }
    if (memory_mode < BG_MEMORY_GPU || memory_mode > BG_MEMORY_HYBRID) { g_create_err = "invalid Argon2 memory mode"; return nullptr; }
    if (memory_mode != BG_MEMORY_GPU && lanes <= 0) {
        g_create_err = "argon2-memory=host/hybrid requires an explicit --lanes N to prevent accidental RAM pinning";
        return nullptr;
    }
    BgCtx* c = new BgCtx();
    c->dev = device;
    c->m_blocks = m_blocks;
    c->memory_mode = memory_mode;
    if (chunk > 0) c->chunk = chunk;
    cudaDeviceProp p;
    if (!ck(nullptr, cudaSetDevice(device), "cudaSetDevice") || !ck(nullptr, cudaGetDeviceProperties(&p, device), "cudaGetDeviceProperties")) {
        delete c;
        return nullptr;
    }
    if (memory_mode != BG_MEMORY_GPU && !p.canMapHostMemory) {
        g_create_err = "selected GPU cannot map pinned host memory (cudaDeviceProp.canMapHostMemory=0)";
        bg_destroy(c);
        return nullptr;
    }
    // CUDA Runtime API contexts enable cudaDeviceMapHost implicitly. The actual
    // capability is validated again by cudaHostGetDevicePointer for each lane.
    c->name = p.name;
    c->cc = p.major * 10 + p.minor;
    c->sms = p.multiProcessorCount;
    c->mem_total = (double)p.totalGlobalMem;
    if (!ck(nullptr, cudaFree(0), "cuda context") || !ck(nullptr, cudaStreamCreateWithFlags(&c->stream, cudaStreamNonBlocking), "stream") ||
        !ck(nullptr, cudaStreamCreateWithFlags(&c->parse_stream, cudaStreamNonBlocking), "Stratum parser stream") ||
        !ck(nullptr, cudaEventCreate(&c->ev0), "event") || !ck(nullptr, cudaEventCreate(&c->ev1), "event") ||
        !ck(nullptr, cudaEventCreateWithFlags(&c->work_done, cudaEventDisableTiming), "work completion event") ||
        !ck(nullptr, cudaEventCreateWithFlags(&c->parse_done, cudaEventDisableTiming), "parser completion event")) {
        bg_destroy(c);
        return nullptr;
    }
    // Build the Argon2i reference table on the GPU; production PoW no longer
    // computes any Argon2/BLAKE2-derived values on the host.
    const size_t table_bytes = (size_t)(m_blocks / 2) * sizeof(uint32_t);
    if (!ck(nullptr, cudaMalloc(&c->d_table, table_bytes), "cudaMalloc table") ||
        !ck(nullptr, cudaMemsetAsync(c->d_table, 0, 2 * sizeof(uint32_t), c->stream), "zero initial table entries")) {
        bg_destroy(c);
        return nullptr;
    }
    const uint32_t groups_per_slice = ((m_blocks / 4) + 127u) / 128u;
    build_ref_table_kernel<<<groups_per_slice * 2u, 1, 0, c->stream>>>(c->d_table, m_blocks, groups_per_slice);
    if (!ck(nullptr, cudaGetLastError(), "build_ref_table_kernel launch") ||
        !ck(nullptr, cudaStreamSynchronize(c->stream), "build Argon2i reference table")) {
        bg_destroy(c);
        return nullptr;
    }
    size_t lane_bytes = (size_t)m_blocks * 1024;
    size_t fr = 0, tot = 0;
    if (!ck(nullptr, cudaMemGetInfo(&fr, &tot), "cudaMemGetInfo")) { bg_destroy(c); return nullptr; }
    size_t reserve = (size_t)(reserve_mb > 0 ? reserve_mb : 0) * 1048576;
    int max_gpu_lanes = fr > reserve ? (int)((fr - reserve) / lane_bytes) : 0;
    if (max_gpu_lanes > 64) max_gpu_lanes = 64;
    if (lanes > 64) lanes = 64;

    auto add_gpu_lane = [&]() -> bool {
        uint64_t* m = nullptr;
        cudaError_t e = cudaMalloc(&m, lane_bytes);
        if (e != cudaSuccess) { (void)cudaGetLastError(); return false; }
        c->lane_mem.push_back(m);
        c->lane_dev_mem.push_back(m);
        c->lane_is_host.push_back(0);
        ++c->gpu_lanes;
        return true;
    };
    auto add_host_lane = [&]() -> bool {
        void* hmem = nullptr;
        cudaError_t e = cudaHostAlloc(&hmem, lane_bytes, cudaHostAllocMapped | cudaHostAllocPortable);
        if (e != cudaSuccess) {
            char b[256]; snprintf(b, sizeof b, "cudaHostAlloc mapped Argon2 lane (%.0f MiB): %s",
                                  lane_bytes / 1048576.0, cudaGetErrorString(e));
            c->err = b; (void)cudaGetLastError(); return false;
        }
        void* dmem = nullptr;
        e = cudaHostGetDevicePointer(&dmem, hmem, 0);
        if (e != cudaSuccess) {
            cudaFreeHost(hmem);
            char b[256]; snprintf(b, sizeof b, "cudaHostGetDevicePointer for mapped Argon2 lane: %s", cudaGetErrorString(e));
            c->err = b; (void)cudaGetLastError(); return false;
        }
        c->lane_mem.push_back((uint64_t*)hmem);
        c->lane_dev_mem.push_back((uint64_t*)dmem);
        c->lane_is_host.push_back(1);
        ++c->host_lanes;
        return true;
    };

    if (memory_mode == BG_MEMORY_GPU) {
        if (lanes <= 0 || lanes > max_gpu_lanes) lanes = lanes <= 0 ? max_gpu_lanes : lanes;
        for (int l = 0; l < lanes; ++l) if (!add_gpu_lane()) break;
    } else if (memory_mode == BG_MEMORY_HOST) {
        for (int l = 0; l < lanes; ++l) {
            if (!add_host_lane()) {
                std::string why = c->err;
                bg_destroy(c);
                g_create_err = why.empty() ? "failed to allocate mapped pinned Argon2 host memory" : why;
                return nullptr;
            }
        }
    } else { // HYBRID: fill VRAM first, then allocate the remaining lanes in mapped system RAM.
        const int want_gpu = std::min(lanes, max_gpu_lanes);
        for (int l = 0; l < want_gpu; ++l) if (!add_gpu_lane()) break;
        while ((int)c->lane_mem.size() < lanes) {
            if (!add_host_lane()) {
                std::string why = c->err;
                bg_destroy(c);
                g_create_err = why.empty() ? "hybrid mode could not allocate remaining mapped host lanes" : why;
                return nullptr;
            }
        }
    }
    c->lanes = (int)c->lane_mem.size();
    if (c->lanes == 0 || (memory_mode != BG_MEMORY_GPU && c->lanes != lanes)) {
        char b[256];
        snprintf(b, sizeof b, "could not allocate requested Argon2 lanes: mode=%s, requested=%d, GPU free=%.0f MiB, lane=%.0f MiB",
                 memory_mode == BG_MEMORY_HOST ? "host" : (memory_mode == BG_MEMORY_HYBRID ? "hybrid" : "gpu"),
                 lanes, fr / 1048576.0, lane_bytes / 1048576.0);
        g_create_err = b;
        bg_destroy(c);
        return nullptr;
    }
    if (!ck(nullptr, cudaMalloc(&c->d_lanes, sizeof(uint64_t*) * c->lanes), "cudaMalloc lanes") ||
        !ck(nullptr, cudaMemcpy(c->d_lanes, c->lane_dev_mem.data(), sizeof(uint64_t*) * c->lanes, cudaMemcpyHostToDevice), "copy lane device pointers") ||
        !ck(nullptr, cudaMalloc(&c->d_headers, (size_t)c->lanes * 100), "cudaMalloc headers") ||
        !ck(nullptr, cudaMalloc(&c->d_nonces, (size_t)c->lanes * sizeof(uint64_t)), "cudaMalloc nonces") ||
        !ck(nullptr, cudaMalloc(&c->d_valid_flags, (size_t)c->lanes), "cudaMalloc nonce valid flags") ||
        !ck(nullptr, cudaMalloc(&c->d_valid_count, sizeof(uint32_t)), "cudaMalloc valid count") ||
        !ck(nullptr, cudaMalloc(&c->d_job_header, 100), "cudaMalloc job header") ||
        !ck(nullptr, cudaMalloc(&c->d_nonce_cursor, sizeof(uint64_t)), "cudaMalloc nonce cursor") ||
        !ck(nullptr, cudaMalloc(&c->d_nonce_exhausted, sizeof(uint32_t)), "cudaMalloc nonce exhausted") ||
        !ck(nullptr, cudaMalloc(&c->d_stratum_json, 4u << 20), "cudaMalloc Stratum JSON buffer") ||
        !ck(nullptr, cudaMalloc(&c->d_stratum_out, sizeof(BgStratumMessage)), "cudaMalloc Stratum result") ||
        !ck(nullptr, cudaMalloc(&c->d_stratum_format_in, sizeof(BgStratumFormatInput)), "cudaMalloc Stratum format input") ||
        !ck(nullptr, cudaMalloc(&c->d_stratum_format_out, BG_STRATUM_FORMAT_CAPACITY), "cudaMalloc Stratum format output") ||
        !ck(nullptr, cudaMalloc(&c->d_stratum_format_len, sizeof(uint32_t)), "cudaMalloc Stratum format length") ||
        !ck(nullptr, cudaMalloc(&c->d_tags, (size_t)c->lanes * 32), "cudaMalloc tags") ||
        !ck(nullptr, cudaMalloc(&c->d_share_target, 32), "cudaMalloc share target") ||
        !ck(nullptr, cudaMalloc(&c->d_network_target, 32), "cudaMalloc network target") ||
        !ck(nullptr, cudaMalloc(&c->d_share_flags, (size_t)c->lanes), "cudaMalloc share flags") ||
        !ck(nullptr, cudaMalloc(&c->d_block_flags, (size_t)c->lanes), "cudaMalloc block flags") ||
        !ck(nullptr, cudaMalloc(&c->d_candidates, (size_t)c->lanes * sizeof(BgShareCandidate)), "cudaMalloc compact candidates") ||
        !ck(nullptr, cudaMalloc(&c->d_candidate_count, sizeof(uint32_t)), "cudaMalloc candidate count")) {
        bg_destroy(c);
        return nullptr;
    }
    // Page-locked staging buffers make the async H2D/D2H operations below real
    // DMA operations instead of pageable-memory staging performed by the runtime.
    // They are small and independent of the 2 GiB Argon2 lane allocation.
    if (!ck(c, cudaHostAlloc((void**)&c->h_stratum_json, 4u << 20, cudaHostAllocPortable), "pinned Stratum RX buffer") ||
        !ck(c, cudaHostAlloc((void**)&c->h_stratum_out, sizeof(BgStratumMessage), cudaHostAllocPortable), "pinned Stratum parsed result") ||
        !ck(c, cudaHostAlloc((void**)&c->h_stratum_format_in, sizeof(BgStratumFormatInput), cudaHostAllocPortable), "pinned Stratum formatter input") ||
        !ck(c, cudaHostAlloc((void**)&c->h_stratum_format_out, BG_STRATUM_FORMAT_CAPACITY, cudaHostAllocPortable), "pinned Stratum formatter output") ||
        !ck(c, cudaHostAlloc((void**)&c->h_stratum_format_len, sizeof(uint32_t), cudaHostAllocPortable), "pinned Stratum formatter length") ||
        !ck(c, cudaHostAlloc((void**)&c->h_job_stage, sizeof(BgPinnedJobStage), cudaHostAllocPortable), "pinned GPU job input") ||
        !ck(c, cudaHostAlloc((void**)&c->h_valid_count, sizeof(uint32_t), cudaHostAllocPortable), "pinned generated nonce count") ||
        !ck(c, cudaHostAlloc((void**)&c->h_candidate_count, sizeof(uint32_t), cudaHostAllocPortable), "pinned candidate count") ||
        !ck(c, cudaHostAlloc((void**)&c->h_candidates, (size_t)c->lanes * sizeof(BgShareCandidate), cudaHostAllocPortable), "pinned candidate records") ||
        !ck(c, cudaHostAlloc((void**)&c->h_full_headers, (size_t)c->lanes * 100u, cudaHostAllocPortable), "pinned full-hash headers") ||
        !ck(c, cudaHostAlloc((void**)&c->h_full_nonces, (size_t)c->lanes * sizeof(uint64_t), cudaHostAllocPortable), "pinned full-hash nonces") ||
        !ck(c, cudaHostAlloc((void**)&c->h_full_targets, 64u, cudaHostAllocPortable), "pinned full-hash targets") ||
        !ck(c, cudaHostAlloc((void**)&c->h_full_tags, (size_t)c->lanes * 32u, cudaHostAllocPortable), "pinned full-hash tags") ||
        !ck(c, cudaHostAlloc((void**)&c->h_full_flags, (size_t)c->lanes * 2u, cudaHostAllocPortable), "pinned full-hash flags") ||
        !ck(c, cudaHostAlloc((void**)&c->h_compat_init, (size_t)c->lanes * 256u * sizeof(uint64_t), cudaHostAllocPortable), "pinned legacy init blocks") ||
        !ck(c, cudaHostAlloc((void**)&c->h_compat_last, (size_t)c->lanes * 128u * sizeof(uint64_t), cudaHostAllocPortable), "pinned legacy final block")) {
        bg_destroy(c);
        return nullptr;
    }

    c->mem_used = (double)lane_bytes * c->gpu_lanes + table_bytes +
                  (double)c->lanes * (100 + sizeof(uint64_t) + 1 + 32 + 2 + sizeof(BgShareCandidate)) +
                  64.0 + sizeof(uint32_t) + 100.0 + sizeof(uint64_t) + sizeof(uint32_t) + (4u << 20) + sizeof(BgStratumMessage) + sizeof(BgStratumFormatInput) + BG_STRATUM_FORMAT_CAPACITY + sizeof(uint32_t);
    c->host_mem_used = (double)lane_bytes * c->host_lanes;
    return c;
}

BG_API void* bg_create(int device, uint32_t m_blocks, int lanes, int reserve_mb, int chunk)
{
    return bg_create_memory(device, m_blocks, lanes, reserve_mb, chunk, BG_MEMORY_GPU);
}

BG_API int bg_lanes(void* h) { return h ? ((BgCtx*)h)->lanes : 0; }
BG_API const char* bg_name(void* h) { return h ? ((BgCtx*)h)->name.c_str() : ""; }
BG_API int bg_compute_capability(void* h) { return h ? ((BgCtx*)h)->cc : 0; }
BG_API int bg_sm_count(void* h) { return h ? ((BgCtx*)h)->sms : 0; }
BG_API double bg_memory_total(void* h) { return h ? ((BgCtx*)h)->mem_total : 0; }
BG_API double bg_memory_used(void* h) { return h ? ((BgCtx*)h)->mem_used : 0; }
BG_API int bg_gpu_lane_count(void* h) { return h ? ((BgCtx*)h)->gpu_lanes : 0; }
BG_API int bg_host_lane_count(void* h) { return h ? ((BgCtx*)h)->host_lanes : 0; }
BG_API double bg_host_memory_used(void* h) { return h ? ((BgCtx*)h)->host_mem_used : 0; }
BG_API const char* bg_memory_mode_name(void* h) {
    if (!h) return "unknown";
    const BgCtx* c = (const BgCtx*)h;
    return c->memory_mode == BG_MEMORY_HOST ? "host" : (c->memory_mode == BG_MEMORY_HYBRID ? "hybrid" : "gpu");
}
BG_API const char* bg_last_error(void* h) { return h ? ((BgCtx*)h)->err.c_str() : g_create_err.c_str(); }
BG_API const char* bg_kernel_info(void) { return KERNEL_INFO; }

BG_API int bg_parse_stratum(void* h, const char* json_line, uint32_t line_bytes, BgStratumMessage* out)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || !json_line || !out || line_bytes == 0 || line_bytes > (4u << 20)) {
        if (c) c->err = "bg_parse_stratum: invalid JSON line or line exceeds 4 MiB";
        return -1;
    }
    std::lock_guard<std::mutex> lock(c->parse_mtx);
    if (!ck(c, cudaSetDevice(c->dev), "Stratum parser cudaSetDevice")) return -1;
    memcpy(c->h_stratum_json, json_line, line_bytes);
    if (!ck(c, cudaMemcpyAsync(c->d_stratum_json, c->h_stratum_json, line_bytes, cudaMemcpyHostToDevice, c->parse_stream), "copy Stratum JSON H2D")) return -1;
    stratum_json_kernel<<<1, 1, 0, c->parse_stream>>>(c->d_stratum_json, line_bytes, c->d_stratum_out);
    if (!ck(c, cudaGetLastError(), "Stratum JSON kernel launch")) return -1;
    if (!ck(c, cudaMemcpyAsync(c->h_stratum_out, c->d_stratum_out, sizeof(BgStratumMessage), cudaMemcpyDeviceToHost, c->parse_stream), "copy parsed Stratum message D2H") ||
        !ck(c, cudaEventRecord(c->parse_done, c->parse_stream), "record Stratum parser completion") ||
        !ck(c, cudaEventSynchronize(c->parse_done), "wait Stratum parser completion")) return -1;
    memcpy(out, c->h_stratum_out, sizeof(BgStratumMessage));
    return 0;
}

static bool host_copy_cstr(char* dst, size_t capacity, const char* src)
{
    if (!dst || capacity == 0 || !src) return false;
    size_t n = strlen(src);
    if (n >= capacity) return false;
    memcpy(dst, src, n + 1);
    return true;
}

static int bg_format_stratum(void* h, const BgStratumFormatInput& input,
                             char* out, uint32_t out_capacity, uint32_t* out_bytes)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || !out || !out_bytes || out_capacity < BG_STRATUM_FORMAT_CAPACITY) {
        if (c) c->err = "Stratum formatter: invalid context or output buffer (need 2048 bytes)";
        return -1;
    }
    std::lock_guard<std::mutex> lock(c->parse_mtx);
    if (!ck(c, cudaSetDevice(c->dev), "Stratum formatter cudaSetDevice")) return -1;
    memcpy(c->h_stratum_format_in, &input, sizeof(input));
    if (!ck(c, cudaMemcpyAsync(c->d_stratum_format_in, c->h_stratum_format_in, sizeof(input), cudaMemcpyHostToDevice, c->parse_stream), "copy Stratum format input H2D")) return -1;
    stratum_format_kernel<<<1, 1, 0, c->parse_stream>>>(c->d_stratum_format_in, c->d_stratum_format_out,
                                                        BG_STRATUM_FORMAT_CAPACITY, c->d_stratum_format_len);
    if (!ck(c, cudaGetLastError(), "Stratum format kernel launch") ||
        !ck(c, cudaMemcpyAsync(c->h_stratum_format_len, c->d_stratum_format_len, sizeof(uint32_t), cudaMemcpyDeviceToHost, c->parse_stream), "copy Stratum format length D2H") ||
        !ck(c, cudaMemcpyAsync(c->h_stratum_format_out, c->d_stratum_format_out, BG_STRATUM_FORMAT_CAPACITY, cudaMemcpyDeviceToHost, c->parse_stream), "copy formatted Stratum JSON D2H") ||
        !ck(c, cudaEventRecord(c->parse_done, c->parse_stream), "record Stratum formatter completion") ||
        !ck(c, cudaEventSynchronize(c->parse_done), "wait Stratum formatter completion")) return -1;
    *out_bytes = *c->h_stratum_format_len;
    if (*out_bytes == 0 || *out_bytes >= BG_STRATUM_FORMAT_CAPACITY || *out_bytes + 1 > out_capacity) {
        c->err = "Stratum formatter: output overflow or invalid command";
        return -1;
    }
    memcpy(out, c->h_stratum_format_out, *out_bytes + 1);
    return 0;
}

BG_API int bg_format_stratum_login(void* h, const char* address, const char* worker,
                                   char* out, uint32_t out_capacity, uint32_t* out_bytes)
{
    BgStratumFormatInput in{}; in.kind = 1u;
    if (!host_copy_cstr(in.address, sizeof(in.address), address) ||
        !host_copy_cstr(in.worker, sizeof(in.worker), worker)) {
        BgCtx* c = (BgCtx*)h; if (c) c->err = "Stratum login formatter: address or worker is too long";
        return -1;
    }
    return bg_format_stratum(h, in, out, out_capacity, out_bytes);
}

BG_API int bg_format_stratum_submit(void* h, uint64_t id, const char* job_id, uint64_t nonce,
                                    const uint8_t claimed_hash[32], uint32_t include_claimed_hash,
                                    const char* miner_version, char* out, uint32_t out_capacity,
                                    uint32_t* out_bytes)
{
    BgStratumFormatInput in{}; in.kind = 2u; in.id = id; in.nonce = nonce;
    in.include_claimed_hash = include_claimed_hash ? 1u : 0u;
    if (!host_copy_cstr(in.job_id, sizeof(in.job_id), job_id) ||
        !host_copy_cstr(in.miner_version, sizeof(in.miner_version), miner_version) ||
        (in.include_claimed_hash && !claimed_hash)) {
        BgCtx* c = (BgCtx*)h; if (c) c->err = "Stratum submit formatter: invalid or oversized fields";
        return -1;
    }
    if (in.include_claimed_hash) memcpy(in.claimed_hash, claimed_hash, 32);
    return bg_format_stratum(h, in, out, out_capacity, out_bytes);
}

BG_API int bg_set_gpu_job(void* h, const uint8_t* header, uint32_t header_bytes,
                          const uint8_t share_target[32], const uint8_t network_target[32],
                          uint64_t nonce_start, uint64_t nonce_end,
                          uint64_t shard_index, uint64_t shard_count)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || !header || !share_target || !network_target || header_bytes == 0 || header_bytes > 100 ||
        shard_count == 0 || shard_index >= shard_count || nonce_end < nonce_start) {
        if (c) c->err = "bg_set_gpu_job: invalid header, targets, nonce range or shard";
        return -1;
    }
    std::lock_guard<std::mutex> lock(c->work_mtx);
    if (!ck(c, cudaSetDevice(c->dev), "cudaSetDevice job")) return -1;
    uint64_t shard_start = 0, max_index = 0;
    uint32_t empty = 0;
    if (nonce_start > UINT64_MAX - shard_index) empty = 1;
    else {
        shard_start = nonce_start + shard_index;
        if (shard_start > nonce_end) empty = 1;
        else max_index = (nonce_end - shard_start) / shard_count;
    }
    c->gpu_nonce_base = shard_start;
    c->gpu_nonce_stride = shard_count;
    c->gpu_nonce_max_index = max_index;
    c->gpu_nonce_empty = empty;
    c->gpu_job_header_bytes = header_bytes;
    c->h_job_stage->nonce_cursor = 0;
    c->h_job_stage->nonce_exhausted = empty;
    memcpy(c->h_job_stage->header, header, header_bytes);
    memcpy(c->h_job_stage->share_target, share_target, 32);
    memcpy(c->h_job_stage->network_target, network_target, 32);
    if (!ck(c, cudaMemcpyAsync(c->d_job_header, c->h_job_stage->header, header_bytes, cudaMemcpyHostToDevice, c->stream), "copy GPU job header H2D") ||
        !ck(c, cudaMemcpyAsync(c->d_share_target, c->h_job_stage->share_target, 32, cudaMemcpyHostToDevice, c->stream), "copy GPU share target H2D") ||
        !ck(c, cudaMemcpyAsync(c->d_network_target, c->h_job_stage->network_target, 32, cudaMemcpyHostToDevice, c->stream), "copy GPU network target H2D") ||
        !ck(c, cudaMemcpyAsync(c->d_nonce_cursor, &c->h_job_stage->nonce_cursor, sizeof(uint64_t), cudaMemcpyHostToDevice, c->stream), "reset GPU nonce cursor") ||
        !ck(c, cudaMemcpyAsync(c->d_nonce_exhausted, &c->h_job_stage->nonce_exhausted, sizeof(uint32_t), cudaMemcpyHostToDevice, c->stream), "reset GPU nonce exhaustion") ||
        !ck(c, cudaEventRecord(c->work_done, c->stream), "record GPU job install") ||
        !ck(c, cudaEventSynchronize(c->work_done), "wait GPU job install")) return -1;
    return 0;
}

BG_API int bg_hash_next_candidates(void* h, BgShareCandidate* candidates, uint32_t candidate_capacity,
                                   uint32_t* candidate_count, uint32_t* hashes_done, int nlanes,
                                   volatile int* abort, double* ms)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || !candidates || !candidate_count || !hashes_done || nlanes < 1 || nlanes > c->lanes ||
        candidate_capacity < (uint32_t)nlanes || c->gpu_job_header_bytes == 0 || c->gpu_nonce_stride == 0) {
        if (c) c->err = "bg_hash_next_candidates: job not installed or invalid output/lane count";
        return -1;
    }
    *candidate_count = 0;
    *hashes_done = 0;
    if (abort && *abort) return 1;
    std::lock_guard<std::mutex> lock(c->work_mtx);
    auto t0 = std::chrono::steady_clock::now();
    if (!ck(c, cudaSetDevice(c->dev), "cudaSetDevice next nonce batch")) return -1;
    if (!ck(c, cudaMemsetAsync(c->d_candidate_count, 0, sizeof(uint32_t), c->stream), "reset candidate count")) return -1;
    prepare_gpu_nonce_batch_kernel<<<1, 128, 0, c->stream>>>(
        c->d_job_header, c->gpu_job_header_bytes, c->d_headers, c->d_nonces, c->d_valid_flags,
        c->gpu_nonce_base, c->gpu_nonce_stride, c->gpu_nonce_max_index, c->gpu_nonce_empty,
        c->d_nonce_cursor, c->d_nonce_exhausted, c->d_valid_count, (uint32_t)nlanes);
    if (!ck(c, cudaGetLastError(), "prepare GPU nonce batch launch")) return -1;
    if (!ck(c, cudaMemcpyAsync(c->h_valid_count, c->d_valid_count, sizeof(uint32_t), cudaMemcpyDeviceToHost, c->stream), "copy generated nonce count D2H") ||
        !ck(c, cudaEventRecord(c->work_done, c->stream), "record generated nonce count") ||
        !ck(c, cudaEventSynchronize(c->work_done), "wait generated nonce count")) return -1;
    const uint32_t nvalid = *c->h_valid_count;
    *hashes_done = nvalid;
    if (nvalid == 0) {
        if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
        return 0;
    }
    int r = run_range(c, nlanes, 2, c->m_blocks, abort, c->d_headers, c->d_nonces,
                      c->gpu_job_header_bytes, nullptr, c->d_share_target, c->d_network_target,
                      nullptr, nullptr, c->d_candidates, c->d_candidate_count,
                      candidate_capacity, c->d_valid_flags);
    if (r) return r;
    // Count and records are copied together into page-locked staging. Only one
    // completion wait is needed; copy the compact prefix to the caller afterwards.
    if (!ck(c, cudaMemcpyAsync(c->h_candidate_count, c->d_candidate_count, sizeof(uint32_t), cudaMemcpyDeviceToHost, c->stream), "copy GPU candidate count D2H") ||
        !ck(c, cudaMemcpyAsync(c->h_candidates, c->d_candidates, (size_t)nlanes * sizeof(BgShareCandidate), cudaMemcpyDeviceToHost, c->stream), "copy GPU candidate records D2H") ||
        !ck(c, cudaEventRecord(c->work_done, c->stream), "record GPU candidate output") ||
        !ck(c, cudaEventSynchronize(c->work_done), "wait GPU candidate output")) return -1;
    const uint32_t count = *c->h_candidate_count;
    if (count > candidate_capacity || count > (uint32_t)nlanes) {
        c->err = "GPU candidate count exceeded generated nonce batch";
        return -1;
    }
    if (count) memcpy(candidates, c->h_candidates, (size_t)count * sizeof(BgShareCandidate));
    *candidate_count = count;
    if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    return 0;
}

// Keep host synchronization overhead down without turning the whole Argon2 pass into
// one long, non-cancellable kernel.  At the default chunk=32768, queue four dependent
// kernels per sync (131072 blocks); for larger user chunks, reduce the batch accordingly.
// Kernel launches on one stream execute in order, so every block still sees its predecessor.
static uint32_t launch_batch_for_chunk(uint32_t chunk)
{
    if (chunk == 0) chunk = 32768u;
    const uint32_t max_queued_blocks = 131072u;
    uint32_t batch = max_queued_blocks / chunk;
    if (batch < 1u) batch = 1u;
    if (batch > 4u) batch = 4u;
    return batch;
}

static int run_range(BgCtx* c, int nlanes, uint32_t start, uint32_t end, volatile int* abort,
                     const uint8_t* init_headers, const uint64_t* init_nonces,
                     uint32_t header_bytes, uint8_t* out_tags,
                     const uint8_t* share_target, const uint8_t* network_target,
                     uint8_t* out_share_flags, uint8_t* out_block_flags,
                     BgShareCandidate* out_candidates, uint32_t* out_candidate_count,
                     uint32_t candidate_capacity, const uint8_t* valid_flags)
{
    const uint32_t half = c->m_blocks / 2;
    const uint32_t chunk = c->chunk > 0 ? (uint32_t)c->chunk : 32768u;
    const uint32_t batch_limit = launch_batch_for_chunk(chunk);
    while (start < end) {
        uint32_t queued = 0;
        while (start < end && queued < batch_limit) {
            uint32_t e = start + chunk;
            if (e > end || e < start) e = end;
            fill_kernel<<<nlanes, 32, 0, c->stream>>>(c->d_lanes, c->d_table, half, start, e,
                                                           init_headers, init_nonces, header_bytes, out_tags,
                                                           share_target, network_target, out_share_flags, out_block_flags,
                                                           out_candidates, out_candidate_count, candidate_capacity, valid_flags);
            if (!ck(c, cudaGetLastError(), "fill_kernel launch")) {
                // Drain any earlier launches from this batch before the caller retries or destroys the context.
                (void)cudaStreamSynchronize(c->stream);
                return -1;
            }
            start = e;
            ++queued;
        }
        if (!ck(c, cudaEventRecord(c->work_done, c->stream), "record fill_kernel batch") ||
            !ck(c, cudaEventSynchronize(c->work_done), "wait fill_kernel batch")) return -1;
        // Poll only after the queued work has completed; no in-flight kernel can race a new job.
        if (abort && *abort) return 1;
    }
    return 0;
}

BG_API int bg_hash(void* h, const uint64_t* init, uint64_t* last, int nlanes, volatile int* abort, double* ms)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || !init || !last || nlanes < 1 || nlanes > c->lanes) return -1;
    std::lock_guard<std::mutex> lock(c->work_mtx);
    auto t0 = std::chrono::steady_clock::now();
    if (!ck(c, cudaSetDevice(c->dev), "cudaSetDevice legacy hash")) return -1;
    memcpy(c->h_compat_init, init, (size_t)nlanes * 256u * sizeof(uint64_t));
    for (int l = 0; l < nlanes; l++) {
        if (c->lane_is_host[l]) memcpy(c->lane_mem[l], c->h_compat_init + (size_t)l * 256u, 2048);
        else if (!ck(c, cudaMemcpyAsync(c->lane_mem[l], c->h_compat_init + (size_t)l * 256u, 2048, cudaMemcpyHostToDevice, c->stream), "copy init H2D")) return -1;
    }
    int r = run_range(c, nlanes, 2, c->m_blocks, abort);
    if (r) return r;
    for (int l = 0; l < nlanes; l++) {
        if (c->lane_is_host[l]) memcpy(c->h_compat_last + (size_t)l * 128u,
                                       c->lane_mem[l] + (size_t)(c->m_blocks - 1) * 128, 1024);
        else if (!ck(c, cudaMemcpyAsync(c->h_compat_last + (size_t)l * 128u,
                                        c->lane_mem[l] + (size_t)(c->m_blocks - 1) * 128,
                                        1024, cudaMemcpyDeviceToHost, c->stream), "copy last D2H")) return -1;
    }
    if (!ck(c, cudaEventRecord(c->work_done, c->stream), "record legacy hash output") ||
        !ck(c, cudaEventSynchronize(c->work_done), "wait legacy hash output")) return -1;
    memcpy(last, c->h_compat_last, (size_t)nlanes * 128u * sizeof(uint64_t));
    if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    return 0;
}

// Complete per-nonce hash path. The optional checked variant copies the two 32-byte
// targets to the device and asks the final CUDA kernel to filter share/block candidates.
static int bg_hash_full_impl(void* h, const uint8_t* headers, uint32_t header_bytes,
                             const uint64_t* nonces, uint8_t* tags,
                             const uint8_t* share_target, const uint8_t* network_target,
                             uint8_t* share_flags, uint8_t* block_flags,
                             BgShareCandidate* candidates, uint32_t candidate_capacity,
                             uint32_t* candidate_count,
                             int nlanes, volatile int* abort, double* ms)
{
    BgCtx* c = (BgCtx*)h;
    const bool checked = share_target && network_target && share_flags && block_flags && !candidates && !candidate_count;
    const bool compact_args = share_target && network_target && candidates && candidate_count &&
                              !share_flags && !block_flags;
    const bool compact = compact_args && c && nlanes >= 1 &&
                         candidate_capacity >= (uint32_t)nlanes &&
                         candidate_capacity <= (uint32_t)c->lanes;
    const bool any_filter_arg = share_target || network_target || share_flags || block_flags ||
                                candidates || candidate_count || candidate_capacity;
    if (!c || !headers || !nonces || (!tags && !compact) || nlanes < 1 || nlanes > c->lanes ||
        header_bytes == 0 || header_bytes > 100u ||
        (any_filter_arg && !checked && !compact) || (compact_args && !compact)) {
        if (c) c->err = "bg_hash_full: invalid arguments, targets/flags/candidates, salt length, or lane count";
        return -1;
    }
    if (candidate_count) *candidate_count = 0;
    std::lock_guard<std::mutex> lock(c->work_mtx);
    auto t0 = std::chrono::steady_clock::now();
    if (!ck(c, cudaSetDevice(c->dev), "cudaSetDevice")) return -1;
    const size_t header_copy_bytes = (size_t)nlanes * header_bytes;
    memcpy(c->h_full_headers, headers, header_copy_bytes);
    memcpy(c->h_full_nonces, nonces, (size_t)nlanes * sizeof(uint64_t));
    if (!ck(c, cudaMemcpyAsync(c->d_headers, c->h_full_headers, header_copy_bytes, cudaMemcpyHostToDevice, c->stream), "copy headers H2D") ||
        !ck(c, cudaMemcpyAsync(c->d_nonces, c->h_full_nonces, (size_t)nlanes * sizeof(uint64_t), cudaMemcpyHostToDevice, c->stream), "copy nonces H2D")) return -1;
    const uint8_t* d_share = nullptr;
    const uint8_t* d_network = nullptr;
    uint8_t* d_sf = nullptr;
    uint8_t* d_bf = nullptr;
    BgShareCandidate* d_cands = nullptr;
    uint32_t* d_cand_count = nullptr;
    uint32_t cand_capacity = 0;
    if (checked || compact) {
        memcpy(c->h_full_targets, share_target, 32);
        memcpy(c->h_full_targets + 32, network_target, 32);
        if (!ck(c, cudaMemcpyAsync(c->d_share_target, c->h_full_targets, 32, cudaMemcpyHostToDevice, c->stream), "copy share target H2D") ||
            !ck(c, cudaMemcpyAsync(c->d_network_target, c->h_full_targets + 32, 32, cudaMemcpyHostToDevice, c->stream), "copy network target H2D")) return -1;
        d_share = c->d_share_target;
        d_network = c->d_network_target;
    }
    if (checked) {
        d_sf = c->d_share_flags;
        d_bf = c->d_block_flags;
    }
    if (compact) {
        if (!ck(c, cudaMemsetAsync(c->d_candidate_count, 0, sizeof(uint32_t), c->stream), "reset candidate count")) return -1;
        d_cands = c->d_candidates;
        d_cand_count = c->d_candidate_count;
        cand_capacity = candidate_capacity;
    }
    uint8_t* d_out_tags = compact ? nullptr : c->d_tags;
    int r = run_range(c, nlanes, 2, c->m_blocks, abort, c->d_headers, c->d_nonces,
                      header_bytes, d_out_tags, d_share, d_network, d_sf, d_bf,
                      d_cands, d_cand_count, cand_capacity);
    if (r) return r;
    if (tags && !ck(c, cudaMemcpyAsync(c->h_full_tags, c->d_tags, (size_t)nlanes * 32, cudaMemcpyDeviceToHost, c->stream), "copy tags D2H")) return -1;
    if (checked &&
        (!ck(c, cudaMemcpyAsync(c->h_full_flags, c->d_share_flags, (size_t)nlanes, cudaMemcpyDeviceToHost, c->stream), "copy share flags D2H") ||
         !ck(c, cudaMemcpyAsync(c->h_full_flags + c->lanes, c->d_block_flags, (size_t)nlanes, cudaMemcpyDeviceToHost, c->stream), "copy block flags D2H"))) return -1;
    if (compact &&
        (!ck(c, cudaMemcpyAsync(c->h_candidate_count, c->d_candidate_count, sizeof(uint32_t), cudaMemcpyDeviceToHost, c->stream), "copy candidate count D2H") ||
         !ck(c, cudaMemcpyAsync(c->h_candidates, c->d_candidates, (size_t)nlanes * sizeof(BgShareCandidate), cudaMemcpyDeviceToHost, c->stream), "copy compact candidates D2H"))) return -1;
    if (!ck(c, cudaEventRecord(c->work_done, c->stream), "record full hash output") ||
        !ck(c, cudaEventSynchronize(c->work_done), "wait full hash output")) return -1;
    if (tags) memcpy(tags, c->h_full_tags, (size_t)nlanes * 32);
    if (checked) {
        memcpy(share_flags, c->h_full_flags, (size_t)nlanes);
        memcpy(block_flags, c->h_full_flags + c->lanes, (size_t)nlanes);
    }
    if (compact) {
        const uint32_t count = *c->h_candidate_count;
        if (count > candidate_capacity || count > (uint32_t)nlanes) {
            c->err = "GPU compact candidate count exceeded output capacity";
            return -1;
        }
        if (count) memcpy(candidates, c->h_candidates, (size_t)count * sizeof(BgShareCandidate));
        *candidate_count = count;
    }
    if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    return 0;
}

BG_API int bg_hash_full(void* h, const uint8_t* headers, uint32_t header_bytes,
                        const uint64_t* nonces, uint8_t* tags, int nlanes,
                        volatile int* abort, double* ms)
{
    return bg_hash_full_impl(h, headers, header_bytes, nonces, tags,
                             nullptr, nullptr, nullptr, nullptr, nullptr, 0, nullptr, nlanes, abort, ms);
}

BG_API int bg_hash_full_checked(void* h, const uint8_t* headers, uint32_t header_bytes,
                                const uint64_t* nonces,
                                const uint8_t share_target[32], const uint8_t network_target[32],
                                uint8_t* tags, uint8_t* share_flags, uint8_t* block_flags,
                                int nlanes, volatile int* abort, double* ms)
{
    return bg_hash_full_impl(h, headers, header_bytes, nonces, tags,
                             share_target, network_target, share_flags, block_flags,
                             nullptr, 0, nullptr, nlanes, abort, ms);
}

BG_API int bg_hash_full_candidates(void* h, const uint8_t* headers, uint32_t header_bytes,
                                   const uint64_t* nonces,
                                   const uint8_t share_target[32], const uint8_t network_target[32],
                                   BgShareCandidate* candidates, uint32_t candidate_capacity,
                                   uint32_t* candidate_count, int nlanes,
                                   volatile int* abort, double* ms)
{
    if (!candidates || !candidate_count) return -1;
    return bg_hash_full_impl(h, headers, header_bytes, nonces, nullptr,
                             share_target, network_target, nullptr, nullptr,
                             candidates, candidate_capacity, candidate_count, nlanes, abort, ms);
}

BG_API int bg_test_blake2b(int device, uint8_t out64[64])
{
    if (!out64) return -1;
    uint8_t* d_out = nullptr;
    cudaError_t e = cudaSetDevice(device);
    if (e != cudaSuccess) return -1;
    e = cudaMalloc(&d_out, 64);
    if (e != cudaSuccess) return -1;
    b2b_known_answer_kernel<<<1, 1>>>(d_out);
    e = cudaGetLastError();
    if (e == cudaSuccess) e = cudaDeviceSynchronize();
    if (e == cudaSuccess) e = cudaMemcpy(out64, d_out, 64, cudaMemcpyDeviceToHost);
    cudaFree(d_out);
    return e == cudaSuccess ? 0 : -1;
}

BG_API int bg_profile(void* h, int nlanes, double* ms_i_part, double* ms_d_part)
{
    BgCtx* c = (BgCtx*)h;
    if (!c || nlanes < 1 || nlanes > c->lanes) return -1;
    cudaSetDevice(c->dev);
    std::vector<uint64_t> init((size_t)nlanes * 256);
    for (size_t i = 0; i < init.size(); i++) init[i] = 0x9e3779b97f4a7c15ULL * (i + 1);
    for (int l = 0; l < nlanes; l++) {
        if (c->lane_is_host[l]) memcpy(c->lane_mem[l], init.data() + (size_t)l * 256, 2048);
        else if (!ck(c, cudaMemcpy(c->lane_mem[l], init.data() + (size_t)l * 256, 2048, cudaMemcpyHostToDevice), "copy init")) return -1;
    }
    const uint32_t half = c->m_blocks / 2;
    auto t0 = std::chrono::steady_clock::now();
    if (run_range(c, nlanes, 2, half, nullptr)) return -1;
    auto t1 = std::chrono::steady_clock::now();
    if (run_range(c, nlanes, half, c->m_blocks, nullptr)) return -1;
    auto t2 = std::chrono::steady_clock::now();
    if (ms_i_part) *ms_i_part = std::chrono::duration<double, std::milli>(t1 - t0).count();
    if (ms_d_part) *ms_d_part = std::chrono::duration<double, std::milli>(t2 - t1).count();
    return 0;
}
