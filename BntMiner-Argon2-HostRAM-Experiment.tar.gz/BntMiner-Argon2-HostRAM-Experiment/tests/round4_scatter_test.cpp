#include <array>
#include <cstdint>
#include <cstdio>
#include <random>

struct Q { uint64_t a, b, c, d; };

static inline uint64_t rotr64(uint64_t x, unsigned n) {
    return (x >> n) | (x << (64 - n));
}
static inline uint64_t blamka(uint64_t x, uint64_t y) {
    const uint64_t m = uint64_t(uint32_t(x)) * uint64_t(uint32_t(y));
    return x + y + 2 * m;
}
static inline void G(uint64_t& a, uint64_t& b, uint64_t& c, uint64_t& d) {
    a = blamka(a, b); d = rotr64(d ^ a, 32);
    c = blamka(c, d); b = rotr64(b ^ c, 24);
    a = blamka(a, b); d = rotr64(d ^ a, 16);
    c = blamka(c, d); b = rotr64(b ^ c, 63);
}

// Models the current CUDA implementation: after the diagonal G, inverse shuffles
// rotate b/c/d back onto the lane that owns each logical shared-memory word.
static std::array<Q, 4> old_round(std::array<Q, 4> v) {
    for (auto& q : v) G(q.a, q.b, q.c, q.d);
    const auto col = v;
    for (int k = 0; k < 4; ++k) {
        Q q { col[k].a, col[(k + 1) & 3].b,
              col[(k + 2) & 3].c, col[(k + 3) & 3].d };
        G(q.a, q.b, q.c, q.d);
        v[k] = q;
    }
    const auto diag = v;
    std::array<Q, 4> out{};
    for (int k = 0; k < 4; ++k) {
        out[k] = Q{diag[k].a, diag[(k + 3) & 3].b,
                    diag[(k + 2) & 3].c, diag[(k + 1) & 3].d};
    }
    return out;
}

// Models the CUDA optimization: no inverse shuffles; b/c/d are scattered into
// the logical slots of lanes k+1/k+2/k+3, respectively.
static std::array<Q, 4> scatter_round(std::array<Q, 4> v) {
    for (auto& q : v) G(q.a, q.b, q.c, q.d);
    const auto col = v;
    for (int k = 0; k < 4; ++k) {
        Q q { col[k].a, col[(k + 1) & 3].b,
              col[(k + 2) & 3].c, col[(k + 3) & 3].d };
        G(q.a, q.b, q.c, q.d);
        v[k] = q;
    }
    const auto diag = v;
    std::array<Q, 4> out{};
    for (int k = 0; k < 4; ++k) {
        out[k].a = diag[k].a;
        out[(k + 1) & 3].b = diag[k].b;
        out[(k + 2) & 3].c = diag[k].c;
        out[(k + 3) & 3].d = diag[k].d;
    }
    return out;
}

static bool same(const std::array<Q, 4>& a, const std::array<Q, 4>& b) {
    for (int k = 0; k < 4; ++k)
        if (a[k].a != b[k].a || a[k].b != b[k].b ||
            a[k].c != b[k].c || a[k].d != b[k].d) return false;
    return true;
}

static int SP(int w, int pad) { return w + ((w >> 4) * pad); }

static bool check_scatter_destinations(int pad) {
    // For every lane-group and each of the b/c/d store instructions, the scatter
    // destinations must be a permutation of the original logical slot set.
    for (int row = 0; row < 8; ++row) {
        bool old_row[3][256] = {}, new_row[3][256] = {};
        bool old_col[3][256] = {}, new_col[3][256] = {};
        for (int k = 0; k < 4; ++k) {
            const int kr[3] = {(k + 1) & 3, (k + 2) & 3, (k + 3) & 3};
            for (int j = 0; j < 3; ++j) {
                old_row[j][SP(16 * row + k + 4 * (j + 1), pad)] = true;
                new_row[j][SP(16 * row + kr[j] + 4 * (j + 1), pad)] = true;
                const int cw = 2 * row + (k & 1) + 16 * (k >> 1);
                const int cw_dst = 2 * row + (kr[j] & 1) + 16 * (kr[j] >> 1);
                old_col[j][SP(cw + 32 * (j + 1), pad)] = true;
                new_col[j][SP(cw_dst + 32 * (j + 1), pad)] = true;
            }
        }
        for (int j = 0; j < 3; ++j) for (int i = 0; i < 256; ++i) {
            if (old_row[j][i] != new_row[j][i] || old_col[j][i] != new_col[j][i]) {
                std::fprintf(stderr, "pad=%d row=%d output=%d store-address set differs at %d\n", pad, row, j, i);
                return false;
            }
        }
    }
    return true;
}

int main() {
    std::mt19937_64 rng(0xB17B10CULL);
    for (int n = 0; n < 100000; ++n) {
        std::array<Q, 4> in{};
        for (auto& q : in) q = Q{rng(), rng(), rng(), rng()};
        if (!same(old_round(in), scatter_round(in))) {
            std::fprintf(stderr, "round scatter mismatch at vector %d\n", n);
            return 1;
        }
    }
    if (!check_scatter_destinations(2) || !check_scatter_destinations(4)) return 1;
    std::puts("100000 BlaMka round vectors: inverse-shuffle and scatter-store outputs match");
    std::puts("pad=2/pad=4 row-store address sets preserved: OK");
    return 0;
}
