#include <cstdint>
#include <cstdio>
#include <vector>

static bool check_pad(int pad) {
    const int smem_words = 128 + 8 * pad;
    auto sp = [pad](int w) { return w + (w >> 4) * pad; };
    std::vector<int> owner((size_t)smem_words, -1);

    for (int w = 0; w < 128; ++w) {
        const int p = sp(w);
        if (p < 0 || p >= smem_words || owner[(size_t)p] != -1) {
            std::fprintf(stderr, "pad=%d: invalid/colliding logical word %d -> %d\n", pad, w, p);
            return false;
        }
        owner[(size_t)p] = w;
    }

    // `s2[sg0]` and `s2[sg1]` are 16-byte ulonglong2 transactions: starts must be
    // 16-byte aligned and both qwords must remain inside shared memory.
    std::vector<int> vector_owner((size_t)smem_words / 2, -1);
    for (int t = 0; t < 32; ++t) {
        const int starts[2] = {sp(2 * t), sp(64 + 2 * t)};
        for (int b = 0; b < 2; ++b) {
            const int p = starts[b];
            if ((p & 1) != 0 || p + 1 >= smem_words) {
                std::fprintf(stderr, "pad=%d: misaligned/out-of-range vector t=%d b=%d p=%d\n", pad, t, b, p);
                return false;
            }
            const int slot = p / 2;
            if (vector_owner[(size_t)slot] != -1) {
                std::fprintf(stderr, "pad=%d: colliding vector slot %d\n", pad, slot);
                return false;
            }
            vector_owner[(size_t)slot] = t * 2 + b;
        }
    }
    return true;
}

int main() {
    if (!check_pad(2) || !check_pad(4)) return 1;
    std::puts("Shared-memory pad=2 and pad=4 index/alignment bounds: OK");
    return 0;
}
