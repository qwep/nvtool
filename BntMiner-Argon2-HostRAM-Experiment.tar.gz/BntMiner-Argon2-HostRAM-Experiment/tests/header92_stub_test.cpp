// Smoke test for the production 92-byte Blocknet PoW header stride in the CPU GPU stub.
#include "../gpu/bnt_gpu.h"
#include "../src/argon_ref.h"
#include <array>
#include <cstdio>
#include <cstring>

int main() {
    constexpr uint32_t m = 8;
    std::array<uint8_t, 92> header{};
    for (size_t i = 0; i < header.size(); ++i) header[i] = static_cast<uint8_t>(i * 37u + 11u);
    const uint64_t nonce = 0x123456789abcdef0ULL;
    std::array<uint8_t, 32> expected{}, actual{};
    if (!bnt::pow_hash_cpu(header.data(), header.size(), nonce, m, expected.data())) {
        std::fprintf(stderr, "CPU reference failed\n");
        return 1;
    }
    void* ctx = bg_create(0, m, 1, 0, 5);
    if (!ctx) {
        std::fprintf(stderr, "stub context creation failed\n");
        return 1;
    }
    double ms = 0.0;
    const int rc = bg_hash_full(ctx, header.data(), static_cast<uint32_t>(header.size()),
                                &nonce, actual.data(), 1, nullptr, &ms);
    bg_destroy(ctx);
    if (rc != 0 || std::memcmp(expected.data(), actual.data(), expected.size()) != 0) {
        std::fprintf(stderr, "92-byte header stride failed\n");
        return 1;
    }
    std::puts("92-byte Blocknet header stride: OK");
    return 0;
}
