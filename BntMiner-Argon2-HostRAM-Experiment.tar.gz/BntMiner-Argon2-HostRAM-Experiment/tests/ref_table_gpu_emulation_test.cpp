// Portable emulation of build_ref_table_kernel(): verify the GPU address-table
// mapping and scalar Argon2 compression against the independent CPU reference.
#include "argon_ref.h"
#include <algorithm>
#include <cstdio>
#include <vector>

static inline void G(uint64_t& a, uint64_t& b, uint64_t& c, uint64_t& d)
{
    a = bnt::fBlaMka(a, b);
    d = bnt::rotr64(d ^ a, 32);
    c = bnt::fBlaMka(c, d);
    b = bnt::rotr64(b ^ c, 24);
    a = bnt::fBlaMka(a, b);
    d = bnt::rotr64(d ^ a, 16);
    c = bnt::fBlaMka(c, d);
    b = bnt::rotr64(b ^ c, 63);
}

static void round16(uint64_t* v)
{
    G(v[0], v[4], v[8], v[12]);
    G(v[1], v[5], v[9], v[13]);
    G(v[2], v[6], v[10], v[14]);
    G(v[3], v[7], v[11], v[15]);
    G(v[0], v[5], v[10], v[15]);
    G(v[1], v[6], v[11], v[12]);
    G(v[2], v[7], v[8], v[13]);
    G(v[3], v[4], v[9], v[14]);
}

static void compress_zero_inplace(uint64_t* block)
{
    uint64_t r[128];
    for (int i = 0; i < 128; ++i) r[i] = block[i];
    for (int row = 0; row < 8; ++row) round16(block + 16 * row);
    for (int col = 0; col < 8; ++col) {
        uint64_t v[16];
        for (int row = 0; row < 8; ++row) {
            v[2 * row] = block[16 * row + 2 * col];
            v[2 * row + 1] = block[16 * row + 2 * col + 1];
        }
        round16(v);
        for (int row = 0; row < 8; ++row) {
            block[16 * row + 2 * col] = v[2 * row];
            block[16 * row + 2 * col + 1] = v[2 * row + 1];
        }
    }
    for (int i = 0; i < 128; ++i) block[i] ^= r[i];
}

static uint32_t emu_ref_index(uint32_t i, uint32_t j1)
{
    const uint32_t area = i - 1;
    const uint32_t x = (uint32_t)(((uint64_t)j1 * j1) >> 32);
    const uint32_t y = (uint32_t)(((uint64_t)area * x) >> 32);
    return area - 1 - y;
}

static void emulate_gpu_table(uint32_t m_blocks, std::vector<uint32_t>& table)
{
    const uint32_t seg = m_blocks / 4;
    const uint32_t groups_per_slice = (seg + 127u) / 128u;
    table.assign(m_blocks / 2, 0);
    for (uint32_t slice = 0; slice < 2; ++slice) {
        for (uint32_t group = 0; group < groups_per_slice; ++group) {
            uint64_t input[128] = {};
            input[2] = slice;
            input[3] = m_blocks;
            input[4] = 1;
            input[5] = 2;
            input[6] = group + 1;
            compress_zero_inplace(input);
            compress_zero_inplace(input);

            uint32_t begin = group * 128;
            uint32_t end = std::min(begin + 128, seg);
            if (slice == 0 && begin < 2) begin = 2;
            for (uint32_t idx = begin; idx < end; ++idx) {
                const uint32_t i = slice * seg + idx;
                table[i] = emu_ref_index(i, (uint32_t)input[idx & 127u]);
            }
        }
    }
}

int main()
{
    const uint32_t sizes[] = {8, 64, 1024, 65536, 2097152};
    for (uint32_t m : sizes) {
        std::vector<uint32_t> cpu(m / 2), gpu_emulated;
        bnt::ref_table(m, cpu.data());
        emulate_gpu_table(m, gpu_emulated);
        if (cpu != gpu_emulated) {
            size_t i = 0;
            while (i < cpu.size() && cpu[i] == gpu_emulated[i]) ++i;
            std::fprintf(stderr, "Argon2i table mismatch at m=%u, entry=%zu: CPU=%u GPU-emulation=%u\n",
                         m, i, i < cpu.size() ? cpu[i] : 0u, i < gpu_emulated.size() ? gpu_emulated[i] : 0u);
            return 1;
        }
        std::printf("Argon2i address table m=%u: %zu entries match\n", m, cpu.size());
    }
    std::puts("GPU address-table kernel emulation: ALL OK");
    return 0;
}
