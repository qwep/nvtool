// bg_stub.cpp - CPU stand-in for bgpu.dll (cloud build checks of the host code only).
#include "../gpu/bnt_gpu.h"
#include "../src/argon_ref.h"
#include "../src/json.h"
#include <cstring>
#include <limits>
#include <vector>
#include <string>
#include <chrono>
struct Stub {
  uint32_t m; int lanes; std::vector<uint32_t> table; std::vector<std::vector<uint64_t>> mem;
  std::vector<uint8_t> job_header; uint8_t share_target[32]{}, network_target[32]{};
  uint64_t nonce_base=0, nonce_stride=1, nonce_max_index=0, nonce_cursor=0;
  bool nonce_empty=true, has_job=false;
};
static std::string stub_str(const json::Value* o, const char* key) {
  const json::Value* v=o?o->get(key):nullptr;
  return v && (v->is_str() || v->is_num()) ? v->s : std::string();
}
static uint64_t stub_u64(const json::Value* o, const char* key, uint64_t def=0) {
  std::string s=stub_str(o,key); if(s.empty()) return def; return strtoull(s.c_str(),nullptr,10);
}
static bool stub_hex(const std::string& s, uint8_t* out, size_t n) {
  if(s.size()!=n*2) return false;
  auto hv=[](char c)->int { if(c>='0'&&c<='9')return c-'0'; if(c>='a'&&c<='f')return c-'a'+10; if(c>='A'&&c<='F')return c-'A'+10; return -1; };
  for(size_t i=0;i<n;i++){ int a=hv(s[2*i]),b=hv(s[2*i+1]); if(a<0||b<0)return false; out[i]=(uint8_t)((a<<4)|b); }
  return true;
}
extern "C" {
int bg_device_count(void) { return 1; }
void* bg_create(int, uint32_t m, int lanes, int, int) { Stub* s = new Stub(); s->m = m; s->lanes = lanes > 0 ? lanes : 1; if (s->lanes > 4) s->lanes = 4;
  s->table.resize(m / 2); bnt::ref_table(m, s->table.data()); s->mem.resize(s->lanes); return s; }
void* bg_create_memory(int d, uint32_t m, int lanes, int reserve, int chunk, int) { return bg_create(d, m, lanes, reserve, chunk); }
int bg_gpu_lane_count(void* h) { return ((Stub*)h)->lanes; }
int bg_host_lane_count(void*) { return 0; }
double bg_host_memory_used(void*) { return 0; }
const char* bg_memory_mode_name(void*) { return "cpu-stub"; }
void bg_destroy(void* h) { delete (Stub*)h; }
int bg_lanes(void* h) { return ((Stub*)h)->lanes; }
const char* bg_name(void*) { return "CPU stub"; }
int bg_compute_capability(void*) { return 0; }
int bg_sm_count(void*) { return 0; }
double bg_memory_total(void*) { return 0; }
double bg_memory_used(void*) { return 0; }
const char* bg_last_error(void*) { return ""; }
const char* bg_kernel_info(void) { return "cpu stub"; }
int bg_hash(void* h, const uint64_t* init, uint64_t* last, int n, volatile int* abort, double* ms) {
  Stub* s = (Stub*)h; auto t0 = std::chrono::steady_clock::now();
  for (int l = 0; l < n; l++) { auto& mem = s->mem[l]; mem.assign((size_t)s->m * 128, 0); memcpy(mem.data(), init + l * 256, 2048);
    for (uint32_t i = 2; i < s->m; i++) { const uint64_t* p = &mem[(size_t)(i - 1) * 128];
      uint32_t r = i < s->m / 2 ? s->table[i] : bnt::ref_index(i, (uint32_t)p[0]); bnt::compress(p, &mem[(size_t)r * 128], &mem[(size_t)i * 128]);
      if (abort && *abort && (i & 65535) == 0) return 1; }
    memcpy(last + l * 128, &mem[(size_t)(s->m - 1) * 128], 1024); std::vector<uint64_t>().swap(mem); }
  if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count(); return 0; }
int bg_hash_full(void* h, const uint8_t* headers, uint32_t header_bytes,
                 const uint64_t* nonces, uint8_t* tags, int n,
                 volatile int* abort, double* ms) {
  Stub* s = (Stub*)h; auto t0 = std::chrono::steady_clock::now();
  if (!headers || !nonces || !tags || header_bytes == 0 || header_bytes > 100) return -1;
  for (int l = 0; l < n; ++l) {
    if (abort && *abort) return 1;
    if (!bnt::pow_hash_cpu(headers + (size_t)l * header_bytes, header_bytes, nonces[l], s->m, tags + (size_t)l * 32)) return -1;
  }
  if (ms) *ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
  return 0;
}
int bg_hash_full_checked(void* h, const uint8_t* headers, uint32_t header_bytes,
                         const uint64_t* nonces, const uint8_t share_target[32], const uint8_t network_target[32],
                         uint8_t* tags, uint8_t* share_flags, uint8_t* block_flags, int n,
                         volatile int* abort, double* ms) {
  if (!share_target || !network_target || !share_flags || !block_flags) return -1;
  int r = bg_hash_full(h, headers, header_bytes, nonces, tags, n, abort, ms);
  if (r != 0) return r;
  bool net_nonzero = false; for (int i = 0; i < 32; ++i) net_nonzero |= network_target[i] != 0;
  for (int l = 0; l < n; ++l) {
    const uint8_t* tag = tags + (size_t)l * 32;
    share_flags[l] = memcmp(tag, share_target, 32) <= 0 ? 1u : 0u;
    block_flags[l] = net_nonzero && memcmp(tag, network_target, 32) <= 0 ? 1u : 0u;
  }
  return 0;
}
int bg_hash_full_candidates(void* h, const uint8_t* headers, uint32_t header_bytes,
                            const uint64_t* nonces, const uint8_t share_target[32],
                            const uint8_t network_target[32], BgShareCandidate* candidates,
                            uint32_t candidate_capacity, uint32_t* candidate_count, int n,
                            volatile int* abort, double* ms) {
  if (!candidate_count || !candidates || !share_target || !network_target || n < 1 ||
      candidate_capacity < (uint32_t)n) return -1;
  *candidate_count = 0;
  std::vector<uint8_t> tags((size_t)n * 32);
  int r = bg_hash_full(h, headers, header_bytes, nonces, tags.data(), n, abort, ms);
  if (r != 0) return r;
  bool net_nonzero = false; for (int i = 0; i < 32; ++i) net_nonzero |= network_target[i] != 0;
  for (int l = 0; l < n; ++l) {
    const uint8_t* tag = tags.data() + (size_t)l * 32;
    const bool share = memcmp(tag, share_target, 32) <= 0;
    const bool block = net_nonzero && memcmp(tag, network_target, 32) <= 0;
    if (!share && !block) continue;
    BgShareCandidate& c = candidates[(*candidate_count)++];
    c.nonce = nonces[l]; c.lane_index = (uint32_t)l;
    c.flags = (share ? BG_CANDIDATE_SHARE : 0u) | (block ? BG_CANDIDATE_BLOCK : 0u);
    memcpy(c.hash, tag, 32);
  }
  return 0;
}
int bg_parse_stratum(void*, const char* line, uint32_t len, BgStratumMessage* out) {
  if(!line||!out||!len||len>(4u<<20)) return -1;
  *out = BgStratumMessage{};
  json::Value root;
  if(!json::parse(std::string(line,len),root)||!root.is_obj()) return 0;
  out->valid=1;
  std::string method=stub_str(&root,"method");
  snprintf(out->method,sizeof(out->method),"%s",method.c_str());
  const json::Value* id=root.get("id");
  if(id&&id->is_num()){ out->id=strtoll(id->s.c_str(),nullptr,10); out->has_id=1; }
  std::string status=stub_str(&root,"status");
  snprintf(out->status,sizeof(out->status),"%s",status.c_str());
  out->status_ok=(status=="ok"||status=="OK");
  const json::Value* error=root.get("error"); out->has_error=error&&!error->is_null();
  const json::Value* params=root.get("params");
  if(params&&params->is_obj()) {
    std::string v=stub_str(params,"job_id"); snprintf(out->job_id,sizeof(out->job_id),"%s",v.c_str());
    v=stub_str(params,"header_base"); if(stub_hex(v,out->header,92)) out->header_len=92;
    v=stub_str(params,"target"); out->has_target=stub_hex(v,out->target,32);
    v=stub_str(params,"network_target"); out->has_network_target=stub_hex(v,out->network_target,32);
    const json::Value* x=params->get("height"); if(x){out->height=stub_u64(params,"height");out->has_height=1;}
    x=params->get("difficulty"); if(x){out->difficulty=stub_u64(params,"difficulty");out->has_difficulty=1;}
    x=params->get("nonce_start"); if(x){out->nonce_start=stub_u64(params,"nonce_start");out->has_nonce_start=1;}
    x=params->get("nonce_end"); if(x){out->nonce_end=stub_u64(params,"nonce_end");out->has_nonce_end=1;}
    v=stub_str(params,"message"); snprintf(out->message,sizeof(out->message),"%s",v.c_str());
    v=stub_str(params,"kind"); snprintf(out->kind,sizeof(out->kind),"%s",v.c_str());
  } else if(params&&params->is_str()) {
    snprintf(out->message,sizeof(out->message),"%s",params->s.c_str());
  }
  const json::Value* result=root.get("result");
  if(result&&result->is_obj()) {
    const json::Value* a=result->get("accepted"); if(a&&a->is_bool()){out->accepted=a->b;out->has_accepted=1;}
    const json::Value* pv=result->get("protocol_version"); if(pv){out->protocol_version=(uint32_t)stub_u64(result,"protocol_version");out->has_protocol_version=1;}
    const json::Value* caps=result->get("capabilities"); if(caps&&caps->is_arr()) for(const auto& c:caps->arr) if(c.is_str()&&c.s=="submit_claimed_hash") out->can_submit_claimed_hash=1;
  }
  if(method=="job") out->type=BG_STRATUM_JOB;
  else if(method=="notification") out->type=BG_STRATUM_NOTIFICATION;
  else if(out->has_id) out->type=BG_STRATUM_RESPONSE;
  return 0;
}
int bg_format_stratum_login(void*, const char* address, const char* worker,
                            char* out, uint32_t cap, uint32_t* out_bytes) {
  if(!address||!worker||!out||!out_bytes||cap<BG_STRATUM_FORMAT_CAPACITY)return -1;
  std::string msg="{\"id\":1,\"method\":\"login\",\"params\":{\"address\":"+json::quote(address)+
    ",\"worker\":"+json::quote(worker)+",\"protocol_version\":2,\"capabilities\":[\"login_negotiation\",\"share_validation_status\",\"submit_claimed_hash\"]}}";
  if(msg.size()+1>cap)return -1; memcpy(out,msg.c_str(),msg.size()+1);*out_bytes=(uint32_t)msg.size();return 0;
}
int bg_format_stratum_submit(void*, uint64_t id, const char* job_id, uint64_t nonce,
                             const uint8_t claimed_hash[32], uint32_t include_hash,
                             const char* miner_version, char* out, uint32_t cap, uint32_t* out_bytes) {
  if(!job_id||!miner_version||!out||!out_bytes||cap<BG_STRATUM_FORMAT_CAPACITY||(include_hash&&!claimed_hash))return -1;
  std::string msg="{\"id\":"+std::to_string(id)+",\"method\":\"submit\",\"params\":{\"job_id\":"+json::quote(job_id)+
    ",\"nonce\":"+std::to_string(nonce);
  if(include_hash){static const char h[]="0123456789abcdef";std::string hex;hex.reserve(64);for(int i=0;i<32;i++){hex.push_back(h[claimed_hash[i]>>4]);hex.push_back(h[claimed_hash[i]&15]);}msg+=",\"claimed_hash\":"+json::quote(hex);}
  msg+=",\"miner_version\":"+json::quote(miner_version)+"}}";
  if(msg.size()+1>cap)return -1;memcpy(out,msg.c_str(),msg.size()+1);*out_bytes=(uint32_t)msg.size();return 0;
}
int bg_set_gpu_job(void* h,const uint8_t* header,uint32_t hb,const uint8_t share[32],const uint8_t net[32],
                   uint64_t start,uint64_t end,uint64_t shard,uint64_t shards) {
  Stub* s=(Stub*)h; if(!s||!header||!share||!net||!hb||hb>100||!shards||shard>=shards||end<start)return -1;
  s->job_header.assign(header,header+hb); memcpy(s->share_target,share,32);memcpy(s->network_target,net,32);
  s->nonce_stride=shards;s->nonce_cursor=0;s->nonce_empty=false;
  if(start>UINT64_MAX-shard){s->nonce_empty=true;s->nonce_base=0;s->nonce_max_index=0;}
  else {s->nonce_base=start+shard;if(s->nonce_base>end)s->nonce_empty=true;else s->nonce_max_index=(end-s->nonce_base)/shards;}
  s->has_job=true;return 0;
}
int bg_hash_next_candidates(void* h,BgShareCandidate* c,uint32_t cap,uint32_t* count,uint32_t* done,int n,
                            volatile int* abort,double* ms) {
  Stub* s=(Stub*)h; if(!s||!c||!count||!done||!s->has_job||n<1||n>s->lanes||cap<(uint32_t)n)return -1;
  *count=0;*done=0;if(abort&&*abort)return 1;auto t0=std::chrono::steady_clock::now();
  if(s->nonce_empty||s->nonce_cursor>s->nonce_max_index){if(ms)*ms=0;return 0;}
  uint64_t first=s->nonce_cursor;
  uint64_t rem=s->nonce_max_index-first;
  uint32_t take=rem>=(uint64_t)n-1?(uint32_t)n:(uint32_t)(rem+1);
  if(rem<(uint64_t)n)s->nonce_empty=true;else s->nonce_cursor+=n;
  *done=take;
  for(uint32_t i=0;i<take;i++){
    uint64_t nonce=s->nonce_base+(first+i)*s->nonce_stride;
    uint8_t tag[32];
    if(!bnt::pow_hash_cpu(s->job_header.data(),s->job_header.size(),nonce,s->m,tag))return -1;
    bool share=memcmp(tag,s->share_target,32)<=0, nz=false;
    for(int k=0;k<32;k++)nz|=s->network_target[k]!=0;
    bool block=nz&&memcmp(tag,s->network_target,32)<=0;
    if(share||block){BgShareCandidate& x=c[(*count)++];x.nonce=nonce;x.lane_index=i;x.flags=(share?BG_CANDIDATE_SHARE:0u)|(block?BG_CANDIDATE_BLOCK:0u);memcpy(x.hash,tag,32);}
  }
  if(ms)*ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-t0).count();return 0;
}
int bg_test_blake2b(int, uint8_t out64[64]) { bnt::blake2b(out64, 64, "abc", 3); return 0; }
int bg_profile(void*, int, double* a, double* b) { *a = *b = 1; return 0; }
}
