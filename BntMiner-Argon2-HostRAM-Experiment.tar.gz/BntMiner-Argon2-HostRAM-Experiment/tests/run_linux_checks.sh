#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

command -v g++ >/dev/null 2>&1 || { echo "ERROR: g++ not found" >&2; exit 2; }
command -v pkg-config >/dev/null 2>&1 || { echo "ERROR: pkg-config not found" >&2; exit 2; }
pkg-config --exists openssl || { echo "ERROR: OpenSSL development headers are required" >&2; exit 2; }

TMPDIR_CHECK="$(mktemp -d)"
trap 'rm -rf "$TMPDIR_CHECK"' EXIT

echo '[1/8] Verify shared-memory pad=2/pad=4 index and vector alignment bounds'
g++ -O2 -std=c++17 tests/smem_layout_test.cpp -o "$TMPDIR_CHECK/smem_layout_test"
"$TMPDIR_CHECK/smem_layout_test"

echo '[2/8] Verify inverse-shuffle round and scatter-store round equivalence'
g++ -O2 -std=c++17 tests/round4_scatter_test.cpp -o "$TMPDIR_CHECK/round4_scatter_test"
"$TMPDIR_CHECK/round4_scatter_test"

echo '[3/8] Compile and run CPU reference / CUDA-layout emulation tests'
g++ -O2 -std=c++17 -Isrc tests/cloud_test.cpp -o "$TMPDIR_CHECK/cloud_test"
"$TMPDIR_CHECK/cloud_test" tests/vectors.txt

echo '[4/8] Emulate GPU Argon2i address-table generation against the CPU reference'
g++ -O2 -std=c++17 -Isrc tests/ref_table_gpu_emulation_test.cpp -o "$TMPDIR_CHECK/ref_table_gpu_emulation_test"
"$TMPDIR_CHECK/ref_table_gpu_emulation_test"

echo '[5/8] Check the 92-byte production header stride with the CPU GPU stub'
g++ -O2 -std=gnu++17 -pthread -Isrc -Igpu tests/header92_stub_test.cpp tests/bg_stub.cpp -o "$TMPDIR_CHECK/header92_stub_test"
"$TMPDIR_CHECK/header92_stub_test"

echo '[6/8] Check share/block target-filter and compact candidate output with CPU GPU stub'
g++ -O2 -std=gnu++17 -pthread -Isrc -Igpu tests/share_filter_stub_test.cpp tests/bg_stub.cpp -o "$TMPDIR_CHECK/share_filter_stub_test"
"$TMPDIR_CHECK/share_filter_stub_test"

echo '[7/8] Verify GPU Stratum parser/formatter contract and disjoint GPU nonce shards with CPU stub'
g++ -O2 -std=gnu++17 -pthread -Isrc -Igpu tests/stratum_nonce_stub_test.cpp tests/bg_stub.cpp -o "$TMPDIR_CHECK/stratum_nonce_stub_test"
"$TMPDIR_CHECK/stratum_nonce_stub_test"

echo '[8/8] Compile Linux host code with CPU GPU stub'
g++ -O2 -std=gnu++17 -pthread -Isrc -Igpu \
    src/main.cpp src/tls_conn.cpp tests/bg_stub.cpp \
    $(pkg-config --cflags --libs openssl) -o "$TMPDIR_CHECK/bntminer_stub"
"$TMPDIR_CHECK/bntminer_stub" --help >/dev/null
"$TMPDIR_CHECK/bntminer_stub" --argon2-memory host --lanes 1 --help >/dev/null
"$TMPDIR_CHECK/bntminer_stub" --argon2-memory hybrid --lanes 2 --help >/dev/null
if "$TMPDIR_CHECK/bntminer_stub" --argon2-memory invalid --help >/dev/null 2>&1; then
    echo 'ERROR: invalid --argon2-memory value was accepted' >&2
    exit 1
fi
printf 'Host compile / CLI smoke test (gpu/host/hybrid memory options): OK\n'
printf 'NOTE: GPU kernel compilation and GPU hash vectors require nvcc and a CUDA-capable NVIDIA device.\n'
