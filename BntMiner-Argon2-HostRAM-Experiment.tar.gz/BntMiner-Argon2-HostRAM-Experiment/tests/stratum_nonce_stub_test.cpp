#include "../gpu/bnt_gpu.h"
#include <cstdio>
#include <cstring>
#include <set>
#include <string>
#include <vector>

static std::string hex_repeat(const char* pair, size_t bytes) {
    std::string s; s.reserve(bytes * 2);
    for (size_t i = 0; i < bytes; ++i) s += pair;
    return s;
}

int main() {
    const std::string line = std::string("{\"method\":\"job\",\"params\":{\"job_id\":\"job-42\",\"header_base\":\"") +
        hex_repeat("ab", 92) + "\",\"target\":\"" + hex_repeat("ff", 32) +
        "\",\"network_target\":\"" + hex_repeat("00", 32) +
        "\",\"height\":42,\"difficulty\":123,\"nonce_start\":10,\"nonce_end\":15}}";

    void* g = bg_create(0, 8, 2, 0, 0);
    if (!g) { std::puts("FAIL: bg_create"); return 1; }

    BgStratumMessage m{};
    if (bg_parse_stratum(g, line.data(), (uint32_t)line.size(), &m) != 0 || !m.valid ||
        m.type != BG_STRATUM_JOB || std::strcmp(m.job_id, "job-42") ||
        m.header_len != 92 || !m.has_target || !m.has_network_target ||
        m.height != 42 || m.difficulty != 123 || m.nonce_start != 10 || m.nonce_end != 15) {
        std::puts("FAIL: GPU Stratum parser contract (CPU stub)"); bg_destroy(g); return 1;
    }

    uint8_t header[92], share[32], network[32]{};
    std::memset(header, 0xab, sizeof(header)); std::memset(share, 0xff, sizeof(share));
    std::set<uint64_t> all;
    for (uint64_t shard = 0; shard < 2; ++shard) {
        if (bg_set_gpu_job(g, header, sizeof(header), share, network, 10, 15, shard, 2) != 0) {
            std::puts("FAIL: set GPU nonce shard"); bg_destroy(g); return 1;
        }
        for (;;) {
            BgShareCandidate candidates[2]{};
            uint32_t count = 0, done = 0;
            int rc = bg_hash_next_candidates(g, candidates, 2, &count, &done, 2, nullptr, nullptr);
            if (rc != 0) { std::puts("FAIL: GPU nonce batch (CPU stub)"); bg_destroy(g); return 1; }
            if (done == 0) break;
            if (count != done) { std::puts("FAIL: all-FF target must accept every hash"); bg_destroy(g); return 1; }
            for (uint32_t i = 0; i < count; ++i) all.insert(candidates[i].nonce);
        }
    }
    if (all.size() != 6 || *all.begin() != 10 || *all.rbegin() != 15) {
        std::puts("FAIL: GPU nonce shards are not disjoint/complete"); bg_destroy(g); return 1;
    }

    BgStratumMessage login{};
    const char* login_line = "{\"id\":1,\"status\":\"ok\",\"result\":{\"protocol_version\":2,\"capabilities\":[\"submit_claimed_hash\"]}}";
    if (bg_parse_stratum(g, login_line, (uint32_t)std::strlen(login_line), &login) != 0 ||
        !login.valid || login.type != BG_STRATUM_RESPONSE || login.id != 1 || !login.status_ok ||
        login.protocol_version != 2 || !login.can_submit_claimed_hash) {
        std::puts("FAIL: Stratum login response parse (CPU stub)"); bg_destroy(g); return 1;
    }

    BgStratumMessage notice{};
    const char* notice_line = "{\"method\":\"notification\",\"params\":{\"kind\":\"maintenance\",\"message\":\"hello\\nworld\"}}";
    if (bg_parse_stratum(g, notice_line, (uint32_t)std::strlen(notice_line), &notice) != 0 ||
        !notice.valid || notice.type != BG_STRATUM_NOTIFICATION ||
        std::strcmp(notice.kind, "maintenance") || std::strcmp(notice.message, "hello\nworld")) {
        std::puts("FAIL: Stratum notification parse (CPU stub)"); bg_destroy(g); return 1;
    }

    char formatted[BG_STRATUM_FORMAT_CAPACITY] = {};
    uint32_t formatted_bytes = 0;
    if (bg_format_stratum_login(g, "wallet\"x", "rig\\gpu", formatted, sizeof(formatted), &formatted_bytes) != 0 ||
        formatted_bytes != std::strlen(formatted) ||
        std::string(formatted) != "{\"id\":1,\"method\":\"login\",\"params\":{\"address\":\"wallet\\\"x\",\"worker\":\"rig\\\\gpu\",\"protocol_version\":2,\"capabilities\":[\"login_negotiation\",\"share_validation_status\",\"submit_claimed_hash\"]}}") {
        std::puts("FAIL: GPU login JSON formatter (CPU stub)"); bg_destroy(g); return 1;
    }
    uint8_t raw_hash[32]; std::memset(raw_hash, 0xab, sizeof(raw_hash));
    std::string expected_hash; for (int i = 0; i < 32; ++i) expected_hash += "ab";
    const std::string expected_submit = std::string("{\"id\":7,\"method\":\"submit\",\"params\":{\"job_id\":\"job-42\",\"nonce\":99,\"claimed_hash\":\"") +
        expected_hash + "\",\"miner_version\":\"bntminer/test\"}}";
    if (bg_format_stratum_submit(g, 7, "job-42", 99, raw_hash, 1, "bntminer/test",
                                 formatted, sizeof(formatted), &formatted_bytes) != 0 ||
        formatted_bytes != std::strlen(formatted) || std::string(formatted) != expected_submit) {
        std::puts("FAIL: GPU submit JSON formatter (CPU stub)"); bg_destroy(g); return 1;
    }
    if (bg_format_stratum_submit(g, 8, "job-42", 77, raw_hash, 0, "bntminer/test",
                                 formatted, sizeof(formatted), &formatted_bytes) != 0 ||
        std::string(formatted).find("claimed_hash") != std::string::npos ||
        std::string(formatted).find("\"nonce\":77") == std::string::npos) {
        std::puts("FAIL: optional claimed-hash JSON formatter (CPU stub)"); bg_destroy(g); return 1;
    }

    bg_destroy(g);
    std::puts("Stratum JSON extraction/formatting + GPU nonce sharding contract (CPU stub): OK");
    return 0;
}
