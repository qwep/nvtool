#include "../gpu/bnt_gpu.h"
#include "../src/argon_ref.h"
#include <cstdio>
#include <cstring>

static bool step_target(const uint8_t in[32], uint8_t out[32], bool increment)
{
    memcpy(out, in, 32);
    for (int i = 31; i >= 0; --i) {
        if (increment) {
            if (out[i] != 0xff) { ++out[i]; return true; }
            out[i] = 0;
        } else {
            if (out[i] != 0) { --out[i]; return true; }
            out[i] = 0xff;
        }
    }
    return false;
}

int main()
{
    uint8_t header[92], expected[32], got[32], below[32], above[32], maximum[32], zero[32] = {};
    for (size_t i = 0; i < sizeof header; ++i) header[i] = (uint8_t)(i * 37u + 11u);
    const uint64_t nonce = 0x123456789abcdef0ULL;
    if (!bnt::pow_hash_cpu(header, sizeof header, nonce, 8, expected)) return 1;
    if (!step_target(expected, below, false) || !step_target(expected, above, true)) return 2;
    memset(maximum, 0xff, sizeof maximum);

    void* ctx = bg_create(0, 8, 1, 0, 5);
    if (!ctx) return 3;
    uint8_t sf[1] = {}, bf[1] = {};
    double ms = 0.0;
    bool eq = bg_hash_full_checked(ctx, header, sizeof header, &nonce, expected, expected,
                                   got, sf, bf, 1, nullptr, &ms) == 0 &&
              memcmp(got, expected, 32) == 0 && sf[0] == 1 && bf[0] == 1;
    bool edge = bg_hash_full_checked(ctx, header, sizeof header, &nonce, below, above,
                                     got, sf, bf, 1, nullptr, &ms) == 0 &&
                memcmp(got, expected, 32) == 0 && sf[0] == 0 && bf[0] == 1;
    bool zero_net = bg_hash_full_checked(ctx, header, sizeof header, &nonce, maximum, zero,
                                         got, sf, bf, 1, nullptr, &ms) == 0 &&
                    sf[0] == 1 && bf[0] == 0;

    BgShareCandidate candidates[1] = {};
    uint32_t count = 0;
    bool compact_match = bg_hash_full_candidates(ctx, header, sizeof header, &nonce,
        expected, expected, candidates, 1, &count, 1, nullptr, &ms) == 0 && count == 1 &&
        candidates[0].nonce == nonce && candidates[0].lane_index == 0 &&
        candidates[0].flags == (BG_CANDIDATE_SHARE | BG_CANDIDATE_BLOCK) &&
        memcmp(candidates[0].hash, expected, 32) == 0;
    uint32_t none_count = 999;
    bool compact_empty = bg_hash_full_candidates(ctx, header, sizeof header, &nonce,
        zero, zero, candidates, 1, &none_count, 1, nullptr, &ms) == 0 && none_count == 0;
    bg_destroy(ctx);
    if (!eq || !edge || !zero_net || !compact_match || !compact_empty) {
        fprintf(stderr, "GPU compact candidate stub contract: FAILED (eq=%d edge=%d zero_net=%d compact=%d empty=%d)\n",
                eq, edge, zero_net, compact_match, compact_empty);
        return 4;
    }
    puts("Share/block target + compact candidate contract (CPU stub): OK");
    return 0;
}
